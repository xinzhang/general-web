﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;
using System.Configuration;

namespace ClientPortal.Web.MLC.Controllers
{
    public class RelayController : ApiController
    {
        private HttpClient httpClient = new HttpClient();
        private Uri serviceUri;

        // XZ - 2016/0707 - use this upload service uri to decide if the server address can be communicated by Relay
        // serviceUri for upload
        private static readonly string uploadServiceUri = ConfigurationManager.AppSettings["UploadServiceAddress"];

        [HttpGet]
        public async Task<HttpResponseMessage> GetRelay()
        {
            if (!CheckRelayServerAddress())
                return CreateResponse(new HttpResponseMessage(HttpStatusCode.BadRequest));

            SetupParameters();
            using (HttpResponseMessage serviceResponse = await httpClient.GetAsync(serviceUri, HttpCompletionOption.ResponseHeadersRead))
            {
                return CreateResponse(serviceResponse);
            }
        }

        [HttpPost]
        public async Task<HttpResponseMessage> PostRelay()
        {
            if (!CheckRelayServerAddress())
                return CreateResponse(new HttpResponseMessage(HttpStatusCode.BadRequest));

            SetupParameters();
            HttpContent content = this.Request.Content;

            this.Request.Content = null;
            
            if (this.Request.Headers.Contains("uploadCategory"))
            {
                var category = this.Request.Headers.FirstOrDefault(x => x.Key == "uploadCategory");
                httpClient.DefaultRequestHeaders.Add("uploadCategory", category.Value.FirstOrDefault());
            }

            using (HttpResponseMessage serviceResponse = await httpClient.PostAsync(serviceUri, content))
            {
                return CreateResponse(serviceResponse);
            }
        }

        [HttpPut]
        public async Task<HttpResponseMessage> PutRelay()
        {
            if (!CheckRelayServerAddress())
                return CreateResponse(new HttpResponseMessage(HttpStatusCode.BadRequest));

            SetupParameters();
            HttpContent content = this.Request.Content;
            this.Request.Content = null;

            using (HttpResponseMessage serviceResponse = await httpClient.PutAsync(serviceUri, content))
            {
                return CreateResponse(serviceResponse);
            }
        }

        [HttpDelete]
        public async Task<HttpResponseMessage> DeleteRelay()
        {
            if (!CheckRelayServerAddress())
                return CreateResponse(new HttpResponseMessage(HttpStatusCode.BadRequest));

            SetupParameters();

            using (HttpResponseMessage serviceResponse = await httpClient.DeleteAsync(serviceUri))
            {
                return CreateResponse(serviceResponse);
            }
        }

        private HttpResponseMessage CreateResponse(HttpResponseMessage serviceResponse)
        {
            HttpResponseMessage relayResponse = this.Request.CreateResponse(serviceResponse.StatusCode);

            relayResponse.Content = serviceResponse.Content;
            serviceResponse.Content = null;

            return relayResponse;
        }

        private string ExtractDestUrl(HttpRequestMessage request)
        {
            string destUrl = string.Empty;

            if (this.Request != null)
            {
                IEnumerable<string> listDestUrl = new List<string>();
                request.Headers.TryGetValues("DestUrl", out listDestUrl);

                if (listDestUrl != null && listDestUrl.Count() > 0)
                {
                    destUrl = string.Format("{0}", listDestUrl.FirstOrDefault());
                }
            }
            //Tam: Removed
            //return destUrl;
            //To fix the DestUrl while using angular-file-upload (diffent domain)  
            return destUrl = (destUrl == string.Empty) ? uploadServiceUri : destUrl;            
        }

        private void SetupParameters()
        {
            this.httpClient = new HttpClient();
            if (
                this.Request != null
                && this.Request.Headers != null
                && this.Request.Headers.Authorization != null
               )
            {
                this.httpClient.DefaultRequestHeaders.Authorization = this.Request.Headers.Authorization;
            }
            this.httpClient.Timeout = TimeSpan.FromMinutes(20);

            this.serviceUri = new Uri(ExtractDestUrl(this.Request));            
        }

        private string GetServerAddress(string requestUrl)
        {
            string result = requestUrl;

            if (requestUrl.ToLower().StartsWith("http://") || requestUrl.ToLower().StartsWith("https://")) {
                result = requestUrl.Replace("http://", "").Replace("https://", "");
                return result.Substring(0, result.LastIndexOf("/"));
            }
            else {
                return "";
            }
        }

        private bool CheckRelayServerAddress()
        {            
            string destinationUrl = ExtractDestUrl(this.Request);
            string server = "";
            string port = "";

            // if the destination has no http,https, it canbe the local url, 
            // in this case, server/port == empty, and we allow it

            if (destinationUrl.ToLower().StartsWith("http://") || destinationUrl.ToLower().StartsWith("https://"))
            {
                string result = destinationUrl.Replace("http://", "").Replace("https://", "");
                if (result.IndexOf("/") >= 0)
                {
                    result = result.Substring(0, result.IndexOf("/"));
                }

                if (result.IndexOf(':') >= 0) {
                    server = result.Substring(0, result.IndexOf(':')).ToLower();
                    port = result.Substring(result.IndexOf(':') + 1).ToLower();
                }
                else
                {
                    server = result;
                    port = "";
                }
            }

            string allowedServers = ConfigurationManager.AppSettings["RelayAllowedServers"].ToLower();
            string allowedPorts = ConfigurationManager.AppSettings["RelayAllowedPorts"].ToLower();

            if (!string.IsNullOrEmpty(allowedServers) && server!= "" && !allowedServers.Contains(server))
                return false;

            if (!string.IsNullOrEmpty(allowedPorts) && port != "" && !allowedPorts.Contains(port))
                return false;

            return true;
        }
    }
}
