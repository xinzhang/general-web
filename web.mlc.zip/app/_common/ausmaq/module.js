(function(){
    "use strict";

    angular.module('ausmaq.ui', []);
})();