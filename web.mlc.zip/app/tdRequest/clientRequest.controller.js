﻿(function () {
    'use strict';

    angular.module('app').controller('ClientRequestCtrl', ClientRequestCtrl);

    ClientRequestCtrl.$inject = ['$location', '$scope', '$stateParams', 'tdRequestService', 'commonService', 'authService', '$q', 'notify', '$filter'];

    function ClientRequestCtrl($location, $scope, $stateParams, tdRequestService, commonService, authService, $q, notify, $filter) {

        var vm = this;
        vm.title = "Requests";
        vm.clientCode = '';

        //Used by modalRequestDetailTDAusmaqRateTermStandard
        vm.asset = '';

        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }
        vm.histories = [];
        vm.pageRequestList = [];
        vm.filteredHistories = vm.histories;
        
        // Sort
        var orderBy = $filter('orderBy');
       

        vm.gotoPage = function (pageno) {
            if (pageno < 0 || pageno >= vm.paging.totalPage)
                return;

            vm.paging.isPrev = vm.paging.isNext = true;

            if (pageno == 0)
                vm.paging.isPrev = false;

            if (pageno == (vm.paging.totalPage - 1))
                vm.paging.isNext = false;

            vm.paging.currentPage = pageno;

            vm.pageRequestList = vm.filteredHistories.slice(pageno * 10, (pageno + 1) * 10);

        }

        activate();

        ////////////////

        function activate() {
            vm.authentication = authService.authentication;

            $("#modalRequestDetailTermAndConditions").draggable({
                handle: ".modal-header"
            });

            $("#modalRequestDetailInterestRate").draggable({
                handle: ".modal-header"
            });

            $("#modalRequestDetailDirectNegotiatedRate").draggable({
                handle: ".modal-header"
            });
            
            $("#modalRequestDetailDirectNegotiatedInvestment").draggable({
                handle: ".modal-header"
            });
            if (vm.authentication.adiCode != '') {                
                vm.clientCode = vm.authentication.adiCode;
                vm.selectionRequestTypes = ['Term and conditions', 'Interest rate',  'Negotiated Investment', 'TD Ausmaq Rate Term Days', 'TD Ausmaq Rate Term Standard'];

            } else if (vm.authentication.tdOrgCode != '' && vm.authentication.isTermDeposit) {
                
                vm.clientCode = vm.authentication.tdOrgCode;
                vm.selectionRequestTypes = ['Negotiated Investment', 'TD Ausmaq Rate Term Days', 'TD Ausmaq Rate Term Standard'];
            } 

            tdRequestService.getRequestList(vm.clientCode)
                .then(function (response) {
                    vm.histories = response;
                    vm.filteredHistories = vm.histories;
                    vm.paging.rowTotal = vm.filteredHistories.length;
                    vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
                    vm.gotoPage(0);
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });
        };

        vm.refresh = function () {
            activate();
        }

        vm.filterObject = {
            'requestType': '',
            'addedBy': '',
            'requestStatus': ''
        }

        
        vm.selectionRequestStatuses = ['Pending', 'Received', 'Accepted', 'Review', 'Error', 'Success'];

        vm.setFilterObject = function (purpose) {

            console.log('purpose: ' + purpose);

            switch (purpose) {
                case "AllRequests":
                    vm.filterObject.requestType = '';
                    vm.filterObject.addedBy = '';
                    vm.filterObject.requestStatus = '';
                    break;

                case "MyRequests":
                    vm.filterObject.addedBy = vm.authentication.userName;
                    break;

                case "PendingRequests":
                    vm.filterObject.requestStatus = 'Pending';
                    break;
            }
        };

        vm.filterRequestList = function (row) {
            var blRequestType = false;

            blRequestType = (
                    (vm.isObjEmpty(vm.filterObject.requestType) || vm.filterObject.requestType === row.requestType)
                    &&
                    (vm.isObjEmpty(vm.filterObject.addedBy) || vm.filterObject.addedBy === row.addedBy)
                    &&
                    (vm.isObjEmpty(vm.filterObject.requestStatus) || vm.filterObject.requestStatus === row.status)
                );

            if (!vm.isObjEmpty(vm.freeQuery)) {
                blRequestType = blRequestType
                    &&
                    (
                         angular.lowercase(row.requestReference.toString()).indexOf(angular.lowercase(vm.freeQuery) || '') !== -1
                    );
            }
            return blRequestType;
        };

        vm.isObjEmpty = function (obj) {
            if (obj === undefined || obj === null || obj === '') {
                return true;
            }
            else {
                return false;
            }
        };

        vm.submitDirectNegotiatedRate = function (submitDNRRVM) {
            var toAccept = submitDNRRVM.tdCustomisedAssetRateDataViewModel.accepted;
            var toReject = submitDNRRVM.tdCustomisedAssetRateDataViewModel.rejected;

            tdRequestService.submitDirectNegotiatedRate(submitDNRRVM)
                .then(function (response) {
                    // Refresh the list
                    activate();
                    if (toAccept) {
                        notify.showSuccess("Direct Negotiated Rate Request is accepted successfully.");
                    }
                    else if (toReject) {
                        notify.showSuccess("Direct Negotiated Rate Request is rejected successfully.");
                    }
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });
        };

        vm.acceptDirectNegotiatedRate = function (submitDNRRVM) {
            submitDNRRVM.tdCustomisedAssetRateDataViewModel.accepted = true;
            submitDNRRVM.tdCustomisedAssetRateDataViewModel.rejected = false;
            vm.submitDirectNegotiatedRate(submitDNRRVM, "accept");
            $('#modalRequestDetailDirectNegotiatedRate').modal('hide');
        };

        vm.rejectDirectNegotiatedRate = function (submitDNRRVM) {
            submitDNRRVM.tdCustomisedAssetRateDataViewModel.accepted = false;
            submitDNRRVM.tdCustomisedAssetRateDataViewModel.rejected = true;
            vm.submitDirectNegotiatedRate(submitDNRRVM, "reject");
            $('#modalRequestDetailDirectNegotiatedRate').modal('hide');
        };

        vm.showRequestDetail = function (clientCode, reference, requestType) {
            tdRequestService.getRequestDetailByReference(clientCode, reference)
                .then(function (response) {
                    switch (angular.lowercase(requestType)) {
                        case "term and conditions":
                            vm.modalTitle = "Term And Conditions";
                            vm.requestDetail = response;
                            vm.effectiveDate = vm.requestDetail.effectiveDate;
                            vm.documentDescription = vm.requestDetail.documentDescription;
                            vm.userName = vm.requestDetail.userName;
                            vm.adiCode = vm.requestDetail.adiCode;
                            vm.localFileName = vm.requestDetail.localFileName;
                            $('#modalRequestDetailTermAndConditions').modal('show');
                            break;

                        case "interest rate":
                            vm.modalTitle = "Interest Rate";
                            vm.requestDetail = response;
                            vm.submitDate = vm.requestDetail.submitDate;
                            vm.userName = vm.requestDetail.userName;
                            vm.listTDAssetRateViewModel = vm.requestDetail.listTDAssetRateViewModel;
                            $('#modalRequestDetailInterestRate').modal('show');
                            break;

                        case "direct negotiated rate":
                            vm.modalTitle = "Direct Negotiated Rate";
                            vm.submitDirectNegotiatedRateRequestViewModel = response;
                            vm.tdCustomisedAssetRateDataViewModel = vm.submitDirectNegotiatedRateRequestViewModel.tdCustomisedAssetRateDataViewModel;
                            $('#modalRequestDetailDirectNegotiatedRate').modal('show');
                            break;
                            
                        case "negotiated investment":
                            vm.modalTitle = "Client Negotiated Term Deposit";
                            vm.requestDetail = response;
                            vm.adi = vm.requestDetail.selectedAdi;
                            vm.term = vm.requestDetail.termDays;
                            vm.interestRate = vm.requestDetail.interestRate;
                            vm.interestPaidFrequency = vm.requestDetail.interestPaidFreq;
                            vm.amount = vm.requestDetail.amount;
                            vm.offerExpiry = vm.requestDetail.offerExpiry;
                            vm.specialRateReference = vm.requestDetail.specialRateRef;
                            vm.contactName = vm.requestDetail.contactName;
                            vm.email = vm.requestDetail.email;
                            vm.phone = vm.requestDetail.phone;
                            vm.notes = vm.requestDetail.notes;
                            $('#modalRequestDetailDirectNegotiatedInvestment').modal('show');
                            break;

                        case "td ausmaq rate term days":
                            vm.modalTitle = "TD Ausmaq Rate Term Days";
                            vm.requestDetail = response;
                            
                            console.log('vm.modalTitle: ' + vm.modalTitle);


                            vm.adi = vm.requestDetail.selectedAdi;
                            vm.term = vm.requestDetail.termDays;
                            vm.interestRate = vm.requestDetail.interestRate;
                            vm.interestPaidFrequency = vm.requestDetail.interestPaidFreq;
                            vm.amount = vm.requestDetail.amount;
                            vm.offerExpiry = vm.requestDetail.offerExpiry;
                            vm.specialRateReference = vm.requestDetail.specialRateRef;
                            vm.contactName = vm.requestDetail.contactName;
                            vm.email = vm.requestDetail.email;
                            vm.phone = vm.requestDetail.phone;
                            vm.notes = vm.requestDetail.notes;
                            vm.adiCodes = vm.adi.split(","); // Convert to array of string

                            console.log('vm.adi: ' + vm.adi);

                            console.log('vm.term: ' + vm.term);
                            console.log('vm.interestRate: ' + vm.interestRate);
                            console.log('vm.interestPaidFrequency: ' + vm.interestPaidFrequency);
                            console.log('vm.amount: ' + vm.amount);
                            console.log('vm.offerExpiry: ' + vm.offerExpiry);
                            console.log('vm.specialRateReference: ' + vm.specialRateReference);
                            console.log('vm.contactName: ' + vm.contactName);
                            console.log('vm.email: ' + vm.email);
                            console.log('vm.phone: ' + vm.phone);
                            console.log('vm.notes: ' + vm.notes);
                            console.log('vm.adiCodes: ' + vm.adiCodes);



                            $('#modalRequestDetailTDAusmaqRateTermDays').modal('show');
                            break;

                        case "td ausmaq rate term standard":
                            vm.modalTitle = "TD Ausmaq Rate Term Standard";
                            vm.requestDetail = response;

                            vm.adi = vm.requestDetail.selectedAdi;                            
                            (isNaN(vm.requestDetail.tdAssetTerm.substring(0, 2) === true) ?
                            vm.asset = vm.requestDetail.tdAssetTerm.substring(0, 1):
                            vm.asset = vm.requestDetail.tdAssetTerm.substring(0, 2));
                            vm.asset = vm.asset.concat(' Months ');
                            vm.asset = vm.asset.concat(vm.getPaidFrequency(vm.requestDetail.tdAssetPaidFreq.toLowerCase()));
                            vm.amount = vm.requestDetail.amount;
                            vm.contactName = vm.requestDetail.contactName;
                            vm.email = vm.requestDetail.email;
                            vm.phone = vm.requestDetail.phone;
                            vm.notes = vm.requestDetail.notes;
                            vm.adiCodes = vm.adi.split(","); // Convert to array of string
                            $('#modalRequestDetailTDAusmaqRateTermStandard').modal('show');
                            break;
                        default:
                            break;
                    }

                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });

        };

        // Sort by column in the grid
        vm.sortColumn = 'dateTimeAdded';
        vm.sortOrder = true;
        vm.sortData = function (columnName) {
            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.filteredHistories = orderBy(vm.filteredHistories, vm.sortColumn, vm.sortOrder);
            vm.gotoPage(0);
        }

        vm.filterHistory = function (searchCriteria) {
            vm.filteredHistories = $filter('filter')(vm.histories, searchCriteria);
            vm.paging.rowTotal = vm.filteredHistories.length;
            vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
            vm.gotoPage(0);
        }
        //Used for Ausmaq Negotiated Rate Term (Standard)
        vm.getPaidFrequency = function (paidFrequency) {
            var retVal = 'Undefined';
            switch (paidFrequency) {
                case 'am':
                    retVal = '(At Maturity)';
                    break;
                case 'm':
                    retVal = '(Monthly)';
                    break;
                case 'q':
                    retVal = '(Quarterly)';
                    break;
                case 's':
                    retVal = '(Semi-Annually)';
                    break;
                case 'a':
                    retVal = '(Annually)';
                    break;
                default:

            }
            return retVal;
        }
    }

})();
