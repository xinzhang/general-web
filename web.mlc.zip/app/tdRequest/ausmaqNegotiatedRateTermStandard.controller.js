﻿(function () {
    'use strict';

    angular.module('app').controller('AusmaqNegotiatedRateTermStandardCtrl', AusmaqNegotiatedRateTermStandardCtrl);
 
    AusmaqNegotiatedRateTermStandardCtrl.$inject = ['$location', '$scope', '$stateParams', 'adiService', 'tdRequestService', 'termdepositService', 'commonService', 'authService', 'userClientAdminService', '$q', 'notify'];

    function AusmaqNegotiatedRateTermStandardCtrl($location, $scope, $stateParams, adiService, tdRequestService, termdepositService, commonService, authService, userClientAdminService, $q, notify) {

        var vm = this;

        vm.title = "Ausmaq Negotiated Rate - Term (Standard)";

        //Term && Payment frequency
        vm.selectionAsset = [];
        //Initialize
        vm.selectedAsset = {
            text: '',
            value: ''
        };
        //displaySelectionAsset list contains value and text
        vm.displaySelectionAsset = [];

        //Displays message using data content (requried) 
        $('.popover-dismiss').popover({
            trigger: 'focus',
            html: 'true'
        });

        //AdiCodeList
        vm.selectionAdiCode = [];
        vm.selectedAdiCode = '';
        
        //Selected ADI
        $scope.tags = [];
        
        //current $scope.tags.length
        vm.currentCount = 0;

        vm.clientCode = '';

        vm.status = {
            isopen: false
        }

        //Control max 3 ADIs
        vm.addAdiMode = true;
               
        //tdTermStandard
        vm.tdTermStandard = {
            clientCode: '',
            selectedAdi: '', // Max 3 ADI
            amount: '', 
            contactName: '',
            email: '',
            phone: '',
            notes: '',
            tdAssetTerm: '', 
            tdAssetPaidFreq:''
        }

        //Monitor add/delete selectedAdi
        $scope.$watch('tags', function () {
            // Handle Add/Delete ADI
            if ((vm.currentCount - $scope.tags.length > 0) && $scope.tags.length> 0){
                //Reload common asset.
                vm.getCommonAssets();
            }
            else{
                //Clear up vm.displaySelectionAsset
                vm.displaySelectionAsset = [];
                //Make sure set vm.selectedAsset to empty (null), not initialize
                vm.selectedAsset = '';
            }
        }, true);

        activate();
        //Load common asset base on selectedAdi list ($scope.tags[])
        vm.getCommonAssets = function()
        {
            var adiList ='';
            for (var i = 0; i < $scope.tags.length; i++) {
                adiList = adiList + $scope.tags[i].name;
                adiList = adiList.concat(",");
            }
            // Initialize
            vm.displaySelectionAsset = [];
            
            termdepositService.getCommonAssets(vm.clientCode, adiList).then(function (response) {
                vm.selectionAsset = response;
                //Create display object: Assume no more that 8 years as term length 
                for (var i = 0; i < vm.selectionAsset.length; i++) {
                    //New object
                    var currentObject = { value: '', text: '' };
                    //Assign value
                    currentObject.value = vm.selectionAsset[i];
                    // Build displaySelectionAsset list
                    if (isNaN(vm.selectionAsset[i].substring(0, 2)))// Less than 10 months
                    {
                        //Must select substring(0, 1)
                        currentObject.text = vm.selectionAsset[i].substring(0, 1).concat(' Months ');
                        currentObject.text = currentObject.text.concat(vm.getPaidFrequency(vm.selectionAsset[i].substring(2).toLowerCase()));
                    }
                    else // Greater than 10 months 
                    {
                        currentObject.text = vm.selectionAsset[i].substring(0, 2).concat(' Months ');
                        currentObject.text = currentObject.text.concat(vm.getPaidFrequency(vm.selectionAsset[i].substring(3).toLowerCase()));
                    }
                    // Add current object to displaySelectionAsset list.
                    vm.displaySelectionAsset.push(currentObject);
                }
            }, function (err) {
                vm.message = commonService.showError(err);
            });

        }
        //Convert initial to corresponding description
        vm.getPaidFrequency = function (paidFrequency) {
            var retVal = 'Undefined';
            switch(paidFrequency)
            {
                case 'am':
                    retVal = '(At Maturity)';
                    break;
                case 'm':
                    retVal = '(Monthly)';
                    break;
                case 'q':
                    retVal = '(Quarterly)';
                    break;
                case 's':
                    retVal = '(Semi-Annually)'; // From B3
                    break;
                case 'a':
                    retVal = '(Annually)';
                    break;
                default:

            }
            return retVal;
        }

        vm.addAdi = function () {
            //Enable add mode
            if ($scope.tags.length < 3)
                vm.addAdiMode = true;
            //Add mode
            if (vm.addAdiMode && vm.selectedAdiCode != "") {
                //New object
                var selectedAdiObj = { name: vm.selectedAdiCode };
                selectedAdiObj.name = vm.selectedAdiCode;

                for (var i = 0; i < $scope.tags.length && $scope.tags[i].name !== selectedAdiObj.name; i++) { }

                //check existing ADI
                //New ADI
                if ($scope.tags.length == i) {
                    $scope.tags.push(selectedAdiObj);
                    vm.currentCount = $scope.tags.length;
                    vm.getCommonAssets();

                }
                else {

                    //ADI already exists!
                }
                // Reach to max ADI. Disable addMode
                if ($scope.tags.length >= 3)
                    vm.addAdiMode = false;

            }
        }

        function activate() {
            vm.authentication = authService.authentication;
            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;

            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;
            // Get user detail by default
            userClientAdminService.getUserDetails(vm.authentication.userName)
                .then(function (reponse) {
                    vm.tdTermStandard.contactName = reponse.firstName.concat(' ', reponse.lastName);
                    vm.tdTermStandard.email = reponse.email;
                    vm.tdTermStandard.phone = reponse.phoneNumber;
                }, function (err) {
                    vm.message = commonService.showError(err);
                });

            //Load ADI list
            adiService.getAdiCodeList()
                .then(function (reponse) {
                    vm.selectionAdiCode = reponse;
                }, function (err) {
                    vm.message = commonService.showError(err);
                });
        }

        vm.submitRequest = function () {
            vm.tdTermStandard.selectedAdi = vm.selectedAdiCode;
            vm.tdTermStandard.clientCode = vm.clientCode;

            // < 10 
            if (isNaN(vm.selectedAsset.value.substring(0, 2))) {
                // tdAssetTerm = 1...9M
                vm.tdTermStandard.tdAssetTerm = vm.selectedAsset.value.substring(0, 2);
                //tdAssetPaidFreq = AM/M/Q/S/A
                vm.tdTermStandard.tdAssetPaidFreq = vm.selectedAsset.value.substring(2);
            }
            else // >= 10 months 
            {
                // tdAssetTerm > 9M
                vm.tdTermStandard.tdAssetTerm = vm.selectedAsset.value.substring(0, 3);
                //tdAssetPaidFreq = AM/M/Q/S/A
                vm.tdTermStandard.tdAssetPaidFreq = vm.selectedAsset.value.substring(3);
            }


            console.log('Submit Ausmaq negotiated rate term (standard) request');
            tdRequestService.submitAusmaqRateTermStandardRequest(vm.tdTermStandard)
                .then(function (response) {
                    var reference = response;
                    notify.showSuccess("Ausmaq Negotiated Rate Term (Standard) Request is submitted successfully.");
                    // Redirect to request
                    var reference = response;
                    $location.path('/request/requestReference/' + reference);

                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(err);
                });
        }
    }
})();

