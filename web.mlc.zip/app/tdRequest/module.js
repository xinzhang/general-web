﻿'use strict';

angular.module('app.tdRequest', [
    'ui.router',
    'ngResource'
])

.config(function ($stateProvider) {
    $stateProvider
       .state('app.directInvestment', {
           url: '/tdRequest/directInvestment',
           views: {
               "content@app": { 
                   controller: 'DirectInvestmentCtrl',
                   templateUrl: 'app/tdRequest/directInvestment.html',
                   controllerAs: 'vm'
               }
           },
           data: {
               title: 'TD Request Direct Investment'
           }
       })

    .state('app.ausmaqNegotiatedRateTermDays', {
        url: '/tdRequest/ausmaqNegotiatedRateTermDays',
        views: {
            "content@app": {
                controller: 'AusmaqNegotiatedRateTermDaysCtrl',
                templateUrl: 'app/tdRequest/ausmaqNegotiatedRateTermDays.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: 'Ausmaq Negotiated Rate Term Days'
        }
    })

    .state('app.ausmaqNegotiatedRateTermStandard', {
        url: '/tdRequest/ausmaqNegotiatedRateTermStandard',
        views: {
            "content@app": {
                controller: 'AusmaqNegotiatedRateTermStandardCtrl',
                templateUrl: 'app/tdRequest/ausmaqNegotiatedRateTermStandard.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: 'Ausmaq Negotiated Rate Term Standard'
        }
    })

    .state('app.clientRequest', {
        url: '/tdRequest/clientRequest',
        views: {
            "content@app": {
                controller: 'ClientRequestCtrl',
                templateUrl: 'app/tdRequest/clientRequest.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: 'Requests'
        }
    })

    .state('app.uploadTDS', {
        url: '/tdRequest/uploadTDS',
        views: {
            "content@app": {
                controller: 'UploadTDSCtrl',
                templateUrl: 'app/tdRequest/uploadTDS.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: 'Upload Term Deposit Term & Conditions Document'
        }
    })
});
