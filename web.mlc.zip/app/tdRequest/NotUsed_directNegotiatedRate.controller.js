﻿(function () {
    'use strict';

    angular.module('app').controller('DirectNegotiatedRateCtrl', DirectNegotiatedRateCtrl);

    DirectNegotiatedRateCtrl.$inject = ['$location', '$scope', '$stateParams', 'requestService', 'commonService', 'authService', '$q', 'notify', '$filter'];

    function DirectNegotiatedRateCtrl($location, $scope, $stateParams, requestService, commonService, authService, $q, notify, $filter) {

        var vm = this;
        vm.title = "Direct Negotiated Rate";
        vm.clientCode = '';

        vm.request = {
            requestReference: "",
            tdCustomisedAssetRateDataViewModel: {
            }
        };

         $('.popover-dismiss').popover({
             trigger: 'focus',
             html: 'true'
         });
        
         
        

        activate();

        function resetRequest() {
            vm.request.requestReference = '';
            vm.request.prodCode = '1';
            vm.request.adiCode = 'ANZ';
            vm.request.ProposedInvestmentAmount = '';
            vm.request.negotiatedRate = '';
            vm.tdCustomisedAssetRateDataViewModel = '';
            
            
        
        }

        ////////////////

        function activate() {
            vm.authentication = authService.authentication;

            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;

            $("#modalDirectNegotiatedRate").draggable({
                handle: ".modal-header"
            });
           
        };

        vm.showDNRRModal = function () {
            resetRequest();
            $('#modalDirectNegotiatedRate').modal('show');
        };        



        vm.createDirectNegotiatedRateRequest = function () {

            vm.request.requestReference = "";
            vm.request.submitDate = new Date();
            vm.request.completed = false;

            vm.request.userName = authService.authentication.userName;
            vm.request.clientCode = authService.authentication.tdOrgCode;
                        
            requestService.createDirectNegotiatedRateRequest(vm.request)
                .then(function (response) {
                    vm.requestList = response;
                    notify.showSuccess("Direct Negotiated Rate Request has been created successfully.");
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });

            $('#modalDirectNegotiatedRate').modal('hide');
        };

        vm.checkFrequencyCode = function (val) {
            if (vm.request.prodCode == undefined)
                return true;

            if (vm.request.prodCode <= 11)
                return (val != "");

            else if (vm.request.prodCode > 11)
                return (val == "");
        }

        vm.prodCodeChange = function () {
            if (vm.request.prodCode == undefined)
                return true;

            if (vm.request.prodCode <= 11)
                vm.request.frequencyCode = '';

            else if (vm.request.prodCode > 11)
                vm.request.frequencyCode = 'M';

        }
    }

})();
