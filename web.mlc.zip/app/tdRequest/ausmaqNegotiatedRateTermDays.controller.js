﻿(function () {
    'use strict';

    angular.module('app').controller('AusmaqNegotiatedRateTermDaysCtrl', AusmaqNegotiatedRateTermDaysCtrl);
 
    AusmaqNegotiatedRateTermDaysCtrl.$inject = ['$location', '$scope', '$stateParams', 'adiService', 'tdRequestService', 'commonService', 'authService', 'userClientAdminService', '$q', 'notify'];

    function AusmaqNegotiatedRateTermDaysCtrl($location, $scope, $stateParams, adiService, tdRequestService, commonService, authService, userClientAdminService, $q, notify) {

        var vm = this;

        vm.title = "Ausmaq Negotiated Rate - Term (Days)";

        //Displays message using data content (requried) 
        $('.popover-dismiss').popover({
            trigger: 'focus',
            html: 'true'
        });

        //Interest Pay Frequency
        vm.selectionInterestPaidFreq = [
           { "value": "AM", "text": "At Maturity" },
           { "value": "M", "text": "Monthly" },
           { "value": "Q", "text": "Quarterly" },
           { "value": "S", "text": "Semi-Annually" },
           { "value": "A", "text": "Annually" }
        ]
        $scope.selectedInterestPaidFreq = vm.selectionInterestPaidFreq[0];

        //AdiCodeList
        vm.selectionAdiCode = [];
        $scope.selectedAdiCode = '';

        $scope.tags = [];
        vm.currentCount = 0;
        
        vm.clientCode = '';

        vm.status = {
            isopen: false
        }

        vm.addAdiMode = true;

        
        //View model: tdTermDays
        vm.tdTermDays = {
            clientCode: '',
            selectedAdi: '', // Max 3 ADI
            termDays: '',
            amount: '',
            InterestPaidFreq: '',
            contactName: '',
            email: '',
            phone: '',
            notes: ''            
        }

        activate();

        // Max 3 ADI
        vm.addAdi = function () {
            //Enable addMode
            if ($scope.tags.length < 3)
                vm.addAdiMode = true;
            if (vm.addAdiMode && $scope.selectedAdiCode != "") {
                //New object
                var selectedAdiObj = { name: $scope.selectedAdiCode };
                selectedAdiObj.name = $scope.selectedAdiCode;
                //check existing ADI
                for (var i = 0; i < $scope.tags.length && $scope.tags[i].name !== selectedAdiObj.name; i++) { }
                //New ADI
                if ($scope.tags.length == i) {
                    $scope.tags.push(selectedAdiObj);
                    vm.currentCount = $scope.tags.length;
                }
                else {

                    //ADI already exists! Do nothing
                }
                // Reach to max ADI. Disable addMode
                if ($scope.tags.length >= 3)
                    vm.addAdiMode = false;

            }

        }

        function activate() {
            vm.authentication = authService.authentication;
            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;
            // Get user detail by default
            userClientAdminService.getUserDetails(vm.authentication.userName)
                .then(function (reponse) {
                    vm.tdTermDays.contactName = reponse.firstName.concat(' ', reponse.lastName);
                    vm.tdTermDays.email = reponse.email;
                    vm.tdTermDays.phone = reponse.phoneNumber;
                }, function (err) {
                    vm.message = commonService.showError(err);
                });

            adiService.getAdiCodeList()
                .then(function (reponse) {
                    vm.selectionAdiCode = reponse;
                }, function (err) {
                    vm.message = commonService.showError(err);
                });
        }

        vm.submitRequest = function () {
            //Convert object list to delimited comma string for ADI
            while ($scope.tags.length > 0) {
                vm.tdTermDays.selectedAdi += $scope.tags.pop().name;
                if ($scope.tags.length > 0)
                    vm.tdTermDays.selectedAdi += ",";
            }

            vm.tdTermDays.InterestPaidFreq = $scope.selectedInterestPaidFreq;
            vm.tdTermDays.clientCode = vm.clientCode;

            console.log('Submit Ausmaq rate term (days) request');

            tdRequestService.submitAusmaqRateTermDaysRequest(vm.tdTermDays)
                .then(function (response) {
                    var reference = response;
                    notify.showSuccess("Ausmaq Negotiated Rate Term (Days) Request is submitted successfully.");
                    // Redirect to request
                    $location.path('/request/requestReference/' + reference);
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(err);
                });

        }
        

    }

})();

