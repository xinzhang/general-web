﻿(function () {
    'use strict';

    angular.module('app').controller('DirectInvestmentCtrl', DirectInvestmentCtrl);
 
    DirectInvestmentCtrl.$inject = ['$location', '$scope', '$stateParams', 'adiService', 'tdRequestService', 'commonService', 'authService', 'userClientAdminService', '$q', 'notify'];

    function DirectInvestmentCtrl($location, $scope, $stateParams, adiService, tdRequestService, commonService, authService, userClientAdminService, $q, notify) {

        console.log('DirectInvestmentCtrl loaded');
        var vm = this;

        vm.title = "Client Negotiated Term Deposit";

        //Interest Pay Frequency
        //vm.selectionInterestPaidFreq = ['AM', 'M', 'Q', 'S', 'A'];
        vm.selectionInterestPaidFreq = [
            { "value": "AM", "text": "At Maturity" },
            { "value": "M", "text": "Monthly" },
            { "value": "Q", "text": "Quarterly" },
            { "value": "S", "text": "Semi-Annually" },
            { "value": "A", "text": "Annually" }
        ]
        $scope.selectedInterestPaidFreq = vm.selectionInterestPaidFreq[0].value;

        //AdiCodeList
        vm.selectionAdiCode = [];
        $scope.selectedAdiCode = '';

        vm.clientCode = '';

        vm.status = {
            isopen: false
        }


        $scope.offerExpiry = new Date();
               
        //tdDirectInv
        vm.tdDirectInv = {
            clientCode: '',
            selectedAdi: '',
            termDays: '',
            interestRate: '',
            amount: '',
            offerExpiry: new Date(),
            specialRateRef: '',
            InterestPaidFreq: '',
            contactName: '',
            email: '',
            phone: '',
            notes: ''
        }

        vm.toggleDropdown = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            vm.status.isopen = !vm.status.isopen;
        };

        activate();

        function activate() {
            vm.authentication = authService.authentication;
            

            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;

            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;
            // Get user detail by default
            userClientAdminService.getUserDetails(vm.authentication.userName)
                .then(function (reponse) {
                    vm.tdDirectInv.contactName = reponse.firstName.concat(' ', reponse.lastName);
                    vm.tdDirectInv.email = reponse.email;
                    vm.tdDirectInv.phone = reponse.phoneNumber;
                }, function (err) {
                    vm.message = commonService.showError(err);
                });


            adiService.getAdiCodeList()
                .then(function (reponse) {
                    vm.selectionAdiCode = reponse;
                    $scope.selectedAdiCode = vm.selectionAdiCode[0];
                }, function (err) {
                    vm.message = commonService.showError(err);
                });
        }

        vm.submitRequest = function () {
            // Hide temporary
            //vm.tdDirectInv.offerExpiry = $scope.offerExpiry;
            vm.tdDirectInv.InterestPaidFreq = $scope.selectedInterestPaidFreq;
            vm.tdDirectInv.selectedAdi = $scope.selectedAdiCode;
            vm.tdDirectInv.clientCode = vm.clientCode;
            console.log('submit direct negotiated investment request');

            tdRequestService.submitDirectInvestmentRequest(vm.tdDirectInv)
                .then(function (response) {
                    var reference = response;
                    notify.showSuccess("Client Negotiated Term Deposit Request is submitted successfully.");
                    // Redirect to request
                    var reference = response;
                    $location.path('/request/requestReference/' + reference);

                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(err);
                });
        }
        //datetime picker
        vm.opened = false;
        vm.open = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            vm.opened = true;
        };

    }

})();

