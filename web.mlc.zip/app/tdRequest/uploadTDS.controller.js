﻿(function () {
    'use strict';

    angular.module('app').controller('UploadTDSCtrl', UploadTDSCtrl);

    UploadTDSCtrl.$inject = ['$location', '$scope', '$stateParams', 'localStorageService', 'termdepositService', 'tdRequestService', 'commonService', 'authService', '$q', 'notify', 'FileUploader'];

    function UploadTDSCtrl($location, $scope, $stateParams, localStorageService, termdepositService, tdRequestService, commonService, authService, $q, notify, FileUploader) {

        var vm = this;

        vm.title = "Upload Term Deposit Term & Conditions Document";

        vm.clientCode = '';

        //Call direct api Relay controller to access ressourceServer without using $hhtp.post       
        var authData = 'Bearer ' + localStorageService.get('authorisationData').token;
        vm.uploader = new FileUploader({
            url: "api/relay",
            headers: {
                Authorization: authData,
                uploadCategory: "adi"
            }
        });

        vm.uploader.filters.push({
            name: 'documentFilter',
            fn: function (item /*{File|FileLikeObject}*/, options) {
                var type = '|' + item.name.slice(item.name.lastIndexOf('.') + 1).toLowerCase() + '|';
                return '|xml|csv|txt|doc|docx|pdf|xls|xlsx|jpg|png|jpeg|bmp|zip|rar|'.indexOf(type) !== -1;
            }
        });

        vm.fileUploaded = false;

        vm.status = {
            isopen:false
        }

        $scope.effectiveDate = new Date();

        vm.tdsRequest = {
            effectiveDate: '',
            documentDescription: "",

            serverFilePath: "",
            localFileName: ""
        }

        vm.toggleDropdown = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            vm.status.isopen = !vm.status.isopen;
        };

        activate();

        function activate() {
            vm.authentication = authService.authentication;

            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;

            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;

            termdepositService.getPreviousAssetRates(vm.clientCode)
                .then(function (response) {
                    vm.assetRates = response;
                }, function (err) {
                    vm.message = commonService.showError(err);
                });            
        }

        vm.submitRequest = function () {
            vm.tdsRequest.effectiveDate = $scope.effectiveDate;
            console.log('submit request');

            tdRequestService.submitAdiDocumentRequest(vm.tdsRequest)
                .then(function (response) {
                    notify.showSuccess("Document Request are submitted successfully.");
                    var reference = response;
                    $location.path('/request/requestReference/' + reference);
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(err);
                });
        }

        //datetime picker
        vm.opened = false;
        vm.open = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            vm.opened = true;
        };

        // CALLBACKS
        vm.uploader.onSuccessItem = function (fileItem, response, status, headers) {
            console.info('onSuccessItem', fileItem, response, status, headers);
        };
        vm.uploader.onErrorItem = function (fileItem, response, status, headers) {
            notify.showError("File upload errr." + status);
        };
        vm.uploader.onCancelItem = function (fileItem, response, status, headers) {
            console.info('onCancelItem', fileItem, response, status, headers);
        };
        vm.uploader.onCompleteItem = function (fileItem, response, status, headers) {
            
            notify.showSuccess("File upload success.");
            vm.tdsRequest.serverFilePath = response.fileNames[0];
            vm.tdsRequest.localFileName = response.names[0];
            
        };

        vm.uploader.onCompleteAll = function () {
            vm.fileUploaded = true;
        };

        vm.uploader.onBeforeUploadItem = function (item) {
            console.log(item);
            if (vm.uploader.queue.length > 1)
            {
                notify.showWarning('you can only upload one document for Term deposit statement');
                //Remove item from UI
                item.remove();
                //Remove item from the queue.
                vm.uploader.queue.cancelItem(item);
            }

         }; 
    }
})();
