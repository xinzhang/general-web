﻿(function () {
    'use restrict';

    angular.module('app').factory('distributionChartService', distributionChartService);

    distributionChartService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function distributionChartService($http, $q, $rootScope, ngSettings) {
        var serviceBase = ngSettings.appServiceBaseUri;

        //private methods
        var _getDistributionOutstandingCount = function () {
            var deferred = $q.defer();
            // Call API DistributionController
            var serviceAddress = serviceBase + "api/distribution/getoutstandingcount/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        }

        var _getDistributionOutstandingByCatogry = function (category) {
            var deferred = $q.defer();
            // Call API DistributionController 
            $http.get(serviceBase + "api/distribution/getoutstandingbycategory/" + category, { header: { 'Content-Type': 'application/json' } })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        var _getDistributionForecastCount = function () {
            var deferred = $q.defer();
            // Call API DistributionController
            var serviceAddress = serviceBase + "api/distribution/getforecastcount/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        }

        var _getDistributionForecastByCatogry = function (category) {
            var deferred = $q.defer();
            // Format category for routing
            var category = category.replace(/[/]/g, '-');
            
            // Call API DistributionController 
            $http.get(serviceBase + "api/distribution/getforecastbycategory/" + category, { header: { 'Content-Type': 'application/json' } })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        var _getDistributionManagementCount = function () {
            var deferred = $q.defer();
            // Call API DistributionController
            var serviceAddress = serviceBase + "api/distribution/getmanagementcount/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        }

        var _getDistributionManagementByCatogry = function (category, name) {
            var deferred = $q.defer();
            // Call API DistributionController
            var serviceAddress = serviceBase + "api/distribution/getmanagementbycategory/" + category + "/" + name;
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        }

        return {
            getDistributionOutstandingCount: _getDistributionOutstandingCount,
            getDistributionOutstandingByCatogry: _getDistributionOutstandingByCatogry,
            getDistributionForecastCount: _getDistributionForecastCount,
            getDistributionForecastByCatogry: _getDistributionForecastByCatogry,
            getDistributionManagementCount: _getDistributionManagementCount,
            getDistributionManagementByCatogry: _getDistributionManagementByCatogry
        }
    }

})();