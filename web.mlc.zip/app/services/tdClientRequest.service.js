﻿(function () {
    'use restrict'

    angular.module('app').factory('tdClientRequestService', tdClientRequestService);

    tdClientRequestService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function tdClientRequestService($http, $q, $rootScope, ngSettings) {
        var serviceBase = ngSettings.appServiceBaseUri;

        //private methods
        var _submitDirectInvestmentRequest = function (directInvestmentRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDClientRequest/CreateDirectInvestmentRequest/";

            $http.post(serviceAddress, directInvestmentRequest, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };
        
        //SubmitAusmaqRateTermDaysRequest
        var _submitAusmaqRateTermDaysRequest = function (tdAusmaqRateTermDaysRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDClientRequest/CreateAusmaqRateTermDaysRequest/";

            $http.post(serviceAddress, tdAusmaqRateTermDaysRequest, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //SubmitAusmaqRateTermStandardRequest
        var _submitAusmaqRateTermStandardRequest = function (tdAusmaqRateTermStandardRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDClientRequest/CreateAusmaqRateTermStandardRequest/";


            $http.post(serviceAddress, tdAusmaqRateTermStandardRequest, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //public methods
        return {
            submitDirectInvestmentRequest: _submitDirectInvestmentRequest,
            submitAusmaqRateTermDaysRequest: _submitAusmaqRateTermDaysRequest,
            submitAusmaqRateTermStandardRequest: _submitAusmaqRateTermStandardRequest
       };

    };

})();

