﻿(function () {
    'use restrict';

    angular.module('app').factory('notify', notifyService);

    function notifyService() {
        toastr.options = {
            "debug": false,
            "positionClass": "toast-bottom-full-width",
            "onclick": null,
            "fadeIn": 300,
            "fadeOut": 1000,
            "timeOut": 5000,
            "extendedTimeOut": 1000
        }

        var _showError = function (message) {
            toastr.error(message);
        }

        var _showSuccess = function (message) {
            toastr.success(message);
        }
        var _showWarning = function (message) {
            toastr.warning(message);
        }

        return {
            showError: _showError,
            showSuccess: _showSuccess,
            showWarning: _showWarning

        }
    }


})();