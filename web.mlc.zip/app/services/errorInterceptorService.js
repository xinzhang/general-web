﻿(function () {
    'use strict';

    // Intercept http calls.
    angular.module('app').factory('errorInterceptorService', function ($q) {
        var errorCounter = 0;
        function notifyError(rejection) {

            var errorMessage = "Unknown Error";

            if (rejection.data.exceptionMessage)
            {
                errorMessage = rejection.data.exceptionMessage;
            }

            $.bigBox({
                title: rejection.status + ' ' + rejection.statusText,
                content: errorMessage,
                color: "#C46A69",
                icon: "fa fa-warning shake animated",
                number: ++errorCounter,
                timeout: 6000
            });
        }

        return {
            // On request failure
            requestError: function (rejection) {
                // show notification
                notifyError(rejection);

                // Return the promise rejection.
                return $q.reject(rejection);
            },

            // On response failure
            responseError: function (rejection) {
                // show notification
                notifyError(rejection);
                // Return the promise rejection.
                return $q.reject(rejection);
            }
        };
    });


})();
