﻿(function () {
    'use strict';

    angular.module('app').factory('authInterceptorService', authInterceptorService);

    authInterceptorService.$inject = ['$q', '$location', 'localStorageService', 'ngSettings'];

    function authInterceptorService($q, $location, localStorageService, ngSettings) {
        var authServiceBaseUri = ngSettings.authServiceBaseUri;
        var appServiceBaseUri = ngSettings.appServiceBaseUri;
        var proxyAddress = ngSettings.proxyAddress;
        var proxyEnabled = ngSettings.proxyEnabled;
        var authInterceptorServiceFactory = {};

        var _request = function (config) {


            config.headers = config.headers || {};
            //Use locaStorageService
            var authData = localStorageService.get('authorisationData');

            if (authData) {
                config.headers.Authorization = 'Bearer ' + authData.token;
            }

            if (
                (proxyEnabled === '1')
                &&
                (config.url.indexOf(authServiceBaseUri || '') !== -1
                || config.url.indexOf(appServiceBaseUri || '') !== -1)
                ) {

                config.headers.DestUrl = config.url;
                config.url = proxyAddress;
            }

            return config;
        }

        var _responseError = function (rejection) {
            //as long as the 401 is received, then retured to home login page
            // this is disabled
            if (rejection.status === 401) {
                //$location.path('/home');
            }
            return $q.reject(rejection);
        }

        authInterceptorServiceFactory.request = _request;
        authInterceptorServiceFactory.responseError = _responseError;

        return authInterceptorServiceFactory;
    }
})();