﻿(function () {
    'use restrict'

    angular.module('app').factory('termdepositService', termdepositService);

    termdepositService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function termdepositService($http, $q, $rootScope, ngSettings) {
        var serviceBase = ngSettings.appServiceBaseUri;

        //private methods

        // Commented out temporary

        var _getPreviousAssetRates = function (adiCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/tdAssetRate/PreviousRates/" + adiCode;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _getTodaysAssetRates = function (adiCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/tdAssetRate/TodaysRates/" + adiCode;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _saveAssetRates = function (assetRates) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/tdAssetRate/SaveRates/";

            $http.post(serviceAddress, assetRates, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _deleteAssetRatesForToday = function (adiCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/tdAssetRate/DeleteAssetRatesForToday/?adiCode=" + adiCode;
            
            $http.delete(serviceAddress).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _getClientLatestAssetRates = function (clientCode) {
            var deferred = $q.defer();

            console.log('termdeposit service loaded');

            var serviceAddress = serviceBase + "api/tdAssetRate/GetClientLatestAssetRates/" + clientCode;

            console.log('Service address: ' + serviceAddress);

            $http.get(serviceAddress).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _getAssetRateHistory = function (assetNo) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/tdAssetRate/GetAssetRateHistory/" + assetNo;

            $http.get(serviceAddress).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _submitAssetRates = function (assetRates) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/tdAssetRate/SubmitRates/";

            $http.post(serviceAddress, assetRates, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _getCommonAssets = function (clientCode, adiList) {
            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/tdAssetRate/GetCommonAsset/" + clientCode + "/" + adiList;

            $http.get(serviceAddress).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        var _checkPreviousPendingRates = function (adiCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/tdAssetRate/CheckPreviousPendingRates/" + adiCode;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        var _deletePreviousPendingAssetRates = function (adiCode) {

            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/tdAssetRate/DeletePreviousPendingAssetRates/?adiCode=" + adiCode;

            $http.delete(serviceAddress).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

        }

        //public methods
        return {
            getPreviousAssetRates: _getPreviousAssetRates,
            getTodaysAssetRates: _getTodaysAssetRates,
            saveAssetRates: _saveAssetRates,
            deleteAssetRatesForToday: _deleteAssetRatesForToday,
            getClientLatestAssetRates: _getClientLatestAssetRates,
            getAssetRateHistory: _getAssetRateHistory,
            submitAssetRates: _submitAssetRates,
            getCommonAssets: _getCommonAssets,
            checkPreviousPendingRates: _checkPreviousPendingRates,
            deletePreviousPendingAssetRates: _deletePreviousPendingAssetRates
        };

    };



})();

