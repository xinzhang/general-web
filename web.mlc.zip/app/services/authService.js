﻿(function () {
    'use restrict';

    angular.module('app').factory('authService', authService);

    
    authService.$inject = ['$http', '$q', '$rootScope', 'localStorageService', 'ngSettings', 'cryptService'];

    function authService($http, $q, $rootScope, localStorageService, ngSettings, crypt) {
        
        var _authentication = {
            isAuth: false,
            isProductManagement: false,
            isClient: false,
            isTermDeposit: false,
            userName: "",
            userId: "",
            adiCode: "",
            tdOrgCode: "",
            roleName: "", //Tam
        }
          
        var authData = localStorage.getItem('authorisationData');        
        var permissionString = localStorage.getItem('permissions');
        if (permissionString != null)
            _authentication = crypt.decrypt(permissionString);

        var serviceBase = ngSettings.authServiceBaseUri;

        console.log('ngSettings.authServiceBaseUri: ' + serviceBase);

        var _token = function (userName, password, rememberme) {
            var encodedPassword = crypt.encode(password);
            var data = "grant_type=password&username=" + userName + "&password=" + encodedPassword;

            console.log('_token.data:');
            console.log(data);

            var deferred = $q.defer();
           

            $http.post(serviceBase + 'token', data, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },

            }).success(function (response) {                
                _authentication.isAuth = true;

                _authentication.userName = userName;
                _authentication.useRefreshTokens = rememberme;
                _authentication.isClient = (response.isClient == "True");
                _authentication.isProductManagement = (response.isProductManagement == "True");
                _authentication.isTermDeposit = (response.isTermDeposit == "True");
                _authentication.adiCode = response.adiCode;
                _authentication.tdOrgCode = response.tdOrgCode;

                _authentication.isAdmin = (response.roleName === "Admin");
                _authentication.isAuthorise = (response.roleName === "Authorise");
                _authentication.isStandard = (response.roleName === "Standard");

                //encryption the result
                var authString = crypt.encrypt(_authentication);

                localStorageService.set('authorisationData', {
                    token: response.access_token,
                    refreshToken: "", //not used yet
                    useRefreshTokens: false
                });

                localStorage.setItem('permissions', authString);
                
                $rootScope.$broadcast('authentication.event', _authentication);

                deferred.resolve(response);
            }).error(function (err) {
                deferred.reject(err);
            });

            return deferred.promise;
        }

        var _logout = function () {
            _authentication.isAuth = false;
            _authentication.userName = "";
            localStorageService.remove('authorisationData');
            localStorageService.remove('permissions');

            $rootScope.$broadcast('authentication.event', _authentication);
        }
        
        //Tam:
        //This function allows the users to reset their passwords
        var _userResetPassword = function (userName, email) {

            var data = {
                userName: userName,
                email: email,
            };
            var deferred = $q.defer();
            $http.post(serviceBase + 'api/Account/UserResetPassword', data, { headers: { 'Content-Type': 'application/json' } })
                .success(function (response) {
                    deferred.resolve(response);
                    console.log(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        }

        return {
            authentication: _authentication,
            token: _token,
            logout: _logout,
            userResetPassword: _userResetPassword,
        }

    }
})();