﻿(function () {
    'use restrict'

    angular.module('app').factory('reportService', reportService);

    reportService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function reportService($http, $q, $rootScope, ngSettings) {
        var serviceBase = ngSettings.appServiceBaseUri;

        //private methods
        var _getReports = function () {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/rptDownload/list";

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;

        };

        var _getReportByName = function (name) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/rptDownload/data/?ReportName=" + name;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json', accept:'application/text' } })
                .success(function (response) {                    
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };
        
        //public method
        return {
            getReports: _getReports,
            getReportByName: _getReportByName
       };

    };

})();

