﻿(function () {
    'use restrict'

    angular.module('app').factory('tdRequestService', tdRequestService);

    tdRequestService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function tdRequestService($http, $q, $rootScope, ngSettings) {

        var serviceBase = ngSettings.appServiceBaseUri;

        //private methods from requestService
        var _getRequestList = function (clientCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDRequest/List/" + clientCode;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _submitAdiDocumentRequest = function (adiDocRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDRequest/SubmitAdiDocument/";

            $http.post(serviceAddress, adiDocRequest, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };
        
        var _getRequestDetailByReference = function (clientCode, reference) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDRequest/GetRequestDetailByReference/" + clientCode + "/" + reference;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _createDirectNegotiatedRateRequest = function (request) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDRequest/CreateDirectNegotiatedRateRequest/";

            $http.post(serviceAddress, request, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _submitDirectNegotiatedRate = function (request) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDRequest/SubmitDirectNegotiatedRate/";

            $http.post(serviceAddress, request, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };
        
        //private methods from tdClientRequestService
        var _submitDirectInvestmentRequest = function (directInvestmentRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDClientRequest/CreateDirectInvestmentRequest/";

            $http.post(serviceAddress, directInvestmentRequest, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //SubmitAusmaqRateTermDaysRequest
        var _submitAusmaqRateTermDaysRequest = function (tdAusmaqRateTermDaysRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDClientRequest/CreateAusmaqRateTermDaysRequest/";

            $http.post(serviceAddress, tdAusmaqRateTermDaysRequest, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //SubmitAusmaqRateTermStandardRequest
        var _submitAusmaqRateTermStandardRequest = function (tdAusmaqRateTermStandardRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDClientRequest/CreateAusmaqRateTermStandardRequest/";


            $http.post(serviceAddress, tdAusmaqRateTermStandardRequest, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };
        //public methods
        return {
            //From requestService
            getRequestList: _getRequestList,
            submitAdiDocumentRequest: _submitAdiDocumentRequest,
            getRequestDetailByReference: _getRequestDetailByReference,
            createDirectNegotiatedRateRequest: _createDirectNegotiatedRateRequest,
            submitDirectNegotiatedRate: _submitDirectNegotiatedRate,
            //From tdClientRequestService
            submitDirectInvestmentRequest: _submitDirectInvestmentRequest,
            submitAusmaqRateTermDaysRequest: _submitAusmaqRateTermDaysRequest,
            submitAusmaqRateTermStandardRequest: _submitAusmaqRateTermStandardRequest
       };

    };

})();

