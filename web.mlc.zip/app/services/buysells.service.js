﻿//This service used by buysells
(function () {
    'use restrict';

    angular.module('app').factory('buysellsService', buysellsService);

    buysellsService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function buysellsService($http, $q, $rootScope, ngSettings) {
        var serviceBase = ngSettings.appServiceBaseUri;
        var deffered = $q.defer();

        ////Tam: Mocking data for Daily Confirmation Position 
        //var dailyConfirmationPositionData = [
        //    { name: 'Expected', plan: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6'], count: [4, 6, 4, 0, 4, 3] },
        //    { name: 'Completed', plan: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6'], count: [12,10,16,14,10,18]},
        //]

        //private methods

        var _getOverdueData = function (clientCode) {

            var deferred = $q.defer();
            
            var serviceAddress = serviceBase + "api/buysells/getOverdue/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        //TN: Load data for Buy & Sell pie chart
        var _getBuySellsOverViewData = function (clientCode) {

            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getBuySellsOverView/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        var _getConfirmationForecastData = function (clientCode) {
            
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getConfirmationForecast/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }


        var _getDailyConfirmationPositionData = function (clientCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getDailyConfirmationPosition/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        //Old
        var _getUnbatchedOrderData = function (clientCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getUnbatchedOrdersDetail/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;            
        }
        //TN: New
        var _getUnbatchedOverviewData = function (clientCode) {
            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/buysells/getUnbatchedOverviewHeader/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        }

        //TN
        var _getUnbatchedDetailByCategory = function (type, invNo) {
            var deferred = $q.defer();

            var queryInvNO = "";
            if (invNo != undefined)
                queryInvNO = invNo

            

            //var serviceAddress = serviceBase + "api/buysells/getUnbatchedDetailByCategory/" + type + "/" + invNo;
            var serviceAddress = serviceBase + "api/buysells/getUnbatchedDetailByCategory/?type=" + type + "&invNo=" + queryInvNO;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
            

        }
        var _getOverdueDetail = function (buysells, age) {
            var deferred = $q.defer();

            console.log('get buysells overdue detail ' + encodeURI(age));
            var serviceAddress = serviceBase + "api/buysells/getOverdueDetail/" + buysells + "?category=" + encodeURI(age);

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;            
        }

        var _getDetailByCategory = function (category) {

            var deferred = $q.defer();

            console.log('get buysells overdue detail ' + encodeURI(category));
            
            var serviceAddress = serviceBase + "api/buysells/getDetailByCategory/" + category;//+ buysells + "?category=" + encodeURI(category);

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }
        //Tam:OrderRef
        var _getOrderByRef = function (orderRef){
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getOrdersByRef/" + orderRef;
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        var _getConfirmationForecastDetail = function (buysells, age) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getConfirmationForecastDetail/" + buysells + "/" + age;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        var _getDailyConfirmationPositionDetail = function (buysells, invName) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getDailyConfirmationPositionDetail/" + buysells + "/" + invName;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        //Virtual Cash
        var _getInvestorList = function () {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/GetInvestorList/";

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;

        }

        //Landing page
        var _getOverdueCount = function () {

            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getOverdueCount/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        var _getBuySellsCount = function (category) {
            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/buysells/getOverdueCount/?category=" + category;// + "&invNo=" + queryInvNO;
            //var serviceAddress = serviceBase + "api/buysells/getOverdueCount/" + category;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;

        }

        var _getUnbatchedOrderCount = function () {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getUnbatchedOrderCount/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        var _getDailyConfirmationPositionCount = function () {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/buysells/getDailyConfirmationPositionCount/";
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }
       
        return {
            //Old
            getOverdueData: _getOverdueData,
            //TN: New
            getBuySellsOverViewData: _getBuySellsOverViewData,
            getBuySellsCount: _getBuySellsCount,
            getDetailByCategory: _getDetailByCategory,
            getUnbatchedOverviewData: _getUnbatchedOverviewData,
            getUnbatchedDetailByCategory: _getUnbatchedDetailByCategory,

            getConfirmationForecastData: _getConfirmationForecastData,
            getDailyConfirmationPositionData: _getDailyConfirmationPositionData,
            //Old
            getUnbatchedOrderData: _getUnbatchedOrderData,
            getOverdueDetail: _getOverdueDetail,
            getOrderByRef: _getOrderByRef, //Tam:OrderRef
            getConfirmationForecastDetail: _getConfirmationForecastDetail,
            getDailyConfirmationPositionDetail: _getDailyConfirmationPositionDetail,
            //Virtual Cash
            getInvestorList: _getInvestorList,
            //Landing page
            getOverdueCount: _getOverdueCount,
            getUnbatchedOrderCount: _getUnbatchedOrderCount,
            getDailyConfirmationPositionCount: _getDailyConfirmationPositionCount,

        };

    };

})();

