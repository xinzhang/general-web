﻿(function () {
    'use restrict'

    angular.module('app').factory('adiService', adiService);

    adiService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function adiService($http, $q, $rootScope, ngSettings) {
        var serviceBase = ngSettings.appServiceBaseUri;

        //private methods
        var _getAdiCodeList = function () {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/TDAdi/List/";

            console.log('adiService._getAdiCodeList -> serviceAddress: ' + serviceAddress);

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        
        
        //public method
        return {
            getAdiCodeList: _getAdiCodeList
       };

    };

})();

