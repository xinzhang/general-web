﻿(function () {
    'use restrict';

    angular.module('app').factory('commonService', commonService);
    
    function commonService() {
        var _showError = function (err) {
            console.log('error returned');
            
            if (err.error_description)
                return err.error_description;

            else if (err.exceptionMessage)
                return err.exceptionMessage;

            else if (err.error)
                return err.error;

            else if (err.message)
                return err.message;

            else
                return "Unexpected error " + error.toString();
        }        

        var _showModalError = function (response, serviceId) {
            var errors = [];
            for (var key in response.modelState) {
                for (var i = 0; i < response.modelState[key].length; i++) {
                    errors.push(response.modelState[key][i]);
                }
            }
            return "Failed to " + serviceId + "due to:\n" + errors.join('\n');
        }

        return {
            showError: _showError,
            showModalError: _showModalError
        }
    }


})();