﻿(function () {
    'use restrict'

    angular.module('app').factory('mlcRequestService', mlcRequestService);

    mlcRequestService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function mlcRequestService($http, $q, $rootScope, ngSettings) {

        var serviceBase = ngSettings.appServiceBaseUri;

        //Off Book Trades
        //private methods 
        var _submitMlcOffBookTradesRequest = function (MlcOffBookTradesRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/MLCRequest/CreateMlcOffBookTradesRequest/";

            $http.post(serviceAddress, MlcOffBookTradesRequest, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _getLatestOffbookTrades = function (clientCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/MLCRequest/GetLatestOffbookTrades/" + clientCode;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;

        };

        var _authoriseMlcOffBookTradesRequest = function (MlcOffBookTradesRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/MLCRequest/AuthoriseMlcOffBookTradesRequest/";

            $http.post(serviceAddress, MlcOffBookTradesRequest, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _rejectMlcOffBookTradesRequest = function (mlcOffBookTradesRequest) {
            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/MLCRequest/RejectOffBookTradesRequest/";

            $http.post(serviceAddress, JSON.stringify(mlcOffBookTradesRequest), { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        //Asset Management
        var _submitMlcAssetManagementRequest = function (MlcAssetManagementRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/MLCRequest/CreateMlcAssetManagementRequest/";

            $http.post(serviceAddress, JSON.stringify(MlcAssetManagementRequest), { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //Hardship Withdrawal
        var _submitMlcHardshipWithdrawalRequest = function (MlcHardshipWithdrawalRequest) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/MLCRequest/CreateMlcHardshipWithdrawalRequest/";

            $http.post(serviceAddress, JSON.stringify(MlcHardshipWithdrawalRequest), { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //Virtual Cash
        var _getInvestorList = function() {
            var deferred = $q.defer();
            
            var serviceAddress = serviceBase + "api/buysells/GetInvestorList/";

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;

        };

        //Get existing records
        var _getExistingMlcVirtualCashRequest = function () {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/MLCRequest/GetSubmittedMlcVirtualCashRequest/";

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;

        };

        var _submitMlcVirtualCashRequest = function (mlcVirtualCashlRequest) {
            var deferred = $q.defer();
            console.log("submitMlcVirtualCashRequest");
            console.log(mlcVirtualCashlRequest);
            console.log(mlcVirtualCashlRequest.isAuth);
            var serviceAddress = serviceBase + "api/MLCRequest/CreateMlcVirtualCashRequest/";
            
            $http.post(serviceAddress, JSON.stringify(mlcVirtualCashlRequest), { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        
        var _authoriseMlcVirtualCashRequest = function (mlcVirtualCashlRequest) {
            var deferred = $q.defer();
            console.log("submitMlcVirtualCashRequest");
            console.log(mlcVirtualCashlRequest);
            console.log(mlcVirtualCashlRequest.isAuth);
            var serviceAddress = serviceBase + "api/MLCRequest/AuthoriseMlcVirtualCashRequest/";

            $http.post(serviceAddress, JSON.stringify(mlcVirtualCashlRequest), { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var _rejectMlcVirtualCashRequest = function (mlcVirtualCashlRequest) {
            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/MLCRequest/RejectMlcVirtualCashRequest/";

            $http.post(serviceAddress, JSON.stringify(mlcVirtualCashlRequest), { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        //Requests

        var _getLatestRequestStatus = function (clientCode, requestType) {

            var deferred = $q.defer();

            console.log(clientCode);

            var serviceAddress = serviceBase + "api/MLCRequest/GetLatestRequestStatus/" + clientCode + "/" + requestType;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        var _getRequestList = function (clientCode) {
            var deferred = $q.defer();

            console.log(clientCode);

            var serviceAddress = serviceBase + "api/MLCRequest/List/" + clientCode;

            console.log(serviceAddress);

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _getRequestDetailByReference = function (clientCode, reference) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/MLCRequest/GetRequestDetailByReference/" + clientCode + "/" + reference;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //Landing Page
        var _getLandingPageRequestList = function (clientCode) {
            var deferred = $q.defer();

            console.log("getLast30DaysRequestList" + clientCode);

            var serviceAddress = serviceBase + "api/MLCRequest/GetLandingPageRequestList/" + clientCode;

            console.log(serviceAddress);

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };
        //public methods
        return {
            //Off Book Trades
            submitMlcOffBookTradesRequest: _submitMlcOffBookTradesRequest,
            getLatestOffbookTrades: _getLatestOffbookTrades,
            authoriseMlcOffBookTradesRequest: _authoriseMlcOffBookTradesRequest,
            rejectMlcOffBookTradesRequest: _rejectMlcOffBookTradesRequest,

            //Asset Management
            submitMlcAssetManagementRequest: _submitMlcAssetManagementRequest,

            //Hardship Withdrawal
            submitMlcHardshipWithdrawalRequest: _submitMlcHardshipWithdrawalRequest,

            //Virtual Cash
            getInvestorList: _getInvestorList,
            submitMlcVirtualCashRequest: _submitMlcVirtualCashRequest,
            getExistingMlcVirtualCashRequest: _getExistingMlcVirtualCashRequest,
            authoriseMlcVirtualCashRequest: _authoriseMlcVirtualCashRequest,
            rejectMlcVirtualCashRequest: _rejectMlcVirtualCashRequest,

            //Requests
            getRequestList: _getRequestList,
            getRequestDetailByReference: _getRequestDetailByReference,
            getLatestRequestStatus: _getLatestRequestStatus,

            //Landing Page
            getLandingPageRequestList: _getLandingPageRequestList
       };

    };

})();

