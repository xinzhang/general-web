﻿(function () {
    'use restrict';

    angular.module('app').factory('businessDaysService', businessDaysService);

    function businessDaysService() {

        var _holidayFormat = 'YYYY-MM-DD';

        var _holidays = [
               // XZ - remove the holidays as not needed for now
               //'2016-04-25', '2016-06-16'
        ];

        var _isBusinessDay = function (d) {
            if (d.day() === 0 || d.day() === 6) return false;
            if (_isHoliday(d)) return false;
            return true;
        };

        var _isHoliday = function (d) {
            if (_holidays) {
                if (_holidays.indexOf(d.format(_holidayFormat)) >= 0) return true;
            }
            return false;
        };

        var _businessAdd = function (d, days) {
            var signal = days < 0 ? -1 : 1;
            var daysRemaining = Math.abs(days);
            
            while (daysRemaining) {
                d.add(signal, 'd');
                if (_isBusinessDay(d)) {
                    daysRemaining--;
                };
            };
            return d;
        };

        return {
            businessAdd: _businessAdd,
        }

    }


})();