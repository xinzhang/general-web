﻿(function () {
    'use restrict';

    angular.module('app').factory('servicePerformanceService', servicePerformanceService);

    servicePerformanceService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function servicePerformanceService($http, $q, $rootScope, ngSettings) {
        var serviceBase = ngSettings.appServiceBaseUri;
        var deffered = $q.defer();

        var performance = [
            { name: "Distribution", value: 0.8, location: "app.distribution" },
            { name: "Transfers", value: 0.2, location: "transferServicePerformance" },
            { name: "Security Recs", value: 0.4, location: "app.secRecs" },
            { name: "Rebates", value: 0.9, location: "app.rebates" },
            { name: "Buy & Sell Trades", value: 0.4, location: "app.buysells" },
            { name: "Tax Statements", value: 0.1, location: "app.tax" },
        ]

        //private methods
        var _getServicePerformance = function (clientCode) {
            return (performance);
        };


        // XZ return the graph counter
        var _getServiceOverview = function (service) {
            
            var deferred = $q.defer();
            // Format category for routing
            //var category = category.replace(/[/]/g, '-');

            // Call API DistributionController 
            $http.get(serviceBase + "api/servicePerformance/getServiceOverview/" + service, { header: { 'Content-Type': 'application/json' } })
            .success(function (response) {
                deferred.resolve(response);

                //console.log(response);
            })
            .error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        // return the graph details
        var _getServiceOverviewData = function (service, category) {

            var deferred = $q.defer();

            // Call API DistributionController 
            $http.get(serviceBase + "api/servicePerformance/getServiceDetails/" + service + "?category=" + encodeURI(category), { header: { 'Content-Type': 'application/json' } })
                .success(function (response) {
                    deferred.resolve(response);
            })
            .error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        // return the graph details
        var _getServiceDataByAPIR = function (service, apir) {

            var deferred = $q.defer();

            // Call API DistributionController 
            $http.get(serviceBase + "api/servicePerformance/getServiceDetailsAPIR/" + service + "/" +apir, { header: { 'Content-Type': 'application/json' } })
                .success(function (response) {
                    deferred.resolve(response);
                })
            .error(function (err) {
                deferred.reject(err);
            });
            return deferred.promise;
        }

        //TN: return details matched issuer criteria
        //var _getServiceDataByIssuer = function (service, issuer) {

        //    var deferred = $q.defer();

        //    // Call API DistributionController 
        //    $http.get(serviceBase + "api/servicePerformance/getServiceDetailsIssuer/" + service + "/" + issuer, { header: { 'Content-Type': 'application/json' } })
        //        .success(function (response) {
        //            deferred.resolve(response);
        //        })
        //    .error(function (err) {
        //        deferred.reject(err);
        //    });
        //    return deferred.promise;
        //}

        //TN: return details mathced wit apir and issuer criteria
        //var _getServiceDataByAPIRIssuer = function(service, apir, issuer)
        //{
        //    var deferred = $q.defer();

        //    // Call API DistributionController 
        //    $http.get(serviceBase + "api/servicePerformance/getServiceDetailsAPIRIssuer/" + service + "/" + apir + "/" + issuer, { header: { 'Content-Type': 'application/json' } })
        //        .success(function (response) {
        //            deferred.resolve(response);
        //        })
        //    .error(function (err) {
        //        deferred.reject(err);
        //    });
        //    return deferred.promise;
        //}

        //XZ: Return Fund Manager Performance Trending
        var _getFMPerformanceTrending = function (service) {
            var deferred = $q.defer();

            // Call API DistributionController 
            $http.get(serviceBase + "api/servicePerformance/getFMPerformanceTrending/" +service, { header: {'Content-Type': 'application/json' } })
                .success(function (response) {
                    deferred.resolve(response);
            })
            .error(function (err) {
                deferred.reject(err);
            });

            return deferred.promise;
        }

        //XZ: Return Distribution Processing Management Overview
        var _getProcessingManagementDaily = function (service) {
             var deferred = $q.defer();

            // Call API DistributionController 
                $http.get(serviceBase + "api/servicePerformance/getProcessingManagementDaily/" +service, {
                header: {'Content-Type' : 'application/json' } })
                    .success(function (response) {
                        deferred.resolve(response);
            })
                .error(function (err) {
                    deferred.reject(err);
            });

            return deferred.promise;
        }
        
        var _getServiceNote = function (service, id) {

             var deferred = $q.defer();
                 
            // Call API TraQNotes Controller 
            $http.get(serviceBase + "api/TraQNotes/" + service + "/" + id, {
                     header: {'Content-Type': 'application/json' }
            })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err) {
                deferred.reject(err);
            });

            return deferred.promise;
                }

        var _checkServiceNote = function (service, id) {

             var deferred = $q.defer();

            // Call API TraQNotes Controller 
            $http.get(serviceBase + "api/TraQNotesExist/" + service + "/" +id, {
                header: {
                    'Content-Type': 'application/json'
                }})
                .success(function (response) {
                    deferred.resolve(response);
                })
                .error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
            }

        //public methods
        return {
            getServicePerformance: _getServicePerformance,
            
            getServiceOverview: _getServiceOverview,            
            getFMPerformanceTrending: _getFMPerformanceTrending,
            getProcessingManagementDaily: _getProcessingManagementDaily,
            
            getServiceOverviewData: _getServiceOverviewData,
            getServiceDataByAPIR: _getServiceDataByAPIR,
            //getServiceDataByIssuer: _getServiceDataByIssuer,
            //getServiceDataByAPIRIssuer: _getServiceDataByAPIRIssuer,

            getServiceNote: _getServiceNote,
            checkServiceNote: _checkServiceNote
        };

    };

})();

