﻿(function () {
    'use restrict'

    angular.module('app').factory('userClientAdminService', userClientAdminService);

    userClientAdminService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function userClientAdminService($http, $q, $rootScope, ngSettings) {

        
        var serviceBase = ngSettings.authServiceBaseUri;

        //private methods
        var _getClientCodeList = function () {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/UserClient/clientCodeList/";

            console.log('serviceAddress: ' + serviceAddress)

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //private methods
        var _getUserList = function () {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/UserClient/userList/";

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //private method: used for userByClientAdmin
        var _getUserListByOrgCode = function (tdOrgCode) {

            console.log('_getUserListByOrgCode(tdOrgCode)');
            console.log(tdOrgCode)

            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/UserClient/userListByOrgCode/" + tdOrgCode;

            console.log('userClientAdminService._getUserListByOrgCode -> serviceAddress: ' + serviceAddress);

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {

                    deferred.resolve(response);

                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //private methods
        var _checkUserName = function (userName) {
            var deferred = $q.defer();
            
            //replace userName . with html encoded .
            //userName = userName.replace(".", "&middot;");// Tam: but still issue with Task<HttpResponseMessage> GetRelay() RelayController

            //userName = encodeURIComponent(userName);

            var serviceAddress = serviceBase + "api/UserClient/checkUserName/" + userName;
            //var serviceAddress = serviceBase + "api/UserClient/checkUserName?userName=" + encodeURI(userName);
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        // Save new user
        var _saveUser = function (userName,
                                  firstName,
                                  lastName,
                                  userEmail,
                                  password,
                                  clientCode,
                                  phoneNumber,
                                  selection){

            var data = {
                userName: userName,
                firstName: firstName,
                lastName: lastName,
                Email: userEmail,
                password: password,
                clientcode: clientCode,
                phoneNumber: phoneNumber,
                roleNames: selection,
            };

            

            var deferred = $q.defer();

            $http.post(serviceBase + "api/UserClient/createUser", data, { headers: { 'Content-Type': 'application/json' } }).success(function (response) {
                deferred.resolve(response);
            }).error(function (err) {
                console.log(' _saveUser err');
                console.log(err);
                deferred.reject(err);
            });

            return deferred.promise;
        };

        var _getUserDetails = function(userName)
        {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/UserClient/getUserDetails/" + userName;

            console.log('userClientAdminService._getUserDetails -> serviceAddress: ' + serviceAddress);

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {

                    deferred.resolve(response);

                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _updateUser = function (userName,
                                    firstName,
                                    lastName,
                                    userEmail,
                                    clientCode,
                                    phoneNumber,
                                    selection,
                                    active){
            var data = {
                userName: userName,
                firstName: firstName,
                lastName: lastName,
                Email: userEmail,
                clientcode: clientCode,
                phoneNumber: phoneNumber,
                roleNames: selection,
                active: active
            };

            var deferred = $q.defer();

            $http.post(serviceBase + "api/UserClient/updateUser", data, { headers: { 'Content-Type': 'application/json' } }).success(function (response) {
                deferred.resolve(response);
            }).error(function (err) {
                deferred.reject(err);
            });

            return deferred.promise;
        };
        //Tam:resetPassword uses by ausmaq and admin role.
        var _resetPassword = function (userName, password, email, clientCode) {

            var data = {
                userName: userName,
                password: password,
                email: email,
                clientCode: clientCode
            };

            var deferred = $q.defer();
                                                    
            $http.post(serviceBase + "api/UserClient/resetPassword", data, { headers: { 'Content-Type': 'application/json' } }).success(function (response) {
                deferred.resolve(response);
            }).error(function (err) {
                deferred.reject(err);
            });

            return deferred.promise;
        };

        //Tam: only for users
        var _changePassword = function (userName, password) {

            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/UserClient/changePassword/" + userName + "/" + password;

            $http.post(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {

                    deferred.resolve(response);

                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        var _updateActivityDate = function(userName)
        {
            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/UserClient/updateActivityDate/" + userName;

            $http.post(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {

                    deferred.resolve(response);

                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }


        //Check existing password (old password)
        var _validatePassword = function (userName, password) {

            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/UserClient/checkPassword/" + userName + "/" + password;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {

                    deferred.resolve(response);

                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;


        };

        //Check history passwords (noOfRec = 9 latest password)
        var _checkHistoryPassword = function (userName, password, noOfRec) {

            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/UserClient/checkHistoryPasswords/" + userName + "/" + password + "/" + noOfRec;
            
            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {

                    deferred.resolve(response);

                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        //Check if password expires 45 days
        var _checkExpire = function (userName) {

            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/UserClient/checkExpire/" + userName;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {

                    deferred.resolve(response);

                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        //Check if first time user log in
        var _checkFirstTime = function (userName) {

            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/UserClient/checkFirstTime/" + userName;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {

                    deferred.resolve(response);

                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        //Check if account is active
        var _checkActive = function (userName) {

            var deferred = $q.defer();
            var serviceAddress = serviceBase + "api/UserClient/checkActive/" + userName;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {

                    deferred.resolve(response);

                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        //private methods
        var _getClientList = function () {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/UserClient/clientList/";

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        //private methods
        var _checkClientCode = function (clientCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/UserClient/checkClientCode/" + clientCode;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };
        
        // Save new client
        var _saveClient = function (clientCode,
                                    name,
                                    active,
                                    isTermDeposit,
                                    contactName,
                                    contactPhone,
                                    contactEmail,
                                    addedBy,
                                    isClient,
                                    isProductManagement) {

            var data = {
                clientCode: clientCode,
                name: name,
                active: active,
                isTermDeposit: isTermDeposit,
                contactName: contactName,
                contactPhone: contactPhone,
                contactEmail: contactEmail,
                addedBy: addedBy,
                isClient: isClient,
                isProductManagement: isProductManagement
            };

            var deferred = $q.defer();

            $http.post(serviceBase + "api/UserClient/createClient", data, { headers: { 'Content-Type': 'application/json' } }).success(function (response) {
                deferred.resolve(response);
            }).error(function (err) {
                deferred.reject(err);
            });

            return deferred.promise;
        };

        var _getClientDetails = function (clientCode) {
            var deferred = $q.defer();

            var serviceAddress = serviceBase + "api/UserClient/getClientDetails/" + clientCode;

            $http.get(serviceAddress, { headers: { 'Content-Type': 'application/json' } }).
                success(function (response) {
                    deferred.resolve(response);
                }).error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        };

        var _updateClient = function (clientCode,
                                      name,
                                      active,
                                      isTermDeposit,
                                      contactName,
                                      contactPhone,
                                      contactEmail,
                                      addedBy,
                                      isClient,
                                      isProductManagement) {

            var data = {
                clientCode: clientCode,
                name: name,
                active: active,
                isTermDeposit: isTermDeposit,
                contactName: contactName,
                contactPhone: contactPhone,
                contactEmail: contactEmail,
                addedBy: addedBy,
                isClient: isClient,
                isProductManagement: isProductManagement
            };

            var deferred = $q.defer();

            $http.post(serviceBase + "api/UserClient/updateClient", data, { headers: { 'Content-Type': 'application/json' } }).success(function (response) {
                deferred.resolve(response);
            }).error(function (err) {
                //console.log(err);
                deferred.reject(err);
            });

            return deferred.promise;
        };

        //public methods
        return {
            // User
            getClientCodeList: _getClientCodeList,
            getUserList: _getUserList,
            saveUser: _saveUser,
            checkUserName: _checkUserName,
            getUserDetails: _getUserDetails,
            updateUser: _updateUser,
            resetPassword: _resetPassword,
            //Tam:Added
            getUserListByOrgCode: _getUserListByOrgCode,
            validatePassword: _validatePassword,
            checkHistoryPassword: _checkHistoryPassword,
            changePassword: _changePassword,
            updateActivityDate: _updateActivityDate,
            checkExpire: _checkExpire,
            checkFirstTime: _checkFirstTime,
            checkActive: _checkActive,
            // Client
            getClientList: _getClientList,
            checkClientCode: _checkClientCode,
            saveClient: _saveClient,
            getClientDetails: _getClientDetails,
            updateClient: _updateClient,
        };
    };
})();

