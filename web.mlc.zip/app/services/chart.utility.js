﻿(function () {
    'use restrict';

    angular.module('app').factory('chartUtility', chartUtility);

    function chartUtility() {

        var buildCategoryCounts = function (countArray, dataArray) {
            if (countArray == undefined) {
                countArray = [];
            }


            for (var i = 0; i < dataArray.length; i++) {
                var currValue = dataArray[i];
                var found = false;
                for (var j = 0; j < countArray.length; j++) {
                    if (countArray[j][0] == currValue) {
                        found = true;
                        var newCount = countArray[j][1];
                        countArray[j][1] = newCount + 1;
                    }
                }
                if (!found) {
                    countArray.push([currValue, 1]);
                }
            }
            return countArray;
        },

        loadPieChart = function (countArray, divId, chartTitle, customClickEvent) {
            //Build Pie Chart
            Highcharts.setOptions({
            })
            $(divId).highcharts({
                chart: {
                    backgroundColor: '#ffffff',
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false
                },
                credits: {
                    enabled: false
                },
                title: {
                    text: chartTitle
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.y}</b>',
                    percentageDecimals: 0
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '{point.name}'
                        },
                        showInLegend: true
                    }
                },

                legend: {
                    labelFormat: '{name}: <b>{y}</b>',
                    itemStyle: {
                        color: '#000'
                    },
                    itemHoverStyle: {
                        color: '#FFF'
                    },
                    itemHiddenStyle: {
                        color: '#333'
                    }
                },
                series: [{
                    type: 'pie',
                    name: chartTitle,
                    data: countArray,
                    events: {
                        click: customClickEvent
                    },
                }]
            });
        },

        loadBarChart = function (xCategories, seriesData, divId, chartTitle, yAxisTitle) {
            //Build Bar Chart
            $(divId).highcharts({
                chart: {
                    backgroundColor: '#ffffff',
                    type: 'bar'
                },
                credits: {
                    enabled: false
                },
                title: {
                    text: chartTitle
                },
                xAxis: {
                    categories: xCategories
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: yAxisTitle
                    }
                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    bar: {
                        dataLabels: {
                            enabled: true,
                            color: '#000',
                            format: '<b>{y}</b>'
                        }
                    },
                    series: {
                        animation: false
                    }
                },
                series: [{
                    name: yAxisTitle,
                    data: seriesData,
                    events: {
                        click: function (event) {
                        }
                    }
                }]
            });
        },

        loadColumnChart = function (xCategories, seriesData, divId, chartTitle, yAxisTitle, customClickEvent) {
            //Build Bar Chart
            $(divId).highcharts({
                chart: {
                    backgroundColor: '#ffffff',
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'column'
                },
                credits: {
                    enabled: false
                },
                title: {
                    text: chartTitle
                },
                xAxis: {
                    categories: xCategories,
                    labels: {
                        rotation: -45
                    }
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: yAxisTitle
                    }
                },
                legend: {
                    enabled: false
                },

                plotOptions: {
                    column: {
                        dataLabels: {
                            enabled: true,
                            rotation: -90,
                            y: 8, // 8 pixels down from the top
                            color: '#000',
                            format: '<b>{y}</b>'
                        }
                    },
                    series: {
                        animation: false
                    }
                },

                series: [{
                    name: yAxisTitle,
                    data: seriesData,
                    events: {
                        click: customClickEvent
                    },
                }]
            });
        },

        loadStackedColumnChart = function (xCategories, seriesData, divId, chartTitle, yAxisTitle, customClickEvent) {
            //Build Stacked Column Chart            
            $(divId).highcharts({
                chart: {
                    backgroundColor: '#ffffff',
                    type: 'column'
                },
                credits: {
                    enabled: false
                },
                title: {
                    text: chartTitle
                },
                xAxis: {
                    categories: xCategories
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: yAxisTitle
                    }
                },

                tooltip: {
                    pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
                    shared: true
                },
                plotOptions: {
                    column: {
                        stacking: 'percent',
                        dataLabels: {
                            enabled: true,
                            color: '#000',
                            format: '<b>{y}</b>'
                        }
                    }
                },

                legend: {
                    itemStyle: {
                        color: '#000'
                    },
                    itemHoverStyle: {
                        color: '#FFF'
                    },
                    itemHiddenStyle: {
                        color: '#333'
                    }
                },
                series: seriesData
            });
        },

        loadStackedBarChart = function (xCategories, seriesData, divId, chartTitle, yAxisTitle) {
            //Build Stacked Bar Chart
            $(divId).highcharts({
                chart: {
                    backgroundColor: '#ffffff',
                    type: 'bar'
                },
                credits: {
                    enabled: false
                },
                title: {
                    text: chartTitle
                },
                xAxis: {
                    categories: xCategories
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: yAxisTitle
                    }
                },
                legend: {
                    reversed: true,
                },

                plotOptions: {
                    bar: {
                        dataLabels: {
                            enabled: true,
                            color: '#000',
                            format: '<b>{y}</b>'
                        }
                    },
                    series: {
                        animation: false,
                        stacking: 'normal',
                        events: {
                            click: function (event) {
                            }
                        }
                    }
                },
                series: seriesData
            });
        },

        drawRateCharts = function (historiesArray) {

            console.log('chartUtility Here');
            var histEndDate = historiesArray[historiesArray.length - 1].dateTimeAdded;
            var histStartDate = historiesArray[0].dateTimeAdded;

            console.log('historiesArray');

            var seriesData = [];

            for (var i = 0; i < historiesArray.length - 1; i++) {

                seriesData[i] = [];
                seriesData[i][0] = historiesArray[i].dateTimeAdded;
                seriesData[i][1] = historiesArray[i].intRate;

                console.log(seriesData[i][0]);
            }

            console.log('chartUtility start #container');


            $('#container').highcharts({
                chart: {
                    zoomType: 'x'
                },
                title: {
                    text: 'interest rate through now'
                },
                subtitle: {
                    text: document.ontouchstart === undefined ?
                            'Click and drag in the plot area to zoom in' :
                            'Pinch the chart to zoom in'
                },
                xAxis: {
                    type: 'datetime',
                    dateTimeLabelFormats: { // don't display the dummy year
                        month: '%e. %b',
                        year: '%b'
                    },
                    title: {
                        text: 'Date'
                    }
                },
                yAxis: {
                    title: {
                        text: 'Interest rate'
                    }
                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    area: {
                        fillColor: {
                            linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                            stops: [
                                [0, Highcharts.getOptions().colors[0]],
                                [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                            ]
                        },
                        marker: {
                            radius: 2
                        },
                        lineWidth: 1,
                        states: {
                            hover: {
                                lineWidth: 1
                            }
                        },
                        threshold: null
                    }
                },

                series: [{
                    type: 'area',
                    name: 'intrest',
                    data: seriesData
                }]
            });
        }

        return {
            buildCategoryCounts: buildCategoryCounts,
            loadPieChart: loadPieChart,
            loadBarChart: loadBarChart,
            loadStackedBarChart: loadStackedBarChart,
            loadColumnChart: loadColumnChart,
            loadStackedColumnChart: loadStackedColumnChart,
            drawRateCharts: drawRateCharts
        }
    }

})();