﻿//This service used by buysells
(function () {
    'use restrict';

    angular.module('app').factory('noteService', noteService);

    noteService.$inject = ['$http', '$q', '$rootScope', 'ngSettings'];

    function noteService($http, $q, $rootScope, ngSettings) {
        var serviceBase = ngSettings.appServiceBaseUri;
        var deffered = $q.defer();

        var _getNote = function (category, id) {

            var deferred = $q.defer();

            // Call API TraQNotes Controller 
            $http.get(serviceBase + "api/TraQNotes/" + category + "/" + id, {
                header: { 'Content-Type': 'application/json' }
            })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err) {
                deferred.reject(err);
            });

            return deferred.promise;
        }

        var _checkNote = function (category, id) {

            var deferred = $q.defer();

            // Call API TraQNotes Controller 
            $http.get(serviceBase + "api/TraQNotesExist/"+ category + "/" + id, {
                header: {
                    'Content-Type': 'application/json'
                }
            })
                .success(function (response) {
                    deferred.resolve(response);
                })
                .error(function (err) {
                    deferred.reject(err);
                });

            return deferred.promise;
        }

        return {
            getNote: _getNote,
            checkNote: _checkNote,
        };

    };

})();

