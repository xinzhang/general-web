﻿(function () {
    'use restrict'

    angular.module('app').factory('corporateActionsService', corporateActionsService);

    corporateActionsService.$inject = ['$http', '$q', '$rootScope', 'ngSettings', '$resource'];

    function corporateActionsService($http, $q, $rootScope, ngSettings, $resource) {
        var serviceBase = ngSettings.apiBase;
        var deffered = $q.defer();

        var corporateActions = [
                   {
                       id: 1,
                       type: "CorporateActions",
                       queue: "active",
                       workType: "Mandatory Withdrawal",
                       fundManager: "BT",
                       securityName: "BT Australian Share Fund",
                       dueDate: "01-03-2016",
                       pendDate: "",
                       attachment: true,
                       status: "urgent",
                       apirCode: "BT123"
                   },
                   {
                       id: 2,
                       type: "CorporateActions",
                       queue: "active",
                       workType: "Takeover Order",
                       fundManager: "DDH",
                       securityName: "DDH Fixed Interest Fund",
                       dueDate: "10-03-2016",
                       pendDate: "",
                       attachment: false,
                       status: "urgent",
                       apirCode: "DDH123"
                   },
                   {
                       id: 3,
                       type: "CorporateActions",
                       queue: "active",
                       workType: "Proxy Vote",
                       fundManager: "AMP",
                       securityName: "AMP FLI High Growth Fund",
                       dueDate: "08-03-2016",
                       pendDate: "",
                       attachment: true,
                       status: "new",
                       apirCode: "FSF123"
                   },
                   {
                       id: 4,
                       type: "CorporateActions",
                       queue: "active",
                       workType: "Fund Split",
                       fundManager: "ACL",
                       securityName: "Regal Long Short Equity Fund",
                       dueDate: "08-03-2016",
                       pendDate: "",
                       attachment: true,
                       status: "new",
                       apirCode: "FSF124"
                   },
                   {
                       id: 5,
                       type: "CorporateActions",
                       queue: "active",
                       workType: "Withdrawal Offer",
                       fundManager: "BT",
                       securityName: "BT Australian Share Fund",
                       dueDate: "08-03-2016",
                       pendDate: "",
                       attachment: true,
                       status: "reopen",
                       apirCode: "FSF125"
                   },
                   {
                       id: 6,
                       type: "CorporateActions",
                       queue: "active",
                       workType: "Takeover Order",
                       fundManager: "APC",
                       securityName: "APC Diversity Share Fund",
                       dueDate: "08-03-2016",
                       pendDate: "",
                       attachment: true,
                       status: "urgent",
                       apirCode: "APC123"
                   },
                   {
                       id: 7,
                       type: "CorporateActions",
                       queue: "pending",
                       workType: "Fund Termination",
                       fundManager: "BMC",
                       securityName: "Bank Australia High Yield Investment",
                       dueDate: "18-03-2016",
                       pendDate: "17-03-2016",
                       attachment: true,
                       status: "pending",
                       apirCode: "AAP123"
                   },
                   {
                       id: 8,
                       type: "CorporateActions",
                       queue: "completed",
                       workType: "Takeover Offer",
                       fundManager: "GHM",
                       securityName: "GHM Diversity Share Fund",
                       dueDate: "28-03-2016",
                       pendDate: "17-03-2016",
                       attachment: true,
                       status: "acknowledged/closed",
                       apirCode: "GHM123"
                   },
                   {
                       id: 9,
                       type: "CorporateActions",
                       queue: "completed",
                       workType: "Mandatory Withdrawal",
                       fundManager: "COL",
                       securityName: "COL Diversity Share Fund",
                       dueDate: "14-03-2016",
                       pendDate: "",
                       attachment: true,
                       status: "closed",
                       apirCode: "COL123"
                   },
                   {
                       id: 10,
                       type: "CorporateActions",
                       queue: "completed",
                       workType: "Mandatory Withdrawal",
                       fundManager: "FSF",
                       securityName: "FSF Diversity Share Fund",
                       dueDate: "14-03-2016",
                       pendDate: "17-03-2016",
                       attachment: true,
                       status: "closed",
                       apirCode: "FSF126"
                   },
        ];

        //Uses by corporateActionDetail page
        var corporateComments = [
            {
                id: 1,
                date: "01-02-2016",
                time: "8:45",
                user: "Ausmaq",
                comment: "Please fill out attached form by 10-03-2016",
                link: "C:\\templates\\attachemnt.txt",
                attachment: true,
            },
            {
                id: 2,
                date: "08-02-2016",
                time: "8:45",
                user: "Ausmaq",
                comment: "The deadline for the Proxy Vote is 2 days away, it needs to ...",
                link: "",
                attachment: false,
            },
            {
                id: 3,
                date: "10-02-2016",
                time: "8:45",
                user: "mlcuser1",
                comment: "Refer to attached completed form",
                link: "C:\\attachments\\completedform.txt",
                attachment: true,
            },
        ];

        var _getCorporateActions = function (clientCode) {

            return corporateActions;
        };

        var _getCorporateComments = function (clientCode) {

            return (corporateComments);

        };

        var _getCorporationActionById = function (id) {

                var elementPos = corporateActions.map(function (x) { return x.id; }).indexOf(id);
                var objectFound = corporateActions[elementPos];
                return (objectFound);

        };

        var _updateCorporationActionById = function (id, obj) {

            var elementPos = corporateActions.map(function (x) { return x.id; }).indexOf(id);            
            corporateActions[elementPos] = obj;
        };

        var _getCorporationCommentById = function (id) {
            var elementPos = corporateComments.map(function (x) { return x.id; }).indexOf(id);
            var objectFound = corporateComments[elementPos];
            return (objectFound);
        };

        var _getQueueCount = function (dataArray) {

            var queueCount = {};

            for (var i = 0; i < dataArray.length; i++) {
                var currValue = dataArray[i].queue;
                var found = false;
                
                if (queueCount[currValue] == undefined) {
                    queueCount[currValue] = 1;
                }
                else {
                    queueCount[currValue] = queueCount[currValue] + 1;
                }
            }

            return queueCount;
        }

        var _addComment = function (objComment) {
            var last_element = corporateComments[corporateComments.length - 1];
            objComment.id = last_element.id + 1;
            corporateComments.push(objComment);
        }

        //public methods
        return {
            getCorporateActions: _getCorporateActions,
            getQueueCount: _getQueueCount,
            getCorporationActionById: _getCorporationActionById,
            updateCorporationActionById: _updateCorporationActionById,
            getCorporateComments: _getCorporateComments,
            getCorporationCommentById: _getCorporationCommentById,
            addComment: _addComment
        };

    };

})();

