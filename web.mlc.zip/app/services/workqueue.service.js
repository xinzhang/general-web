﻿
"use strict";

angular.module('app').factory('workQueueService', function () {

    var workQueues = [
           {
               id: 1,
               type: "WorkQueue",
               workType: "Asset Management",
               fundManager: "BT",
               securityName: "BT Australian Share Fund",
               dueDate: "01-02-2016",
               attachment: true,
               status: "active",
               priority: 'Urgent'
           },
           {
               id: 2,
               type: "WorkQueue",
               workType: "Takeover Order",
               fundManager: "DDH",
               securityName: "DDH Fixed Interest Fund",
               dueDate: "10-02-2016",
               attachment: false,
               status: "active",
               priority: "Urgent"
           },
           {
               id: 3,
               type: "WorkQueue",
               workType: "Asset Management",
               fundManager: "FSF",
               securityName: "FSF Diversity Share Fund",
               dueDate: "08-02-2016",
               attachment: true,
               status: "active",
               priority: "Urgent"
           },
       {
           id: 4,
           type: "WorkQueue",
           workType: "Asset Management",
           fundManager: "FSF",
           securityName: "FSF Diversity Share Fund",
           dueDate: "08-02-2016",
           attachment: true,
           status: "active",
           priority: "Standard"
       },
       {
           id: 5,
           type: "WorkQueue",
           workType: "Takeover Order",
           fundManager: "FSF",
           securityName: "FSF Diversity Share Fund",
           dueDate: "08-02-2016",
           attachment: true,
           status: "active",
           priority: "Standard"
       },
       {
           id: 6,
           type: "WorkQueue",
           workType: "Takeover Order",
           fundManager: "APC",
           securityName: "APC Diversity Share Fund",
           dueDate: "08-02-2016",
           attachment: true,
           status: "completed",
           priority: "Standard"
       },
       {
           id: 7,
           type: "WorkQueue",
           workType: "Asset Management",
           fundManager: "AAP",
           securityName: "AAP Diversity Share Fund",
           dueDate: "08-02-2016",
           attachment: true,
           status: "completed",
           priority: "Standard"
       },
       {
           id: 8,
           type: "WorkQueue",
           workType: "Asset Management",
           fundManager: "GHM",
           securityName: "GHM Diversity Share Fund",
           dueDate: "08-02-2016",
           attachment: true,
           status: "completed",
           priority: "Standard"
       },
       {
           id: 9,
           type: "WorkQueue",
           workType: "Asset Management",
           fundManager: "COL",
           securityName: "COL Diversity Share Fund",
           dueDate: "08-02-2016",
           attachment: true,
           status: "completed",
           priority: "Urgent"
       },
       {
           id: 10,
           type: "WorkQueue",
           workType: "Asset Management",
           fundManager: "FSF",
           securityName: "FSF Diversity Share Fund",
           dueDate: "08-02-2016",
           attachment: true,
           status: "completed",
           priority: "Urgent"
       },
    ]

    //private methods

    var _getWorkQueues = function (clientCode) {
        return (workQueues);
    };

    var _getStatusCount = function (dataArray) {

        var statusCount = {};

        for (var i = 0; i < dataArray.length; i++) {
            var currValue = dataArray[i].status;
            var found = false;
            
            if (statusCount[currValue] == undefined) {
                statusCount[currValue] = 1;
            }
            else {
                statusCount[currValue] = statusCount[currValue] + 1;
            }
        }

        return statusCount;
    }

    //public methods
    return {
        getWorkQueues: _getWorkQueues,
        getStatusCount: _getStatusCount
    };
    
});

