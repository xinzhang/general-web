﻿(function () {
    'use strict';

    angular.module('app').controller('UserResetPasswordCtrl', UserResetPasswordCtrl);

    UserResetPasswordCtrl.$inject = ['$window', '$location', '$scope', '$stateParams', 'authService', 'commonService', 'notify'];

    function UserResetPasswordCtrl($window, $location, $scope, $stateParams, authService, commonService, notify) {
        var vm = this;
        vm.title = "Reset Password";
        vm.message = '';

        //var isValid = true;
        vm.resetPassword = function () {
            //Check validity
            $scope.$broadcast('show-errors-check-validity');
            if ($scope.userResetPasswordForm.$invalid  ||
                $scope.userResetPasswordForm.$invalid == undefined
                ) { return }

            var abc = authService.userResetPassword(vm.userName, vm.email);
            abc.then(function (response) {
                if (response) {
                    vm.savedSuccessfully = true;
                    notify.showSuccess('Succeed! Please Check Your Email');
                    //Redirect to login page
                    $window.location.href = 'home.html#/account/appaccount'  
                } else {
                    vm.message = 'Invalid user name, or email!';
                }

                                  
            }, function (err) {
                vm.savedSuccessfully = false;
                vm.message = commonService.showError(err, 'Reset password');
                notify.showError(err);
            });
            
        }
    }
})();