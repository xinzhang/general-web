﻿'use strict';

//angular.module('app.account', [
//    'ui.router',
//    'ngResource',
//    'app.settings'
//])

angular.module('app')
.config(function ($stateProvider) {
    
    $stateProvider.state('appaccount', {
        url: '/account/login',
        templateUrl: 'app/account/login.html',
        controller: 'LoginCtrl',
        controllerAs: 'vm'
    })

    .state('changePassword', {
        url: '/account/changePassword',
        templateUrl: 'app/account/changePassword.html',
        controller: 'ChangePasswordCtrl',
        controllerAs: 'vm'
    })

    .state('userResetPassword', {
        url: '/account/userRestPassword',
        templateUrl: 'app/account/userResetPassword.html',
        controller: 'UserResetPasswordCtrl',
        controllerAs: 'vm'
    })
});