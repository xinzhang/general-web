﻿(function () {
    'use strict';

    angular.module('app').controller('LoginCtrl', LoginCtrl);

    LoginCtrl.$inject = ['$window', '$location', '$scope', '$stateParams', 'authService', 'commonService', 'ngSettings', 'userClientAdminService'];

    function LoginCtrl($window, $location, $scope, $stateParams, authService, commonService, ngSettings, userClientAdminService) {

        var vm = this;
        vm.title = "Please Sign In";

        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        activate();

        ////////////////

        function activate() {
            authService.logout();
        }

        vm.login = function () {
            authService.login(vm.username, vm.password, vm.rememberme)
                .then(function (response) {
                    //$location service won't be able to redirect to another html page, use Javascript $window.location instead.
                    $window.location.href = 'index.html#/dashboard/landingPage';
                }, function (err) {
                    vm.message = commonService.showError(err);
                });
        }

        vm.logout = function () {
            authService.logout();
            $location.path('/home');
        }

        vm.token = function () {
            //Token
            authService.token(vm.username, vm.password, vm.rememberme).then(function (response) {
                //Don't check expire for ausmaq account
                //Remove due to Ausmaq is not admin
                //if (authService.authentication.isAdmin && authService.authentication.tdOrgCode == 'AMQ') {
                if (authService.authentication.tdOrgCode == 'AMQ') {
                    //Update last active date time
                    userClientAdminService.updateActivityDate(vm.username).then(function (response) {
                        //Ausmaq admin page
                        $window.location.href = 'index.html#/dashboard/landingPage';
                    }, function (err) {
                        vm.message = commonService.showError(err);
                    });
                }
                else {
                    userClientAdminService.checkActive(vm.username).then(function (response) {
                        if (response) {
                            //Check first time logging
                            userClientAdminService.checkFirstTime(vm.username).then(function (response) {
                                //Not first time
                                if (!response) {
                                    //Check expire pawword for other accounts
                                    userClientAdminService.checkExpire(vm.username).then(function (response) {
                                        if (!response) {
                                            //Update last active date time
                                            userClientAdminService.updateActivityDate(vm.username).then(function (response) {
                                                if (authService.authentication.isAdmin && authService.authentication.tdOrgCode !== 'AMQ') {
                                                    // Redirect to admin page.
                                                    $window.location.href = 'index.html#/admin/userByClientAdmin';
                                                }
                                                else {
                                                    // Redirect to user page
                                                    $window.location.href = 'index.html#/dashboard/landingPage';
                                                }
                                            }, function (err) {
                                                vm.message = commonService.showError(err);
                                            });

                                        } else {
                                            //Go change password for any accounts other than ausmaq.
                                            vm.authentication = authService.authentication;
                                            $window.location.href = 'home.html#/account/changePassword';
                                        }
                                    }, function (err) {
                                        vm.message = commonService.showError(err);
                                    });
                                }
                                else {
                                    //Redirect to change password page for any accounts other than ausmaq.
                                    vm.authentication = authService.authentication;
                                    $window.location.href = 'home.html#/account/changePassword';
                                }

                            }, function (err) {
                                vm.message = commonService.showError(err);
                            });
                        }
                        else{
                            vm.message = 'account is disabled';
                        }
                    }, function (err) {
                        vm.message = commonService.showError(err);
                    });

                }
            }, function (err) {
                vm.message = commonService.showError(err);
            });
        }
    }
})();