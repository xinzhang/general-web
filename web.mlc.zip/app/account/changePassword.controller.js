﻿(function () {
    'use strict';

    angular.module('app').controller('ChangePasswordCtrl', ChangePasswordCtrl);

    ChangePasswordCtrl.$inject = ['$window', '$location', '$scope', '$stateParams', 'authService', 'commonService', 'ngSettings', 'userClientAdminService', 'notify'];

    function ChangePasswordCtrl($window, $location, $scope, $stateParams, authService, commonService, ngSettings, userClientAdminService, notify) {

        var vm = this;
        vm.title = "Change Password";
        var noOfRec = 9; // 9 latest history password
        //For valid passowrd (old password == in db)
        vm.errValidPwddMsg = '';
        vm.errValidPwd = false;
        //For new passord == old passord (temporary passord)
        vm.errSameOldNewPwd = false;
        vm.errSameOldNewPwdMsg = '';
        //For new password <> confirm passord
        vm.errDiffNewConfirmPwd = false;
        vm.errDiffNewConfirmPwdMsg = '';
        //For new password exists in history
        vm.errHistoryPwd = false;
        vm.errHistoryPwdMsg = '';

        vm.authentication = authService.authentication;
        vm.userId = vm.authentication.userName;
        
        vm.savePassword = function () {

            activate;

            //Check validity
            $scope.$broadcast('show-errors-check-validity');
            if ($scope.passwordForm.$invalid ||
                $scope.passwordForm.$error.unique ||
                $scope.passwordForm.$invalid == undefined
                ) { return }

            //Check newPassword against oldPassword (temporary password)
            if (vm.oldPassword === vm.newPassword){
                vm.errSameOldNewPwd = true;
                vm.errSameOldNewPwdMsg = 'New password can not be the same old password. ';
                return;
            } else {
                vm.errSameOldNewPwd = false;
                vm.errSameOldNewPwdMsg = '';
            }
            
            if (vm.newPassword != vm.confirmPassword) {
                vm.errDiffNewConfirmPwd = true;
                vm.errDiffNewConfirmPwdMsg = 'New password does not match to confirm password. ';
                return;
            } else {
                vm.errDiffNewConfirmPwd = false;
                vm.errDiffNewConfirmPwd = '';
            }
            //Validate the existing password (old password)
            var abc = userClientAdminService.validatePassword(vm.userId, vm.oldPassword);
            abc.then(function (response) {
                //Response returned by server: SignInStatus.Success = 0
                if (response == 0) {
                    vm.errValidPwdMsg = '';
                    vm.errValidPwd = false;
                    //Check previous password (9 history passwords)
                    userClientAdminService.checkHistoryPassword(vm.userId, vm.newPassword, noOfRec).then(function (response) {
                        //Response = false => the new pwd doesn't contain in the 9 latest history pwds. 
                        if (!response) {
                            console.log('Start add the new pwd');
                            userClientAdminService.changePassword(vm.userId, vm.newPassword).then(function (response) {
                                //Update last active date time
                                userClientAdminService.updateActivityDate(vm.userId).then(function (response) {
                                    if (authService.authentication.isAdmin && authService.authentication.tdOrgCode !== 'AMQ') {
                                        // Redirect to admin page.
                                        $window.location.href = 'index.html#/admin/userByClientAdmin';
                                    }
                                    else {
                                        // Redirect to user page
                                        $window.location.href = 'index.html#/dashboard/landingPage';
                                    }
                                }, function (err) {
                                    vm.message = commonService.showError(err);
                                })
                            }, function (err) {
                                vm.message = commonService.showError(err);
                            })
                        }
                        else {
                            vm.errHistoryPwd = true;
                            vm.errHistoryPwdMsg = 'New password can not be the same in the last 9 history passwords. ';
                        }
                    })

                } else {
                    vm.errValidPwdMsg = 'Invalid password. ';
                    vm.errValidPwd = true;
                    return; //No return
                    
                }

            }, function (err) {
                vm.errValidwdMsg = err;
                vm.errValidPwd = true;
                return;
            });
        }
        
        var activate = function () {
            //For valid passowrd (old password == in db)
            vm.errValidPwddMsg = '';
            vm.errValidPwd = false;
            //For new passord == old passord (temporary passord)
            vm.errSameOldNewPwd = false;
            vm.errSameOldNewPwdMsg = '';
            //For new password <> confirm passord
            vm.errDiffNewConfirmPwd = false;
            vm.errDiffNewConfirmPwdMsg = '';
            //For new password exists in history
            vm.errHistoryPwd = false;
            vm.errHistoryPwdMsg = '';
        }
    }
})();