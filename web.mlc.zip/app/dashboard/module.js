'use strict';

angular.module('app.dashboard', [
    'ui.router',
    'ngResource'
])

.config(function ($stateProvider) {
    //$stateProvider
    //    .state('app.dashboard', {
    //        url: '/dashboard',
    //        views: {
    //            "content@app": {
    //                controller: 'DashboardCtrl',
    //                templateUrl: 'app/dashboard/dashboard.html'
    //            }
    //        },
    //        data: {
    //            title: 'Dashboard'
    //        }
    //    })
    $stateProvider
        .state('app.landingPage', {
            url: '/dashboard/landingPage',
            views: {
                "content@app": {
                    controller: 'NavigationCtrl',
                    templateUrl: 'app/dashboard/landingPage.html'
                }
            },
            data: {
                title: 'Landing page'
            }
        })
});
