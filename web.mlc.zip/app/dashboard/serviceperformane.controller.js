﻿(function () {
    'use strict';

    angular.module('app').controller('ServicePerformanceCtrl', ServicePerformanceCtrl);

    ServicePerformanceCtrl.$inject = ['$location', '$scope', '$stateParams', 'authService', 'servicePerformanceService'];

    function ServicePerformanceCtrl($location, $scope, $stateParams, authService, servicePerformanceService) {
        var vm = this;
        vm.clientCode = '';        
        vm.title = "Service Performance";

        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        vm.authentication = authService.authentication;

        vm.isShowGraph = false;

        vm.load = function () {            
            vm.serviceMetrics = servicePerformanceService.getServicePerformance(vm.clientCode);
            /*
            servicePerformanceService.getServicePerformance(vm.clientCode)
                .then(function (response) {
                    vm.serviceMetrics = response;
                }, function (err) {
                    vm.message = commonService.showError(err);
                })
            */
        }

        activate();

        ////////////////

        function activate() {
            $scope.$on('LastRepeaterElement', function () {
                $('.popover-dismiss').popover({
                    trigger: 'focus',
                    html: 'true'
                });
            });

            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;

            vm.load();
        }

        function getRandomArbitrary(min, max) {
            return Math.random() * (max - min) + min;
        }

        function getExampleData() {
            var data = [];
            for (var i = 1; i < 31; i++)
            {
                var dd = [];
                dd.push('Date.UTC(2016, 3,' + i + ')');
                dd.push(Number(getRandomArbitrary(0.5, 1).toFixed(2)));

                data.push(dd)
            }
            
            return data;
        }

        function getYData() {
            var data = [];
            for (var i = 1; i < 31; i++) {

                data.push(Number(getRandomArbitrary(0.5, 1).toFixed(2)));
            }

            return data;
        }

        function getXCateogry() {
            var cat = [];
            for (var i = 1; i < 31; i++) {

                cat.push(i);
            }

            return cat;
        }

        function initializeChart(name) {
            vm.isShowGraph = true;
            console.log('show graph');

            $('#servicePerformanceGraph').highcharts({
                chart: {
                    type: 'line'
                },
                title: {
                    text: name + ' performance for current month'
                },
                xAxis: {
                    categories: getXCateogry()
                },
                yAxis: {
                    title: {
                        text: 'performance'
                    },
                    min: 0,
                    max: 1
                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    area: {
                        fillColor: {
                            linearGradient: {
                                x1: 0,
                                y1: 0,
                                x2: 0,
                                y2: 1
                            },
                            stops: [
                                [0, Highcharts.getOptions().colors[0]],
                                [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                            ]
                        },
                        marker: {
                            radius: 2
                        },
                        lineWidth: 1,
                        states: {
                            hover: {
                                lineWidth: 1
                            }
                        },
                        threshold: null
                    }
                },

                series: [{
                    type: 'area',
                    name: 'performance chart',
                    data: getYData()
                }]
            });
            
        }

        vm.showGraph = function (name) {            
            initializeChart(name);            
        }
        
    }            
})();