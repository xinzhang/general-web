﻿(function () {
    'use strict';

    angular.module('app').controller('ServiceSummaryCtrl', ServiceSummaryCtrl);

    ServiceSummaryCtrl.$inject = ['$window', '$location', '$scope', '$stateParams', '$filter', 'mlcRequestService', 'commonService', 'authService', 'serviceNames', 'servicePerformanceService', 'buysellsService'];

    function ServiceSummaryCtrl($window, $location, $scope, $stateParams, $filter, mlcRequestService, commonService, authService, serviceNames, servicePerformanceService, buysellsService) {
        var vm = this;
        vm.clientCode = '';
        vm.title = "Service Performance";
        vm.summary = [];
        //Initialise data
        vm.distribution = {
            type: 'Distributions',
            overdue: 0,
            completed: 0,
            received: 0
        }
        vm.rebate = {
            type: 'Rebates',
            overdue: 0,
            outoftolerance: 0,
            completed: 0,
            received: 0
        }
        vm.securityrecs = {
            type: 'Security Recs',
            overdue: 0,
            completed: 0,
            received: 0
        }
        vm.buysell = {
            type: 'Buy & Sell',
            overdue: 0,
            awaiting: 0,
            unbatched: 0,
            dailyconfirmation: 0
        }
        vm.transfer = {
            type: 'Transfers',
            transferin: 0,
            transferout: 0,
        }
        vm.completed = false;
        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        var loadPerformanceOverview = function () {
            //Load Distribution overview
            servicePerformanceService.getServiceOverview(serviceNames.Distribution)
            .then(function (response) {
                vm.distribution.overdue = response[0].y;
                vm.distribution.completed = response[1].y;
                vm.distribution.received = response[2].y;
            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            })

            //Load Rebate overview
            servicePerformanceService.getServiceOverview(serviceNames.Rebate)
            .then(function (response) {
                vm.rebate.overdue = response[0].y;
                vm.rebate.completed = response[1].y;
                vm.rebate.received = response[2].y;
                vm.rebate.outoftolerance = response[3].y;

            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            })

            //Load Security Recs overview
            servicePerformanceService.getServiceOverview(serviceNames.SecurityRecs)
            .then(function (response) {
                vm.securityrecs.overdue = response[0].y;
                vm.securityrecs.completed = response[1].y;
                vm.securityrecs.received = response[2].y;
            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            })

            //Load buy&sells
            //Existing
            //buysellsService.getOverdueCount()
            //    .then(function (response) {
            //        vm.buysell.overdue = response;
            //    }, function (err) {
            //        vm.errorMessage = commonService.showError(err);
            //    });

            //New
            buysellsService.getBuySellsCount('Overdue')
                .then(function (response) {
                    vm.buysell.overdue = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
            buysellsService.getBuySellsCount('Awaiting')
                .then(function (response) {
                    vm.buysell.awaiting = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
            buysellsService.getDailyConfirmationPositionCount()
              .then(function (response) {
                  vm.buysell.dailyconfirmation = response;
              }, function (err) {
                  vm.errorMessage = commonService.showError(err);
              })
            buysellsService.getUnbatchedOrderCount()
              .then(function (response) {
                  vm.buysell.unbatched = response;
              }, function (err) {
                  vm.errorMessage = commonService.showError(err);
              })


            servicePerformanceService.getServiceOverview(serviceNames.Transfer)
            .then(function (response) {
                vm.transfer.transferin = response[0].y;
                vm.transfer.transferout = response[1].y;
                
            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            })


        }
        
        activate();

        ////////////////

        function activate() {

            vm.authentication = authService.authentication;
            vm.clientCode = vm.authentication.tdOrgCode;
            loadPerformanceOverview();
                

            //for (var property in serviceNames) {
            //    var obj = {};
            //    if (serviceNames.hasOwnProperty(property)) {
            //        console.log(property);
            //        servicePerformanceService.getServiceOverview(property)
            //        .then(function (response) {
                        
            //            console.log(response);
            //            //obj.type = property;
            //            //obj.cat1= response[0].name + ' ' + response[0].y,
            //            //obj.cat2 = '',
            //            //obj.cat3 = response[2].name + ' ' + response[2].y,
            //            //obj.cat4 = response[1].name + ' ' + response[1].y
            //            //var obj = {
            //            //    type: serviceNames.Distribution,
            //            //    cat1: response[0].name + ' ' + response[0].y,
            //            //    cat2: '',
            //            //    cat3: response[2].name + ' ' + response[2].y,
            //            //    cat4: response[1].name + ' ' + response[1].y
            //            //}
                       

            //            //vm.summary.push(obj);
            //        }, function (err) {
            //            vm.errorMessage = commonService.showError(err);
            //        })
                    
            //    }
            //}
            
            //console.log("vm.summary");
            //console.log(vm.summary);
            //servicePerformanceService.getServiceOverview("Distribution")
            //.then(function (response) {
            //    console.log("activate");
            //    console.log(response);
            //    var obj = {
            //        type: serviceNames.Distribution,
            //        cat1: response[0].name + ' ' + response[0].y,
            //        cat2: '',
            //        cat3: response[2].name + ' ' + response[2].y,
            //        cat4: response[1].name + ' ' + response[1].y
            //    }
            //    vm.summary.push(obj);
            //    console.log(vm.summary);
            //}, function (err) {
            //    vm.errorMessage = commonService.showError(err);
            //})

            //servicePerformanceService.getServiceOverview(serviceNames.Rebate)
            //.then(function (response) {
            //    console.log("activate");
            //    console.log(response);
            //    var obj = {
            //        type: serviceNames.Rebate,
            //        cat1: response[0].name + ' ' + response[0].y,
            //        cat2: response[3].name + ' ' + response[3].y,
            //        cat3: response[2].name + ' ' + response[2].y,
            //        cat4: response[1].name + ' ' + response[1].y
            //    }
            //    vm.summary.push(obj);
            //    console.log(vm.summary);
            //}, function (err) {
            //    vm.errorMessage = commonService.showError(err);
            //})

            //servicePerformanceService.getServiceOverview(serviceNames.SecurityRecs)
            //.then(function (response) {
            //    console.log("activate");
            //    console.log(response);
            //    var obj = {
            //        type: serviceNames.SecurityRecs,
            //        cat1: response[0].name + ' ' + response[0].y,
            //        cat2: '',
            //        cat3: response[2].name + ' ' + response[2].y,
            //        cat4: response[1].name + ' ' + response[1].y
            //    }
            //    vm.summary.push(obj);
            //    console.log(vm.summary);
            //}, function (err) {
            //    vm.errorMessage = commonService.showError(err);
            //})

            //servicePerformanceService.getServiceOverview(serviceNames.Transfer)
            //.then(function (response) {
            //    console.log("activate");
            //    console.log(response);
            //    var obj = {
            //        type: serviceNames.Transfer,
            //        cat1: response[0].name + ' ' + response[0].y,
            //        cat2: response[1].name + ' ' + response[1].y,
            //        cat3: '',
            //        cat4: ''
            //    }
            //    vm.summary.push(obj);
            //    console.log(vm.summary);
            //}, function (err) {
            //    vm.errorMessage = commonService.showError(err);
            //})
        }

        
    }
})();