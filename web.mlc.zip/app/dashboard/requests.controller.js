﻿(function () {
    'use strict';

    angular.module('app').controller('RequestsCtrl', RequestsCtrl);

    RequestsCtrl.$inject = ['$window', '$location', '$scope', '$stateParams', '$filter', 'mlcRequestService', 'commonService', 'authService'];

    function RequestsCtrl($window, $location, $scope, $stateParams, $filter, mlcRequestService, commonService, authService) {
        var vm = this;
        vm.clientCode = '';
        vm.title = "Requests";
        vm.completed = false;
        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }
        vm.histories = [];
        vm.pageRequestList = [];
        vm.filteredHistories = vm.histories;
        
        vm.monthlyRequest = [];

        vm.activeCount = 0;
        vm.completedCount = 0;
        var orderBy = $filter('orderBy');

        // Sort by column in the grid
        vm.sortColumn = 'dateTimeAdded';
        vm.sortOrder = true;
        vm.sortData = function (columnName) {
            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.filteredHistories = orderBy(vm.filteredHistories, vm.sortColumn, vm.sortOrder);
            vm.gotoPage(0);
        }
       
        vm.loadDataByStatus = function (status) {

            if (angular.lowercase(status) === 'active') {
                vm.completed = false;
                vm.histories = vm.monthlyRequest.filter(function (obj) {
                    return obj.status === 8 || obj.status === 1;
                });
            } else if (angular.lowercase(status) === 'completed')
            {
                vm.completed = true;
                vm.histories = vm.monthlyRequest.filter(function (obj) {
                    return obj.status === 5 || obj.status === 6;
                });
            }
            vm.filteredHistories = vm.histories;
            vm.paging.rowTotal = vm.filteredHistories.length;
            vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
            vm.gotoPage(0);
        }

        vm.gotoPage = function (pageno) {
            if (pageno < 0 || pageno >= vm.paging.totalPage)
                return;

            vm.paging.isPrev = vm.paging.isNext = true;

            if (pageno == 0)
                vm.paging.isPrev = false;

            if (pageno == (vm.paging.totalPage - 1))
                vm.paging.isNext = false;

            vm.paging.currentPage = pageno;

            vm.pageRequestList = vm.filteredHistories.slice(pageno * 10, (pageno + 1) * 10);

        }
        
        vm.loadDetail = function (requestType)
        {
            if (!vm.completed) {
                if (requestType === 'Virtual Cash')
                    $window.location.href = 'index.html#/request/virtualCash';
                else if (requestType === 'Off Book Trades')
                    $window.location.href = 'index.html#/request/offbooktrade';
            }
        }
        activate();

        ////////////////

        function activate() {

            vm.authentication = authService.authentication;
            vm.clientCode = vm.authentication.tdOrgCode;

            mlcRequestService.getLandingPageRequestList(vm.clientCode)
                .then(function (response) {
                    vm.completed = false;
                    vm.monthlyRequest = response;

                    console.log(vm.monthlyRequest);

                    vm.histories = vm.monthlyRequest.filter(function (obj) {
                        return obj.status === 8 || obj.status === 1;
                    });
                    vm.activeCount = vm.histories.length;
                    vm.completedCount = vm.monthlyRequest.length - vm.activeCount;
                    vm.filteredHistories = vm.histories;
                    vm.paging.rowTotal = vm.filteredHistories.length;
                    vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
                    vm.gotoPage(0);
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });
        }
    }
})();