﻿(function () {
    'use strict';

    angular.module('app').controller('CorporateActionsCtrl', CorporateActionsCtrl);

    CorporateActionsCtrl.$inject = ['$location', '$scope', '$stateParams', 'authService', 'corporateActionsService', '$filter', 'notify'];

    function CorporateActionsCtrl($location, $scope, $stateParams, authService, corporateActionsService, $filter, notify) {
        var vm = this;

        vm.clientCode = '';
        vm.title = "Corporate Actions";
        vm.searchtitle = "Enter Date Range - Work Type optional"

        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        if ($stateParams.corporateid) {
            vm.corporateid = $stateParams.corporateid;            
        }

        vm.allWorkTypes = ['Proxy Vote', 'Fund Split', 'Withdrawal Offer', 'Mandatory Withdrawal', 'Takeover Order'];               
        
        vm.authentication = authService.authentication;

        var orderBy = $filter('orderBy');

        vm.sortData = function (columnName) {
            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.filteredList = orderBy(vm.filteredList, vm.sortColumn, vm.sortOrder);
        }

        vm.fitlerByStatus = function (row) {
            return angular.lowercase(row.status) == (vm.filterStatus);
        }

        vm.updateFilterStatus = function (status) {           
            vm.filteredList = $filter('filter')(vm.corporateActions, status);
            // Sort by column in the grid
            vm.sortColumn = 'dueDate';
            vm.sortOrder = false;
            vm.sortData('dueDate');

            vm.activeTab = status;
        }

        vm.filterObject = {
            workType: '',
            startDate: '',
            finishDate: ''
        }

        vm.pendDate = "";

        activate();

        ////////////////

        function activate() {
            $scope.$on('LastRepeaterElement', function () {
                $('.popover-dismiss').popover({
                    trigger: 'focus',
                    html: 'true'
                });
            });

            $('#corprateActionsTab a').click(function (e) {
                e.preventDefault()
                $(this).tab('show')
            })

            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;

            vm.searchedList = vm.corporateActions = corporateActionsService.getCorporateActions(vm.clientCode);
            vm.queueCount = corporateActionsService.getQueueCount(vm.corporateActions);

            vm.isPend = false;

            vm.events = [];
            _.forEach(vm.corporateActions, function (row) {
                if (row.queue == "active") {
                    var event = { id: "", title: "", start: "" };
                    event.id = row.id;
                    event.title = row.workType;
                    event.start = moment(row.dueDate, "DD-MM-YYYY").format();
                    vm.events.push(event);
                }
            });

            vm.updateFilterStatus("active");

            if (vm.corporateid) {                
                if (parseInt(vm.corporateid) > 0) {
                    vm.detail = corporateActionsService.getCorporationActionById(parseInt(vm.corporateid));
                    vm.detailtitle = vm.detail.workType;
                    vm.corporateComments = corporateActionsService.getCorporateComments(vm.clientCode);

                    vm.updateFilterStatus(vm.detail.queue);

                    $('#activeTab').attr('class', '');
                    $('#pendingTab').attr('class', '');
                    $('#completedTab').attr('class', '');

                    var tabId = '#' + vm.detail.queue + 'Tab';
                    $(tabId).attr('class', 'active');
                }
            }
        }

        /////////////////////////////
        //vm.isShowDetail = false;

        vm.showDetail = function () {
            vm.isShowDetail = !vm.isShowDetail;
        }

        vm.getCorporationActionById = function (id) {
            vm.detail = corporateActionsService.getCorporationActionById(id);
        };

        vm.showCommentDetail = function (commentId) {
            var dateNow = new Date();
            vm.isViewMode = false;
            //New comment
            if (commentId === 0) {
                vm.modalTitle = "Add New Comment";
                vm.date = dateNow.toLocaleDateString();
                vm.time = dateNow.toLocaleTimeString();
                vm.comment = "";
                vm.link = "";
                vm.user = vm.authentication.userName;
            }
            else //Existing comment
            {
                vm.modalTitle = "View Comment";
                vm.isViewMode = true
                //Call service
                vm.commentDetail = corporateActionsService.getCorporationCommentById(parseInt(commentId));
                //Assign value
                vm.date = vm.commentDetail.date;
                vm.time = vm.commentDetail.time;
                vm.comment = vm.commentDetail.comment;
                vm.link = vm.commentDetail.link;
                vm.user = vm.commentDetail.user;
            }
            $('#modalCorporateActionViewAddComment').modal('show');
        };

        vm.showPendCorporateAction = function (commentId) {            
            if (vm.isAcknowledge) {
                return;
            }
            $('#modalCorporateActionViewPendDate').modal('show');
        };

        vm.addComment = function (date, time, user, comment, link) {
            var objComment = [];
            objComment.date = date;
            objComment.time = time;
            objComment.user = user;
            objComment.comment = comment;
            objComment.attachment = false;
            objComment.link = link;
            corporateActionsService.addComment(objComment);
        };

        vm.confirmSubmitCorporateAction = function (commentId) {
            $('#modalCorporateActionConfirm').modal('show');
        };

        vm.submitCorporateAction = function () {
            notify.showSuccess("Coporate Action Request is submitted successfully.");
            // Redirect to request                        
            //$location.path('/request/requestReference/' + "CorpActionRef123");

            $('#modalCorporateActionConfirm').on('hidden.bs.modal', function () {
                // do something…
                $location.path('/corporateactions/summary/0');
            });

            if (vm.isPend) {
                vm.detail.queue = "pending";
                vm.detail.status = "pending";
                corporateActionsService.updateCorporationActionById(parseInt(vm.corporateid), vm.detail);
            }
            else if (vm.isAcknowledge) {
                vm.detail.queue = "completed";
                vm.detail.status = "acknowledged/closed ";
                corporateActionsService.updateCorporationActionById(parseInt(vm.corporateid), vm.detail);
            }
            else {
                vm.detail.queue = "completed";
                vm.detail.status = "review by Ausmaq";
                corporateActionsService.updateCorporationActionById(parseInt(vm.corporateid), vm.detail);
            }

            $('#modalCorporateActionConfirm').modal('hide');

            
        };

        vm.acknowledgeCorporateAction = function () {
            if (vm.isPend)
            {
                return;
            }

            vm.isAcknowledge = !vm.isAcknowledge;
        };

        vm.pendCorporateAction = function () {

            vm.detail.pendDate = vm.pendDate;
            vm.isPend = (vm.detail.pendDate != '');
            
            $('#modalCorporateActionViewPendDate').modal('hide');
        };


        vm.search = function () {

            var date1 = moment(vm.filterObject.startDate, "DD-MM-YYYY");
            var date2 = moment(vm.filterObject.finishDate, "DD-MM-YYYY");

            vm.searchedList = _.filter(vm.corporateActions, vm.filterCorporateActionsByDateRange);
        }

        vm.isObjEmpty = function (obj) {
            if (obj === undefined || obj === null || obj === '') {
                return true;
            }
            else {
                return false;
            }
        };

        vm.filterCorporateActionsList = function (row) {            
            var blRequestType = false;
            
            blRequestType = (
                    (vm.isObjEmpty(vm.filterObject.workType) || vm.filterObject.workType === row.workType)
                    //&&
                    //(vm.isObjEmpty(vm.filterObject.dateFrom) || vm.filterObject.dateFrom === row.dueDate)
                );

            return blRequestType;
        };

        vm.filterCorporateActionsByDateRange = function (row) {

            var date1 = moment(new Date(1900, 1, 1));
            var date2 = moment(new Date(9000, 1, 1));

            if (vm.filterObject.startDate != "") {
                date1 = moment(vm.filterObject.startDate, "DD-MM-YYYY");
            }
            if (vm.filterObject.finishDate != "") {
                date2 = moment(vm.filterObject.finishDate, "DD-MM-YYYY");
            }

            var dueDate = moment(row.dueDate, "DD-MM-YYYY");
            var result = ((dueDate.isSame(date1) || dueDate.isAfter(date1))
                            && (dueDate.isSame(date2) || dueDate.isBefore(date2)));

            return result;
        };

        //////////////////////

    }
    
})();