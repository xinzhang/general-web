﻿(function () {
    'use strict';

    angular.module('app.dashboard').controller('DashboardCtrl', DashboardCtrl);

    DashboardCtrl.$inject = ['$location', '$scope', '$stateParams', 'authService'];

    function DashboardCtrl($location, $scope, $stateParams, authService) {
        var vm = this;
        vm.clientCode = '';
        vm.showDetail = false;
        vm.title = "";

        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }

        vm.authentication = authService.authentication;
             
        activate();

        ////////////////

        function activate() {
            $scope.$on('LastRepeaterElement', function () {
                $('.popover-dismiss').popover({
                    trigger: 'focus',
                    html: 'true'
                });
            });

            /*
            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;


            userService.getAlerts(vm.username, 20)
                .then(function (response) {
                    vm.alerts = response;
                    vm.paging.rowTotal = vm.alerts.length;
                    vm.paging.totalPage = vm.alerts.length / 10;
                    vm.gotoPage(0);

                }, function (err) {
                    vm.message = commonService.showError(err);
                });
            
            vm.loadRequestPieCharts();
            
            userService.getDashboardCount(vm.clientCode, vm.username, "messages,alerts,requests").then(function (response) {
                vm.counter = response;
            }, function (err) {
                vm.message = commonService.showError(err);
            });
            */
        }
    }
})();