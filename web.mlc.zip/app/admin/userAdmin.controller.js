﻿(function () {
    'use strict';

    angular.module('app').controller('userAdminCtrl', userAdminCtrl);

    userAdminCtrl.$inject = ['$window','$location', '$scope', '$stateParams', '$filter', 'ngSettings', 'authService', 'commonService', 'userClientAdminService', 'notify'];
    function userAdminCtrl($window, $location, $scope, $stateParams, $filter, ngSettings, authService, commonService, userClientAdminService, notify) {
       
        console.log('New userAdminCtrl');
        var passwordLength = 6;

        var vm = this;     
        var target = '';
        vm.title = 'User Management';
        vm.authentication = authService.authentication;
        
        
        // User
        vm.userTitle = 'Add New User';
        vm.message = '';
        vm.editMode = false;
        vm.addNewMode = false;
        vm.resetPwdMode = false;
        vm.msgGeneratePwd = '';
        vm.selectionUserStatuses = ['Active', 'Lockout'];
        vm.selectionClientCode = [];
        vm.clientCodeDlg = [];
        vm.authentication = authService.authentication;
 
        vm.userDetails = [];
        // name must match to value of column Name in the Roles table
        vm.roles = [{name:'Authorise'},
					{name:'Standard'}];
        vm.selection = [];
        
        vm.toggleSelection = function(roleName)
        {
            var idx = vm.selection.indexOf(roleName);
            // is currently selected
            if (idx > -1) {
                //Remove the first item in an array
                vm.selection.splice(idx, 1);
            }

            // is newly selected
            else {

                //The just below statement allows only one role per user
                vm.selection = [];
                vm.selection.push(roleName);
                //Initialise the error message
                vm.errRoleMsg = '';
            }
        }

        vm.svrPwdMessage = "";
        vm.errPwdRequired = false;
        vm.errPwdMinlength = false;
        vm.errPwdCompareTo = false;
        
        //Tam:Pwd
        vm.errPwdStrength = false;
        vm.errRoleMsg = '';

        //Paging
        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }
        vm.histories = [];
        vm.pageRequestList = [];
        vm.filteredHistories = vm.histories;

        vm.gotoPage = function (pageno) {
            if (pageno < 0 || pageno >= vm.paging.totalPage)
                return;

            vm.paging.isPrev = vm.paging.isNext = true;

            if (pageno == 0)
                vm.paging.isPrev = false;

            if (pageno == (vm.paging.totalPage - 1))
                vm.paging.isNext = false;

            vm.paging.currentPage = pageno;

            vm.pageRequestList = vm.filteredHistories.slice(pageno * 10, (pageno + 1) * 10);

        }

        // Sort by column in the grid
        vm.sortColumn = '';
        vm.sortOrder = true;
        vm.sortData = function (columnName) {
            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.filteredHistories = $filter('orderBy')(vm.filteredHistories, vm.sortColumn, vm.sortOrder);
            vm.gotoPage(0);
        }

        vm.filterObject = {
            'userStatus': ''
        }
        
        vm.filterRequestList = function (row) {
            var blRequestType = false;

            blRequestType = (
                    (vm.isObjEmpty(vm.filterObject.userStatus) || vm.filterObject.userStatus === vm.userStatus(row.lockoutEndDateUtc))
                    //&&
                    //(vm.isObjEmpty(vm.filterObject.clientCode) || vm.filterObject.clientCode === row.clientCode) //TAM
                );
            return blRequestType;
        };

        vm.isObjEmpty = function (obj) {
            if (obj === undefined || obj === null || obj === '') {
                return true;
            }
            else {
                return false;
            }
        };

        vm.userStatus = function (obj) {
            if (obj === undefined || obj === null || obj === '') {
            return 'Active';
            }
            else {
                return 'Lockout';
            }
        };

        
        activate();

        ////////////////

        function activate() {
            //Below code initialises default role to be standard
            //vm.selection.push('Standard');
            //Initialise user
            vm.editMode = false;
            vm.addNewMode = false;
            vm.resetPwdMode = false;
            vm.svrPwdMessage = "";
            vm.errPwdRequired = false;
            vm.errPwdMinlength = false;
            vm.errPwdCompareTo = false;
            vm.errRoleMsg = '';

            //Tam:Fixed adi admin role where tdOrgCode is blank
            if (vm.authentication.tdOrgCode === '')
                target = vm.authentication.adiCode;
            else
                target = vm.authentication.tdOrgCode;

            // Load user list per tdOrgCode
            userClientAdminService.getUserListByOrgCode(target)
                .then(function (response) {
                    vm.histories = response;
                    vm.filteredHistories = vm.histories;
                    vm.paging.rowTotal = vm.filteredHistories.length;
                    vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
                    vm.gotoPage(0);
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });
           
        };

        vm.refresh = function () {
            activate();
        }

        vm.newUser = function () {
            vm.userTitle = 'Add New User';
            vm.editMode = false;
            vm.addNewMode = true;
            vm.resetPwdMode = false;
            vm.resetUser();
            vm.svrPwdMessage = "";
            vm.errPwdRequired = false;
            vm.errPwdMinlength = false;
            vm.errPwdCompareTo = false;
            vm.clientCodeDlg = vm.selectionClientCode;
            vm.loginName = vm.authentication.userName;
            vm.clientCode = vm.authentication.tdOrgCode;
            vm.msgGeneratePwd = '';
            vm.errRoleMsq = '';         
            
            $('#modalUserDetails').modal('show');
        };
        
        
        vm.editUser = function (userName) {
            vm.addNewMode = false;
            vm.editMode = true;
            vm.resetPwdMode = false;
            vm.userTitle = 'Edit User';
            vm.resetUser();
            vm.svrPwdMessage = "";
            vm.errPwdRequired = false;
            vm.errPwdMinlength = false;
            vm.errPwdCompareTo = false;
            vm.msgGeneratePwd = '';
            vm.errRoleMsq = '';

            vm.clientCodeDlg = vm.selectionClientCode;
            userClientAdminService.getUserDetails(userName)
                .then(function (response) {
                    vm.userDetails = response;
                    vm.userName = vm.userDetails.userName;
                    vm.firstName = vm.userDetails.firstName;
                    vm.lastName = vm.userDetails.lastName;
                    vm.userEmail = vm.userDetails.email;
                    vm.phoneNumber = vm.userDetails.phoneNumber;
                    vm.clientCode = vm.userDetails.clientCode;
                    vm.selection = vm.userDetails.roleNames;
                    vm.loginName = vm.authentication.userName;

                    $('#modalUserDetails').modal('show');
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });

        };
        
        //This function handles three cases: reset password, add new user and update user's details.
        vm.saveUser = function () {

            //Reset Password
            if (vm.resetPwdMode)
            {
                resetPwdByAdmin();

            } else {
                ////Check required fields
                $scope.$broadcast('show-errors-check-validity');
                if ($scope.userForm.$invalid ||
                    $scope.userForm.$error.unique ||
                    $scope.userForm.$invalid == undefined
                    ) { return }
                //Check role name
                if (vm.selection.length == 0) {
                    vm.errRoleMsg = 'The role can not be empty';
                    return;
                }
                if (vm.addNewMode) {
                    addNewUser();
                } else {
                    updateUser();
                }

            }
        }

        vm.resetUser = function () {
            $scope.$broadcast('show-errors-reset');
            vm.userName = "";
            vm.firstName = "";
            vm.lastName = "";
            vm.userEmail = "";
            vm.password = "";
            vm.confirmPassword = "";
            vm.clientCode = '';
            vm.phoneNumber = "";
            //Tam:Added
            vm.selection = [];
        }

        //This function generate randomly a password with the following policy:
        // Password length >= 6, at least on lowercase character, at least on uppercase caharacter, and one digit
        vm.generatePassword = function () {
            var pwd = '';
            while (pwd == '') {
                //Generate the pwd
                pwd = randomPassword(passwordLength);
                //Check pwd security strength
                if (!errPwdStrenth(pwd, pwd.length)) {
                    //Comply security strength policy
                    vm.password = pwd;
                    vm.confirmPassword = pwd;
                } else {
                    //Failed check. Re-Generate pwd
                    pwd = '';
                }
            }
            //Generated pwd by system
            if(vm.resetPwdMode)
                vm.msgGeneratePwd = 'Click on Save button, the new temporary password will send to ' + vm.userEmail;
            
        }
        
        vm.resetPassword = function (userName) {
            vm.addNewMode = false;
            vm.editMode = false;
            vm.resetPwdMode = true;
            vm.userTitle = 'Reset Password';
            vm.resetUser();
            vm.svrPwdMessage = "";
            vm.errPwdRequired = false;
            vm.errPwdMinlength = false;
            vm.errPwdCompareTo = false;
            vm.msgGeneratePwd = '';
            vm.errRoleMsq = '';
            vm.clientCodeDlg = vm.selectionClientCode;
            //Need to send email
            userClientAdminService.getUserDetails(userName)
                .then(function (response) {
                    vm.userDetails = response;
                    vm.userName = vm.userDetails.userName;
                    vm.userEmail = vm.userDetails.email;
                    vm.clientCode = vm.userDetails.clientCode;
                    $('#modalUserDetails').modal('show');
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });

        };

        //resetPwdByAdmin updates the password
        var resetPwdByAdmin = function () {
            // Valid Data to be saved 
            var abc = userClientAdminService.resetPassword(vm.userName, 
                                                            vm.password, 
                                                            vm.userEmail,  //Need to send email
                                                            vm.clientCode);//Need to send email
            abc.then(function (response) {
                vm.savedSuccessfully = true;
                vm.message = "Update successfully";
                $('#modalUserDetails').modal('hide');
                vm.resetUser();
                vm.editMode = false;
                vm.addNewMode = false;
                vm.svrPwdMessage = "";
                vm.errPwdRequired = false;
                vm.errPwdMinlength = false;
                vm.errPwdCompareTo = false;
                vm.svrPwdStrengthMessage = false;
                activate();
                notify.showSuccess("Changing password is success.");
            }, function (err) {
                vm.savedSuccessfully = false;
                vm.message = commonService.showModalError(err, "change password");
                notify.showError(err);
            });
        }

        var addNewUser = function () {
            // Valid Data to be saved 
            var abc = userClientAdminService.saveUser(vm.userName,
                                                    vm.firstName,
                                                    vm.lastName,
                                                    vm.userEmail,
                                                    vm.password,
                                                    vm.clientCode,
                                                    vm.phoneNumber,
                                                    vm.selection);
                                                   
            abc.then(function (response) {
                vm.savedSuccessfully = true;
                vm.message = "Create successfully";
                $('#modalUserDetails').modal('hide');
                activate();
                notify.showSuccess("Add new user is success.");
            }, function (err) {
                vm.savedSuccessfully = false;
                vm.message = commonService.showModalError(err, "create user");
                notify.showError(err);
            });
        };

        var updateUser = function () {
            // Valid Data to be saved 
            var abc = userClientAdminService.updateUser(vm.userName,
                                                    vm.firstName,
                                                    vm.lastName,
                                                    vm.userEmail,
                                                    vm.clientCode,
                                                    vm.phoneNumber,
                                                    vm.selection);
                                                    
           

            abc.then(function (response) {
                vm.savedSuccessfully = true;
                vm.message = "Update successfully";
                $('#modalUserDetails').modal('hide');
                vm.resetUser();
                vm.editMode = false;
                vm.addNewMode = false;
                vm.svrPwdMessage = "";
                vm.errPwdRequired = false;
                vm.errPwdMinlength = false;
                vm.errPwdCompareTo = false;
                activate();
                notify.showSuccess("Update user is success.");
            }, function (err) {
                vm.savedSuccessfully = false;
                vm.message = commonService.showModalError(err, "update user");
                notify.showError(err);
            });
        };

        //Tam:
        ///Check password security strength
        ///Returns false if no error caused by the policy, ortherwise return true.
        var errPwdStrenth = function (pwd, length) {
            var pwdValidLength, pwdHasLetterUppercase, pwdHasLetterLowercase, pwdHasNumber;
            //Initialise the message
            vm.svrPwdStrengthMessage = "";
            //Require password length >= 6
            pwdValidLength = (pwd && pwd.length >= length ? true : false);
            //Require password uppercase and lowercase
            //Require at least one uppercase character using regEx check
            if (pwd && /[A-Z]/.test(pwd)) {
                pwdHasLetterUppercase = true;
            } else {
                pwdHasLetterUppercase = false;
                vm.svrPwdStrengthMessage = "The password must include at least one uppercase character";
            }
            
            //Require at least one lowercase character using regEx check
            if (pwd && /[a-z]/.test(pwd)) {
                pwdHasLetterLowercase = true;
            } else {
                pwdHasLetterLowercase = false;
                vm.svrPwdStrengthMessage = "The password must include at least one lowercase character";
            }

            //Require at least one digit using regEx check
            //pwdHasNumber = (pwd && /\d/.test(pwd)) ? true : false;
            if(pwd && /\d/.test(pwd)){
                pwdHasNumber = true;
            }
            else {
                pwdHasNumber = false;
                vm.svrPwdStrengthMessage = "The password must include at least one digit";
            }
            
            if (pwdValidLength && pwdHasNumber && pwdHasLetterUppercase && pwdHasLetterLowercase)
                return false;   //No error
            else
                return true;    //error occurs
        };

        //Tam:
        ///Random generate password
        var randomPassword = function(length) {
            var chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            var pwd = "";
            for (var x = 0; x < length; x++) {
                var i = Math.floor(Math.random() * chars.length);
                pwd += chars.charAt(i);
            }
            return pwd;
        }


        vm.filterHistory = function (searchCriteria) {
            vm.filteredHistories = $filter('filter')(vm.histories, searchCriteria);
            vm.paging.rowTotal = vm.filteredHistories.length;
            vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
            vm.gotoPage(0);
        }
    }
})();