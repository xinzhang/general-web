﻿'use strict';

angular.module('app.admin', [
    'ui.router',
    'ngResource'
])

.config(function ($stateProvider) {
    
    $stateProvider
       .state('app.ausmaqClientAdmin', {
           url: '/admin/ausmaq/clientAdmin/:title',
           views: {
               "content@app": {
                   controller: 'userClientAdminCtrl',
                   templateUrl: 'app/admin/ausmaq/clientAdmin.html',
                   controllerAs: 'vm'
               }
           },
           data: {
               title: 'Client Admin'
           }
       })

       .state('app.ausmaqUserAdmin', {
           url: '/admin/ausmaq/userAdmin/:title',
           views: {
               "content@app": {
                   controller: 'userClientAdminCtrl',
                   templateUrl: 'app/admin/ausmaq/userAdmin.html',
                   controllerAs: 'vm'
               }
           },
           data: {
               title: 'User Admin'
           }
       })
       .state('app.userByClientAdmin', {
           url: '/admin/userByClientAdmin',
           views: {
               "content@app": { 
                   controller: 'userAdminCtrl',
                   templateUrl: 'app/admin/userByClientAdmin.html',
                   controllerAs: 'vm'
               }
           },
           data: {
               title: 'User Admin'
           }
       })
});
