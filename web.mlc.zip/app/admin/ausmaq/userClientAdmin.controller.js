﻿(function () {
    'use strict';

    angular.module('app').controller('userClientAdminCtrl', userClientAdminCtrl);

    userClientAdminCtrl.$inject = ['$location', '$scope', '$stateParams', '$filter', 'authService', 'commonService', 'userClientAdminService', 'notify'];

    function userClientAdminCtrl($location, $scope, $stateParams, $filter, authService, commonService, userClientAdminService, notify) {
        var vm = this;
        vm.title = $stateParams.title;
        vm.authentication = authService.authentication;
        
        // User
        vm.userTitle = 'Add New User';
        vm.clientTitle = 'Add New Client'
        vm.message = '';
        vm.editMode = false;
        vm.addNewMode = false;
        vm.selectionUserStatuses = ['Active', 'Lockout'];
        vm.selectionClientCode = [];
        vm.clientCodeDlg = [];
        vm.authentication = authService.authentication;
        vm.userDetails = [];
        // name must match to value of column Name int the Roles table
        vm.roles = [{name:'Admin'},
					{name:'Authorise'},
					{name:'Standard'}];
        vm.selection = [];
        vm.toggleSelection = function(roleName)
        {
            var idx = vm.selection.indexOf(roleName);
            // is currently selected
            if (idx > -1) {
                //Remove the first item in an array
                vm.selection.splice(idx, 1);
            }

            // is newly selected
            else {

                //The just below statement allows only one role per user
                vm.selection = [];
                vm.selection.push(roleName);
            }
        }

        // Client
        vm.addNewModeClient = false;
        vm.editModeClient = false;
        vm.clientDetails = [];
        //Server side hadling error for user password
        vm.svrPwdMessage = "";
        vm.errPwdRequired = false;
        vm.errPwdMinlength = false;
        vm.errPwdCompareTo = false;

        //Tam:Added
        vm.types = [{name:'IsClient'},
					{ name: 'IsProductManagement' }];
        vm.selectionType = [];
        vm.toggleClientSelection = function (typeName) {
            var idx = vm.selectionType.indexOf(typeName);
            // is currently selected
            if (idx > -1) {
                //Remove the first item in an array
                vm.selectionType.splice(idx, 1);
            }

                // is newly selected
            else {
                //The just below statement allows only either IsClient or IsProductManangement per client
                vm.selectionType = [];
                vm.selectionType.push(typeName);
                
                //Tam: Refactor to use the same code
                if (typeName === 'IsClient')
                {
                    vm.isClient = true;
                    vm.isProductManagement = false;
                } else {
                    vm.isClient = false;
                    vm.isProductManagement = true;
                }

            }
        }

        //Paging
        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }
        vm.histories = [];
        vm.pageRequestList = [];
        vm.filteredHistories = vm.histories;

        vm.gotoPage = function (pageno) {
            if (pageno < 0 || pageno >= vm.paging.totalPage)
                return;

            vm.paging.isPrev = vm.paging.isNext = true;

            if (pageno == 0)
                vm.paging.isPrev = false;

            if (pageno == (vm.paging.totalPage - 1))
                vm.paging.isNext = false;

            vm.paging.currentPage = pageno;

            vm.pageRequestList = vm.filteredHistories.slice(pageno * 10, (pageno + 1) * 10);

        }

        // Sort by column in the grid
        vm.sortColumn = '';
        vm.sortOrder = true;
        vm.sortData = function (columnName) {
            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.filteredHistories = $filter('orderBy')(vm.filteredHistories, vm.sortColumn, vm.sortOrder);
            vm.gotoPage(0);
        }

        vm.filterObject = {
            'clientCode': '',
            'userStatus': ''
        }
        
        vm.filterRequestList = function (row) {
            var blRequestType = false;

            blRequestType = (
                    (vm.isObjEmpty(vm.filterObject.userStatus) || vm.filterObject.userStatus === vm.userStatus(row.lockoutEndDateUtc))
                    &&
                    (vm.isObjEmpty(vm.filterObject.clientCode) || vm.filterObject.clientCode === row.clientCode)
                );
            return blRequestType;
        };

        vm.isObjEmpty = function (obj) {
            if (obj === undefined || obj === null || obj === '') {
                return true;
            }
            else {
                return false;
            }
        };

        vm.userStatus = function (obj) {
            if (obj === undefined || obj === null || obj === '') {
            return 'Active';
            }
            else {
                return 'Lockout';
            }
        };

        activate();

        ////////////////

        function activate() {
            //Load client code list
            userClientAdminService.getClientCodeList()
                .then(function (response) {
                    vm.selectionClientCode = response;
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });

            if (vm.title === 'User Management') {
                // Below code initialises default role to be standard
                //vm.selection.push('Standard');
                //Initialize user
                vm.editMode = false;
                vm.addNewMode = false;
                vm.svrPwdMessage = "";
                vm.errPwdRequired = false;
                vm.errPwdMinlength = false;
                vm.errPwdCompareTo = false;
                // Load user list
                userClientAdminService.getUserList()
                    .then(function (response) {
                        vm.histories = response;
                        vm.filteredHistories = vm.histories;
                        vm.paging.rowTotal = vm.filteredHistories.length;
                        vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
                        vm.gotoPage(0);
                    }, function (err) {
                        vm.message = commonService.showError(err);
                        notify.showError(vm.message);
                    });
            } else {

                // Initialze client
                vm.addNewModeClient = false;
                vm.editModeClient = false;
                // Load client list
                userClientAdminService.getClientList()
                    .then(function (response) {
                        vm.histories = response;
                        vm.filteredHistories = vm.histories;
                        vm.paging.rowTotal = vm.filteredHistories.length;
                        vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
                        vm.gotoPage(0);
                    }, function (err) {
                        vm.message = commonService.showError(err);
                        notify.showError(vm.message);
                    });
            }
        };

        vm.refresh = function () {
            activate();
        }

        vm.newUser = function () {
            vm.userTitle = 'Add New User';
            vm.editMode = false;
            vm.addNewMode = true;
            vm.resetUser();
            vm.svrPwdMessage = "";
            vm.errPwdRequired = false;
            vm.errPwdMinlength = false;
            vm.errPwdCompareTo = false;
            vm.clientCodeDlg = vm.selectionClientCode;
            
            $('#modalUserDetails').modal('show');
        };
        
        
        vm.editUser = function (userName) {
            vm.addNewMode = false;
            vm.editMode = true;
            vm.userTitle = 'Edit User';
            vm.resetUser();
            vm.svrPwdMessage = "";
            vm.errPwdRequired = false;
            vm.errPwdMinlength = false;
            vm.errPwdCompareTo = false;

            vm.clientCodeDlg = vm.selectionClientCode;
            userClientAdminService.getUserDetails(userName)
                .then(function (response) {
                    vm.userDetails = response;
                    vm.userName = vm.userDetails.userName;
                    vm.firstName = vm.userDetails.firstName;
                    vm.lastName = vm.userDetails.lastName;
                    vm.userEmail = vm.userDetails.email;
                    vm.phoneNumber = vm.userDetails.phoneNumber;
                    vm.clientCode = vm.userDetails.clientCode;
                    vm.selection = vm.userDetails.roleNames;
                    vm.active = vm.userDetails.active;
                    
                    $('#modalUserDetails').modal('show');
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });

        };
        
        vm.saveUser = function () {
            $scope.$broadcast('show-errors-check-validity');
            if ($scope.userForm.$invalid ||
                $scope.userForm.$error.unique ||
                $scope.userForm.$invalid == undefined
                ) { return }

            if (vm.addNewMode) {
                addNewUser();
            } else {
                updateUser();
            }
        }

        vm.resetUser = function () {
            $scope.$broadcast('show-errors-reset');
            vm.userName = "";
            vm.firstName = "";
            vm.lastName = "";
            vm.userEmail = "";
            vm.password = "";
            vm.confirmPassword = "";
            vm.clientCode = '';
            vm.phoneNumber = "";
            //Tam:Added
            vm.selection = [];
        }

        

        vm.resetPassword = function () {
            vm.errPwdRequired = false;
            vm.errPwdMinlength = false;
            vm.errPwdCompareTo = false;
            
            if (vm.password ==="") {
                vm.svrPwdMessage = 'The password is required';
                vm.errPwdRequired = true;
            }
            else if(vm.password.length < 6) {
                vm.svrPwdMessage = 'The password has to be at least six characters';
                vm.errPwdMinlength = true;
            }
            else if(vm.password != vm.confirmPassword){
                vm.errPwdCompareTo = true;
                vm.svrPwdMessage = 'The confirm password is not match';
            }

            if (vm.errPwdRequired || vm.errPwdMinlength || vm.errPwdCompareTo) { return }
            // Valid Data to be saved: Note: Don't need to send email 
            var abc = userClientAdminService.resetPassword(vm.userName, 
                                                            vm.password);
            abc.then(function (response) {
                vm.savedSuccessfully = true;
                vm.message = "Update successfully";
                $('#modalUserDetails').modal('hide');
                vm.resetUser();
                vm.editMode = false;
                vm.addNewMode = false;
                vm.svrPwdMessage = "";
                vm.errPwdRequired = false;
                vm.errPwdMinlength = false;
                vm.errPwdCompareTo = false;
                activate();
                notify.showSuccess("Reset password is success.");
            }, function (err) {
                vm.savedSuccessfully = false;
                vm.message = commonService.showModalError(err, "reset password");
                notify.showError(err);
            });
        
            
        }

        var addNewUser = function () {

            console.log('Here vm.clientCode = ' + vm.clientCode)
            // Valid Data to be saved 
            var abc = userClientAdminService.saveUser(vm.userName,
                                                    vm.firstName,
                                                    vm.lastName,
                                                    vm.userEmail,
                                                    vm.password,
                                                    vm.clientCode,
                                                    vm.phoneNumber,
                                                    vm.selection);
            abc.then(function (response) {
                vm.savedSuccessfully = true;
                vm.message = "Create successfully";
                $('#modalUserDetails').modal('hide');
                activate();
                notify.showSuccess("Add new user is success.");
            }, function (err) {
                vm.savedSuccessfully = false;
                vm.message = commonService.showModalError(err, "create user");
                notify.showError(err);
            });
        };

        var updateUser = function () {
            // Valid Data to be saved 
            var abc = userClientAdminService.updateUser(vm.userName,
                                                    vm.firstName,
                                                    vm.lastName,
                                                    vm.userEmail,
                                                    vm.clientCode,
                                                    vm.phoneNumber,
                                                    vm.selection,
                                                    vm.active);
            abc.then(function (response) {
                vm.savedSuccessfully = true;
                vm.message = "Update successfully";
                $('#modalUserDetails').modal('hide');
                vm.resetUser();
                vm.editMode = false;
                vm.addNewMode = false;
                vm.svrPwdMessage = "";
                vm.errPwdRequired = false;
                vm.errPwdMinlength = false;
                vm.errPwdCompareTo = false;
                activate();
                notify.showSuccess("Update user is success.");
            }, function (err) {
                vm.savedSuccessfully = false;
                vm.message = commonService.showModalError(err, "update user");
                notify.showError(err);
            });
        };

        // Client
        vm.resetClient = function () {
            $scope.$broadcast('show-errors-reset');
            vm.name = '';
            vm.clientCode = '';
            vm.active = '';
            vm.isTermDeposit = '';
            vm.contactName = '';
            vm.contactPhone = '';
            vm.contactEmail = '';
            vm.isClient = false;
            vm.isProductManagement = false;
            //Tam:Added
            vm.selectionType = [];
        };

        vm.newClient = function () {

            vm.clientTitle = 'New Client';
            vm.addNewModeClient = true;
            vm.editModeClient = false;
            vm.resetClient();
            $('#modalClientDetails').modal('show');
        };

        // Load client details based on clientCode
        vm.editClient = function (clientCode) {

            vm.clientTitle = 'Edit Client';
            vm.addNewModeClient = false;
            vm.editModeClient = true;
            vm.resetClient();
            userClientAdminService.getClientDetails(clientCode)
                .then(function (response) {
                    // Assign reponse to the form
                    vm.clientDetails = response;
                    vm.clientCode = vm.clientDetails.clientCode;
                    vm.name = vm.clientDetails.name;
                    vm.active = vm.clientDetails.active;
                    vm.isTermDeposit = vm.clientDetails.isTermDeposit;
                    vm.contactName = vm.clientDetails.contactName;
                    vm.contactPhone = vm.clientDetails.contactPhone;
                    vm.contactEmail = vm.clientDetails.contactEmail;
                    vm.isClient = vm.clientDetails.isClient;
                    vm.isProductManagement = vm.clientDetails.isProductManagement;
                    //Tam:Add
                    vm.selectionType = [];
                    vm.isClient ? vm.selectionType.push('IsClient') : vm.selectionType.push('IsProductManagement')
                    // Display the form
                    $('#modalClientDetails').modal('show');
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });

        };

        vm.saveClient = function () {
            $scope.$broadcast('show-errors-check-validity');
            if ($scope.clientForm.$invalid ||
                $scope.clientForm.$error.unique ||
                $scope.clientForm.$invalid == undefined
                ) { return }

            if (vm.addNewModeClient) {
                addNewClient();
            } else {
                updateClient();
            }
        }

        var addNewClient = function () {
            // Valid Data to be saved 
            var abc = userClientAdminService.saveClient(vm.clientCode,
                                                        vm.name,
                                                        vm.active,
                                                        vm.isTermDeposit,
                                                        vm.contactName,
                                                        vm.contactPhone,
                                                        vm.contactEmail,
                                                        vm.authentication.userName,
                                                        vm.isClient,
                                                        vm.isProductManagement);
            abc.then(function (response) {
                vm.savedSuccessfully = true;
                vm.message = "Create successfully";
                $('#modalClientDetails').modal('hide');
                activate();
                notify.showSuccess("Add new client is success.");
            }, function (err) {
                vm.savedSuccessfully = false;
                vm.message = commonService.showModalError(err, "Create client");
                notify.showError(err);
            });
        };

        var updateClient = function () {
            // Valid Data to be saved 
            var abc = userClientAdminService.updateClient(vm.clientCode,
                                                      vm.name,
                                                      vm.active,
                                                      vm.isTermDeposit,
                                                      vm.contactName,
                                                      vm.contactPhone,
                                                      vm.contactEmail,
                                                      vm.authentication.userName,
                                                      vm.isClient,
                                                      vm.isProductManagement);
            abc.then(function (response) {
                vm.savedSuccessfully = true;
                vm.message = "Update successfully";
                $('#modalClientDetails').modal('hide');
                vm.resetClient();
                vm.addNewModeClient = false;
                vm.editModeClient = false;
                activate();
                notify.showSuccess("Update client is success.");
            }, function (err) {
                vm.savedSuccessfully = false;
                vm.message = commonService.showModalError(err, "Update client");
                notify.showError(err);
            });
        };

        vm.refreshClient = function () {
            activate();
        }

        vm.filterHistory = function (searchCriteria) {
            vm.filteredHistories = $filter('filter')(vm.histories, searchCriteria);
            vm.paging.rowTotal = vm.filteredHistories.length;
            vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
            vm.gotoPage(0);
        }
    }
})();