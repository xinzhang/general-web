﻿(function () {
    'use strict';

    angular.module('app').controller('CorporateActionsCalendarCtrl', CorporateActionsCalendarCtrl);

    CorporateActionsCalendarCtrl.$inject = ['$location', '$scope', '$stateParams', 'authService', 'corporateActionsService', '$filter', 'notify', 'ngSettings'];

    function CorporateActionsCalendarCtrl($location, $scope, $stateParams, authService, corporateActionsService, $filter, notify, ngSettings) {
        var vm = this;

        vm.clientCode = '';
        vm.title = "Corporate Actions Calendar";       

        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        vm.authentication = authService.authentication;

        var $calendar = $("#calendar");

        var calendar = null;

        activate();

        ////////////////

        function activate() {

            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;

            vm.corporateActions = corporateActionsService.getCorporateActions(vm.clientCode);

            vm.events = [];
            _.forEach(vm.corporateActions, function (row) {
                if (row.queue == "active") {
                    var event = { id: "", title: "", start: "" };
                    event.id = row.id;
                    event.title = row.workType;
                    event.start = moment(row.dueDate, "DD-MM-YYYY").format();
                    
                    vm.events.push(event);
                }
            });

            setupCalendar();
        }

        /////////////////////////////

        function setupCalendar(){
            $('#calendar').fullCalendar({

                header: {
                    left: 'title', //,today
                    //center: 'prev, next, today',
                    //right: 'month, agendaWeek, agendaDay' //month, agendaDay,
                },
                eventLimit: true,
                views: {
                    month: {
                        eventLimit: 3 // adjust to 6 only for agendaWeek/agendaDay
                    }
                },
                events: vm.events,
                eventClick: function (calEvent, jsEvent, view) {                    
                    var baseAddress = ngSettings.baseAddress;
                    document.location.href = baseAddress + "/corporateactions/summary/" + calEvent.id;
                }
            })
        }

        // Now events will be refetched every time events scope is updated in controller!!!
        $scope.$watch("events", function (newValue, oldValue) {

            $calendar.fullCalendar('refetchEvents');

        }, true);

        
        vm.today = function () {
            $('.fc-button-today', $calendar).click();
        };

        vm.changeView = function (period) {
            $('#calendar').fullCalendar('changeView', period);
        };
    }

})();