﻿(function () {
    'use strict';

    angular.module('app.dashboard').controller('CorporateActionsSummaryCtrl', CorporateActionsSummaryCtrl);

    CorporateActionsSummaryCtrl.$inject = ['$location', '$scope', '$stateParams', 'chartUtility'];

    function CorporateActionsSummaryCtrl($location, $scope, $stateParams, chartUtility) {
        var vm = this;
        vm.clientCode = '';
        vm.showDetail = false;
        vm.title = "Summary";

        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        //vm.authentication = authService.authentication;
        function showLastSixMonthGraph() {
            //Put data into format for column chart
            var seriesData = [
                {
                    name: 'Urgent',
                    data: [4, 5, 6, 2, 4, 3]
                }, {
                    name: 'New',
                    data: [6, 8, 9, 4, 9, 7]
                }, {
                    name: 'Completed',
                    data: [5, 4, 6, 7, 10, 12]
                }
            ];
            var xCategories = ['Jan', 'Feb', 'March', 'Apr', 'May', 'June'];

            $("#highchart-container").highcharts({
                chart: {
                    type: 'column'
                },
                title: {
                    text: 'Summary by last 6 months'
                },
                xAxis: {
                    categories: xCategories,
                },
                series: seriesData
            })

            //Build Column Chart
            //chartUtility.loadColumnChart(xCategories, seriesData, "#highchart-container", "Last 6 months", "Count", function (event) {
            //    console.log(event.point.category);
            //});
        }

        activate();

        ////////////////

        function activate() {
            /*
            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;           
            */

            console.log('corporateactions summary controller loaded.');
        }

    }
})();