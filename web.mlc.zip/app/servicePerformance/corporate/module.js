'use strict';

angular.module('app.corporate', [
    'ui.router',
    'ngResource'
])

.config(function ($stateProvider) {
    
    $stateProvider
        //Corporate Action summary
        .state('app.corporate', {
            url: '/corporateactions/summary/:corporateid',
            views: {
                "content@app": {
                    controller: 'CorporateActionsSummaryCtrl',
                    templateUrl: 'app/servicePerformance/corporate/summary.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Corporate Actions Summary'
            }
        })

        //Corporate Action Detail
        .state('app.corporate.detail', {        
            url: '/corporate/corporateActionDetail/:corporateid',
            views: {
                "content@app": {
                    controller: 'CorporateActionsCtrl',
                    templateUrl: 'app/servicePerformance/corporate/corporateActionDetail.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'coreporate actions detail'
            }
        });

});
