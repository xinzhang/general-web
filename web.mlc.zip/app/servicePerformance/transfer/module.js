﻿'use strict';

angular.module('app.transfer', [
    'ui.router',
    'ngResource',
    'app.settings'
])

.config(function ($stateProvider) {
    
    $stateProvider
        .state('app.transfer', {
            url: '/servicePerformance/transfer/summary',
            views: {
                "content@app": {
                    controller: 'TransferServicePerformanceCtrl',
                    templateUrl: 'app/servicePerformance/transfer/summary.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Transfer Service Performance'
            }
        })

        .state('app.transferDetail', {
            url: '/servicePerformance/transfer/detail/:title',
            views: {
                "content@app": {
                    controller: 'TransferDetailCtrl',
                    templateUrl: 'app/servicePerformance/transfer/transferDetail.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Transfer'
            }
        })

    .state('app.transferAPIR', {
        url: '/servicePerformance/transfer/APIR/:apir',
        views: {
            "content@app": {
                controller: 'TransferDetailCtrl',
                templateUrl: 'app/servicePerformance/transfer/transferDetail.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: ''
        }
    });

});