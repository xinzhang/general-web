﻿'use strict';

angular.module('app.rebate', [
    'ui.router',
    'ngResource',
    'app.settings'
])

.config(function ($stateProvider) {
    
    $stateProvider
        .state('app.rebate', {
            url: '/servicePerformance/rebate/summary',
            views: {
                "content@app": {
                    controller: 'RebateServicePerformanceCtrl',
                    templateUrl: 'app/servicePerformance/rebate/summary.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Rebate Service Performance'
            }
        })

        .state('app.rebateDetail', {
            url: '/servicePerformance/rebate/detail/:title',
            views: {
                "content@app": {
                    controller: 'RebateDetailCtrl',
                    templateUrl: 'app/servicePerformance/rebate/rebateDetail.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Rebate'
            }
        })

    .state('app.rebateAPIR', {
        url: '/servicePerformance/rebate/APIR/:apir',
        views: {
            "content@app": {
                controller: 'RebateDetailCtrl',
                templateUrl: 'app/servicePerformance/rebate/rebateDetail.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: ''
        }
    });

});