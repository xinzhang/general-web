﻿(function () {
    'use strict';

    angular.module('app.distribution').controller('DistributionDetailCtrl', DistributionDetailCtrl);

    DistributionDetailCtrl.$inject = ['$location', '$scope', '$stateParams', 'commonService', 'authService', 'servicePerformanceService', '$filter', 'serviceNames'];

    function DistributionDetailCtrl($location, $scope, $stateParams, commonService, authService, servicePerformanceService, $filter, serviceNames) {
        
        var vm = this;
        vm.clientCode = '';
        
        //Raw data
        vm.data = [];
        //Initialize fitered data with data
        vm.filteredData = vm.data;
        //Initialize page list 
        vm.pageList = [];
        //Initialize the search criteria
        vm.freeQuery = '';

        //Setup sorting using $filter
        var orderBy = $filter('orderBy');

        //Setup the paging
        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }
        

        if ($stateParams.title) {
            vm.title = $stateParams.title;
        }
        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }
        if ($stateParams.apir) {
            vm.apir = $stateParams.apir;
        }

        vm.authentication = authService.authentication;

        //filtered: use by ng-change on the HTML (page)
        //vm.filterList = function (searchCriteria) {
        vm.filterData = function (searchCriteria) {
            //Filtered
            vm.filteredData = $filter('filter')(vm.data, searchCriteria);
            //Paging filtered data
            vm.paging.rowTotal = vm.filteredData.length;
            vm.paging.totalPage = Math.floor(vm.filteredData.length / 10) + 1;
            vm.gotoPage(0); // Activated first page
        }

        //Function paging
        vm.gotoPage = function (pageno) {
            if (pageno < 0 || pageno >= vm.paging.totalPage)
                return;
            vm.paging.isPrev = vm.paging.isNext = true;
            if (pageno === 0)
                vm.paging.isPrev = false;
            if (pageno === (vm.paging.totalPage - 1))
                vm.paging.isNext = false;
            vm.paging.currentPage = pageno;
            //Load vm.pageList to the grid
            vm.pageList = vm.filteredData.slice(pageno * 10, (pageno + 1) * 10);

            //for current each page item, check if there is notes, if there is then show it as icon
            for (var i=0; i<vm.pageList.length; i++){
                var id = vm.pageList[i].id;
                vm.checkNote(id, vm.pageList[i]);
            }
        }

        //Function Sort
        vm.sortData = function (columnName) {

            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.filteredData = orderBy(vm.filteredData, vm.sortColumn, vm.sortOrder);
            vm.gotoPage(0); //Activate first page
        }

        //
        vm.checkNote = function (id, item) {            
            servicePerformanceService.checkServiceNote(serviceNames.Distribution, id)
                .then(function (response) {
                    if (response)
                        console.log(id + ' has note');
                    item.hasnote = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        };

         //
        vm.showNote = function (id, apir) {
            servicePerformanceService.getServiceNote(serviceNames.Distribution, id)
                .then(function (response) {
                    vm.notes = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                    });
            vm.modalTitle = 'APIR: ' +apir + " - Notes";
            $('#modalDistributionViewNote').modal('show');
    };

        function refresh(response) {
            vm.data = response;
            vm.filteredData = vm.data;
            //Sort data base on expectedDate
            vm.sortData('expectedDate');
            vm.sortOrder = true;

            //Paging data
            vm.paging.rowTotal = vm.filteredData.length;
            vm.paging.totalPage = Math.floor(vm.filteredData.length / 10) + 1;
            vm.gotoPage(0); // Activate first page
        };

        activate();

        vm.searchByAPIR = function () {
            if (vm.apir != undefined) {
                $location.path("/servicePerformance/distribution/APIR/" + vm.apir)
            }
        }

        ////////////////

        function activate() {
            $scope.$on('LastRepeaterElement', function () {
                $('.popover-dismiss').popover({
                    trigger: 'focus',
                    html: 'true'
                });
            });

            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;

            // Sort by column in the grid
            vm.sortColumn = 'expectedDate';

            if (vm.apir != undefined) {
                vm.title = "Search by APIR code";
                servicePerformanceService.getServiceDataByAPIR(serviceNames.Distribution, vm.apir)
                    .then(function (response) {
                        refresh(response)
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
            }
            else {
                //Get data
                servicePerformanceService.getServiceOverviewData(serviceNames.Distribution, vm.title)
                    .then(function (response) {
                        refresh(response)
                    }, function (err) {
                        vm.errorMessage = commonService.showError(err);
                    });
            }
        }

    }
})();