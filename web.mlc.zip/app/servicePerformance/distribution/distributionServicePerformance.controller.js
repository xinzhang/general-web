﻿(function () {
    'use strict';

    angular.module('app.distribution').controller('DistributionServicePerformanceCtrl', DistributionServicePerformanceCtrl);

    DistributionServicePerformanceCtrl.$inject = ['$location', '$scope', '$stateParams', 'commonService', 'authService', 'servicePerformanceService', 'notify', 'ngSettings', 'serviceNames'];

    function DistributionServicePerformanceCtrl($location, $scope, $stateParams, commonService, authService, servicePerformanceService, notify, ngSettings, serviceNames) {
        var vm = this;
        vm.clientCode = '';
        vm.title = "Distribution Service Performance";

        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        vm.authentication = authService.authentication;
        var calendarMonth = moment().format('MMMM YYYY');

        $scope.category = '';        

        function showDistributionOverviewPieChart(_dataSource) {
            $('#distributionOverviewPieChart').highcharts({
                chart: {
                    backgroundColor: null,
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'pie'
                },
                    
                title: {
                    text: 'Distribution Processing Overview ' + calendarMonth,
                    style: {
                        color: '#000',
                        fontWeight: 'bold'
                    }
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.y}</b>',
                    percentageDecimals: 0
                },

                plotOptions: {
                    pie: {
                        //size: '60%',
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            //distance: 5,
                            enabled: true,
                            format: '{point.name}'
                        },
                        showInLegend: true
                    }
                },

                credits: {
                    enabled: false
                },                 
                    

                legend: {
                    labelFormat: '{name}: <b>{y}</b>',
                    itemStyle: {
                        color: '#000'
                    },
                    itemHoverStyle: {
                        color: '#FFF'
                    },
                    itemHiddenStyle: {
                        color: '#333'
                    }
                },
                series: [{
                    type: 'pie',
                    name: 'Test',
                    data: _dataSource,
                    events: {
                        click: function (event) { vm.getDetailsByCategory(event.point.name); }
                    },
                }]
            });
        }

        //Load MLC Distribution Processing Overview Pie Chart
        vm.loadDistributionOverviewPieChart = function () {

            servicePerformanceService.getServiceOverview(serviceNames.Distribution)
            .then(function (response) {
                showDistributionOverviewPieChart(response);
            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            })
           
        }

        //Routing to distributionDetail page
        vm.getDetailsByCategory = function (name) {            
            document.location.href = "index.html#/servicePerformance/distribution/detail/" + name;
        }

        //show MLC FM Performance Trending Line Cahrt
        function showFMPerformanceTrendingLineChart(_dataSource) {

            //Build data for chart
            var nameForecast = 'Forecast from FM';
            var nameActual = 'Actual from FM';
            var forecastArray = [];
            var actualArray = [];
            var axisLabelArray = [];
            for (var x in _dataSource) {
                console.log(_dataSource[x]);
                forecastArray.push(_dataSource[x].forecast);
                actualArray.push(_dataSource[x].actual);
                var dateonly = _dataSource[x].weekEndDate.substr(0, _dataSource[x].weekEndDate.indexOf("T"))
                axisLabelArray.push(_dataSource[x].weekEnd + "<br/>" + dateonly);
            }
            
            //Load pie chart for Distribution Processing Overview
            $('#fundManagerPerformanceTrendingLineChart').highcharts({
                chart: {
                    backgroundColor: null,
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                },
                title: {
                    text: 'Fund Manager Performance Trending',
                    x: -20, //center
                    style: {
                        color: '#000',
                        fontWeight: 'bold'
                    }
                },
                subtitle: {
                    text: 'Source: Ausmaq.com.au',
                    x: -20
                },
                xAxis: {
                    categories: axisLabelArray
                },
                yAxis: {
                    title: {
                        text:''
                    },
                    plotLines: [{
                        value: 0,
                        width: 1,
                        color: '#808080'
                    }]
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle',
                    borderWidth: 0
                },
                series: [{
                    name: nameForecast,
                    data: forecastArray,
                    events: {
                        click: function (event) {
                            console.log(event);
                            //vm.getDetailsByCategory(event.point.series.name);
                        }
                    },
                }, {
                    name: nameActual,
                    data: actualArray,
                    events: {
                        click: function (event) {
                            console.log(event);
                            //vm.getDetailsByCategory(event.point.series.name);
                        }
                    },
                }]
            });
        }

        //Load MLC FM Performance Trending Line Cahrt
        vm.loadFMPerformanceTrendingLineChart = function () {

            servicePerformanceService.getFMPerformanceTrending(serviceNames.Distribution)
            .then(function (response) {
                showFMPerformanceTrendingLineChart(response);
            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            })

        }

        function showProcessingManagementDailyStackedColumnChart(_dataSource) {           
            //Build data for chart
            var dateArray = [];
            var rpName = '';
            var outstading = '';
            var rpDataArray = [];
            var outstandingName = '';
            var outstadingDataArray = [];

            for (var x in _dataSource) {
                var dateonly = _dataSource[x].date.substr(0, _dataSource[x].date.indexOf("T"))
                dateArray.push(dateonly);
                rpName = _dataSource[x].rpName;
                rpDataArray.push(_dataSource[x].rpData);
                outstandingName = _dataSource[x].outstandingName;
                outstadingDataArray.push(_dataSource[x].outstandingData);
            }

            //Build Stacked Column Chart
            var chartTitle = 'Distribution Processing Management Overview';
            
            $('#distributionProcessingManagementOviewStackedColumnChart').highcharts({
                chart: {
                    backgroundColor: null,
                    type: 'column'
                },
                credits: {
                    enabled: false
                },
                title: {
                    text: chartTitle,
                    x: -20, //center
                    style: {
                        color: '#000',
                        fontWeight: 'bold'
                    }
                },
                xAxis: {
                    categories: dateArray
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: ''
                    }
                },

                tooltip: {
                    headerFormat: '<b>{point.x}</b><br/>',
                    pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
                },
                plotOptions: {
                    column: {
                        stacking: 'normal',
                        dataLabels: {
                            enabled: true,
                            color: '#000',
                            format: '<b>{y}</b>'
                        }
                    }
                },

                legend: {
                    itemStyle: {
                        color: '#000'
                    },
                    itemHoverStyle: {
                        color: '#FFF'
                    },
                    itemHiddenStyle: {
                        color: '#333'
                    }
                },
                series: [{
                    name: outstandingName,
                    data: outstadingDataArray,
                    events: {
                        click: function (event) { } //TBA
                    },
                },
                {
                    name: rpName,
                    data: rpDataArray,
                    events: {
                        click: function (event) { } //TBA
                    },
                }]
            });
        }

        //Load MLC FM Performance Trending Line Cahrt
        vm.loadProcessingManagementDailyStackedColumnChart = function () {

            servicePerformanceService.getProcessingManagementDaily(serviceNames.Distribution)
            .then(function (response) {                
                for (var key in response) {
                    vm.weeks.push(key);
                }
                vm.currentWeek = vm.weeks[0];
                vm.processManagmentDailyData = response;
                
                showProcessingManagementDailyStackedColumnChart(vm.processManagmentDailyData[vm.currentWeek]);
            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            })
        }

        vm.updateWeekGraph = function () {
            console.log(vm.processManagmentDailyData[vm.currentWeek]);

            if (vm.processManagmentDailyData.length == 0)
                return;

            showProcessingManagementDailyStackedColumnChart(vm.processManagmentDailyData[vm.currentWeek]);
        }

        activate();

        ////////////////

        function activate() {

            if (vm.authentication.adiCode != '')
                vm.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.clientCode = vm.authentication.tdOrgCode;

            vm.detailAPIR = '';
            vm.weeks = [];
            vm.currentWeek = "";

            vm.loadDistributionOverviewPieChart();
            vm.loadFMPerformanceTrendingLineChart();
            vm.loadProcessingManagementDailyStackedColumnChart();
        }

        vm.viewDetailAPIR = function () {
            console.log(vm.detailAPIR);

            if (vm.detailAPIR == '')
                return;

            $location.path("/servicePerformance/distribution/APIR/" + vm.detailAPIR)
        }
    }
})();