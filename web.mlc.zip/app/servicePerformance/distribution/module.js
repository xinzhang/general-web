﻿'use strict';

angular.module('app.distribution', [
    'ui.router',
    'ngResource',
    'app.settings'
])

.config(function ($stateProvider) {
    
    $stateProvider
        .state('app.distribution', {
            url: '/servicePerformance/distribution/summary',
            views: {
                "content@app": {
                    controller: 'DistributionServicePerformanceCtrl',
                    templateUrl: 'app/servicePerformance/distribution/summary.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Distribution Service Performance'
            }
        })

        .state('app.distributionDetail', {
            url: '/servicePerformance/distribution/detail/:title',
            views: {
                "content@app": {
                    controller: 'DistributionDetailCtrl',
                    templateUrl: 'app/servicePerformance/distribution/distributionDetail.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Distribution'
            }
        })

    .state('app.distributionAPIR', {
        url: '/servicePerformance/distribution/APIR/:apir',
        views: {
            "content@app": {
                controller: 'DistributionDetailCtrl',
                templateUrl: 'app/servicePerformance/distribution/distributionDetail.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: ''
        }
    });

});