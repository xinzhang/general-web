﻿'use strict';

angular.module('app.secrec', [
    'ui.router',
    'ngResource',
    'app.settings'
])

.config(function ($stateProvider) {
    
    $stateProvider
        .state('app.secrec', {
            url: '/servicePerformance/secrec/summary',
            views: {
                "content@app": {
                    controller: 'SecRecServicePerformanceCtrl',
                    templateUrl: 'app/servicePerformance/secrec/summary.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Security Reconciliation Service Performance'
            }
        })

        .state('app.secrecDetail', {
            url: '/servicePerformance/secrec/detail/:title',
            views: {
                "content@app": {
                    controller: 'SecRecDetailCtrl',
                    templateUrl: 'app/servicePerformance/secrec/secrecDetail.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Security Reconciliation'
            }
        })

    .state('app.secrecAPIR', {
        url: '/servicePerformance/secrec/APIR/:apir',
        views: {
            "content@app": {
                controller: 'SecRecDetailCtrl',
                templateUrl: 'app/servicePerformance/secrec/secrecDetail.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: ''
        }
    })

    //.state('app.secrecSearchBy', {
    //    url: '/servicePerformance/secrec/SearchBy/:apir/:issuer',
    //    views: {
    //        "content@app": {
    //            controller: 'SecRecDetailCtrl',
    //            templateUrl: 'app/servicePerformance/secrec/secrecDetail.html',
    //            params: { APIR: null, Issuer: null },
    //            controllerAs: 'vm'
    //        }
    //    },
    //    data: {
    //        title: ''
    //    }
    //})

});