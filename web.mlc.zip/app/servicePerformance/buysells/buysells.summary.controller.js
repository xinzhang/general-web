﻿(function () {
    'use strict';

    angular.module('app.buysells').controller('BuysellsSummaryCtrl', BuysellsSummaryCtrl);

    BuysellsSummaryCtrl.$inject = ['$location', '$scope', '$stateParams', 'commonService', 'authService', 'buysellsService', 'noteService', 'notify', 'ngSettings' , '$filter'];

    function BuysellsSummaryCtrl($location, $scope, $stateParams, commonService, authService, buysellsService, noteService, notify, ngSettings, $filter) {

        var vm = this;
        vm.clientCode = '';
        vm.title = '';

        // Unbatched Orders
        //Raw data
        vm.data = [];
        //Initialize fitered data
        vm.filteredData = vm.data;
        //Initialize page list 
        vm.pageList = [];
        //Initialize the search criteria
        vm.freeQuery = '';

        //Setup sorting using $filter
        var orderBy = $filter('orderBy');

        //Setup the paging
        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }

        //filtered: use by ng-change on the view (HTML page)
        //vm.filterData(vm.freeQuery)
        vm.filterData = function (searchCriteria) {
            //Filtered
            vm.filteredData = $filter('filter')(vm.data, searchCriteria);
            //Paging filtered data
            vm.paging.rowTotal = vm.filteredData.length;
            vm.paging.totalPage = Math.floor(vm.filteredData.length / 10) + 1;
            vm.gotoPage(0); // Activated first page
        }

        //Function paging
        vm.gotoPage = function (pageno) {
            if (pageno < 0 || pageno >= vm.paging.totalPage)
                return;
            vm.paging.isPrev = vm.paging.isNext = true;
            if (pageno === 0)
                vm.paging.isPrev = false;
            if (pageno === (vm.paging.totalPage - 1))
                vm.paging.isNext = false;
            vm.paging.currentPage = pageno;
            //Load vm.pageList to the grid
            vm.pageList = vm.filteredData.slice(pageno * 10, (pageno + 1) * 10);

            //TN: Removed
            //for current each page item, check if there is notes, if there is then show it as icon
            //for (var i = 0; i < vm.pageList.length; i++) {
            //    var id = vm.pageList[i].orderNo;
            //    vm.checkNote(id, vm.pageList[i]);
            //}
        }

        //Function Sort
        vm.sortData = function (columnName) {
            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.filteredData = orderBy(vm.filteredData, vm.sortColumn, vm.sortOrder);
            vm.gotoPage(0); //Activate first page
        }
        // End Unbatched Orders

        vm.total = 0;
        vm.totalBuy = 0;
        vm.totalSell = 0;
        //
        vm.checkNote = function (id, item) {
            noteService.checkNote('Order', id)
                .then(function (response) {
                    item.hasnote = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        };

        //
        vm.showNote = function (id, orderRef) {
            console.log(id);
            noteService.getNote('Order', id)
                .then(function (response) {
                    vm.notes = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
            vm.modalTitle = 'Order: ' + orderRef + " - Notes";
            $('#modalViewNote').modal('show');
        };

        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        vm.authentication = authService.authentication;
        if (vm.authentication.adiCode != '')
            vm.clientCode = vm.authentication.adiCode;
        else if (vm.authentication.tdOrgCode != '')
            vm.clientCode = vm.authentication.tdOrgCode;

        vm.showOverdueAreaChart = function () {
            var chartTitle = 'Overdue';
            var categoryArray = []; // horizontal axis
            var seriesArray = [];

            for (var x in vm.overdueData) {
                categoryArray = vm.overdueData[x].plan;
                seriesArray.push({ name: vm.overdueData[x].name, data:vm.overdueData[x].count})
            }
            
            //Load area chart for overdue
            $('#overdueAreaChart').highcharts({
                chart: {
                    backgroundColor: null,
                    type: 'area'
                },
                title: {
                    text: chartTitle,
                    x: -20, //center
                    style: {
                        color: '#000',
                        fontWeight: 'bold'
                    }
                },
                subtitle: {
                    text: 'Source: Ausmaq.com.au'
                },
                xAxis: {
                    categories: categoryArray,
                    tickmarkPlacement: 'on',
                    title: {
                        enabled: false
                    }
                },
                yAxis: {
                    title: {
                        text: ''
                    },
                    labels: {
                        formatter: function () {
                            return this.value;
                        }
                    }
                },
                tooltip: {
                    shared: true,
                    valueSuffix: ''
                },
                plotOptions: {
                    area: {
                        stacking: 'normal',
                        lineColor: '#666666',
                        lineWidth: 1,
                        marker: {
                            lineWidth: 1,
                            lineColor: '#666666'
                        }
                    },
                    series: {
                        cursor: 'pointer',
                        point: {
                            events: {
                                    click: function () {                                        
                                        vm.getDetailsByCategory("overdue", this.series.name, this.category)
                                    }
                            }
                        }
                    }
                },
                //Assign value to plot
                series: seriesArray
                
            });
        }

        //Load coverdue data to column chart
        vm.loadOverdueAreaChart = function () {
            buysellsService.getOverdueData(vm.clientCode)
                .then(function (response) {
                    vm.overdueData = response;
                    vm.showOverdueAreaChart();
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        }

        //TN: Load data fo pie chart
        vm.loadOverViewPieChart = function () {
            buysellsService.getBuySellsOverViewData(vm.clientCode)
                .then(function (response) {
                    showBuySellsOverviewPieChart(response);
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        }
        //TN: Show Buy & Sell pie chart
        function showBuySellsOverviewPieChart(_dataSource) {
            $('#buysellsOverviewPieChart').highcharts({
                chart: {
                    backgroundColor: null,
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'pie'
                },

                title: {
                    text: 'Buy & Sell Overview ', 
                    style: {
                        color: '#000',
                        fontWeight: 'bold'
                    }
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.y}</b>',
                    percentageDecimals: 0
                },

                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '{point.name}'
                        },
                        showInLegend: true
                    }
                },

                credits: {
                    enabled: false
                },


                legend: {
                    labelFormat: '{name}: <b>{y}</b>',
                    itemStyle: {
                        color: '#000'
                    },
                    itemHoverStyle: {
                        color: '#FFF'
                    },
                    itemHiddenStyle: {
                        color: '#333'
                    }
                },
                series: [{
                    type: 'pie',
                    name: 'Test',
                    data: _dataSource,
                    events: {
                        click: function (event) { vm.getDetailsByCategory("buy & sell overview", " ", event.point.name); }
                    },
                }]
            });
        }



        //Load confirmation forecast data to column chart
        vm.showConfirmationForecastColumnChart = function () {
            
            var chartTitle = 'Confirmation Forecast';
            var categoryArray = []; // horizontal axis
            var seriesArray = [];

            for (var x in vm.confirmationForecastData) {
                categoryArray = vm.confirmationForecastData[x].plan;
                seriesArray.push({ name: vm.confirmationForecastData[x].name, data: vm.confirmationForecastData[x].count})
            }
            $('#confirmationForecastColumnChart').highcharts({
                chart: {
                    backgroundColor: null,
                    type: 'column'
                },
                title: {
                    text: chartTitle,
                    x: -20, //center
                    style: {
                        color: '#000',
                        fontWeight: 'bold'
                    }
                },
                subtitle: {
                    text: 'Source: Ausmaq.com.au'
                },
                xAxis: {
                    categories: categoryArray,
                    crosshair: true
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: ''
                    }
                },
                tooltip: {
                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                        '<td style="padding:0"><b>{point.y}</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
                },

                plotOptions: {
                    column: {
                        pointPadding: 0.2,
                        borderWidth: 0,
                        //Add value as label on each column
                        dataLabels: {
                            enabled: true,
                            color: '#000',
                            format: '<b>{y}</b>'
                        }
                    },
                    series: {
                        cursor: 'pointer',
                        point: {
                            events: {
                                click: function () {                                    
                                    vm.getDetailsByCategory("confirmationforecast", this.series.name, this.category)
                                }
                            }
                        }
                    }
                },
                //Assign value to plot
                series: seriesArray
            });
        }

        vm.loadConfirmationForecastColumnChart = function () {
            buysellsService.getConfirmationForecastData(vm.clientCode)
            .then(function (response) {
                vm.confirmationForecastData = response;
                vm.showConfirmationForecastColumnChart();
            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            })

        }

        //Load daily confirmation position data to stacked column chart
        vm.showDailyConfirmationPositionStackedColumnChart = function () {
            
            var categoryArray = []; // horizontal axis
            var seriesArray = [];

            for (var x in vm.dailyConfirmationPositionData) {
                categoryArray = vm.dailyConfirmationPositionData[x].plan;
                seriesArray.push({ name: vm.dailyConfirmationPositionData[x].name, data: vm.dailyConfirmationPositionData[x].count })
            }
           
            //Build Stacked Column Chart
            var chartTitle = 'Daily Confirmation Position';
            
            $('#dailyConfirmationPositionStackedColumnChart').highcharts({
                chart: {
                    backgroundColor: null,
                    type: 'column'
                },
                credits: {
                    enabled: false
                },
                title: {
                    text: chartTitle,
                    x: -20, //center
                    style: {
                        color: '#000',
                        fontWeight: 'bold'
                    }
                },
                subtitle: {
                    text: 'Source: Ausmaq.com.au'
                },
                xAxis: {
                    categories: categoryArray
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: ''
                    }
                },
                tooltip: {
                    headerFormat: '<b>{point.x}</b><br/>',
                    pointFormat: '{series.name}: {point.y} <br/>Total: {point.stackTotal}'
                },
                plotOptions: {
                    column: {
                        //stacking: 'normal',
                        pointPadding: 0.2,
                        borderWidth: 0,                        
                        dataLabels: {
                            enabled: true,
                            color: '#000',
                            format: '<b>{y}</b>'
                        }
                    },
                    series: {
                        cursor: 'pointer',
                        point: {
                            events: {
                                click: function () {

                                    vm.getDetailsByCategory("dailyConfirmation", this.series.name, this.category)

                                    }
                            }
                        }
                    }
                },

                legend: {
                    itemStyle: {
                        color: '#000'
                    },
                    itemHoverStyle: {
                        color: '#FFF'
                    },
                    itemHiddenStyle: {
                        color: '#333'
                    }
                },
                //Assign value to plot
                series: seriesArray
               
            });
        }

        vm.loadDailyConfirmationPositionStackedColumnChart = function () {
            
            buysellsService.getDailyConfirmationPositionData(vm.clientCode)
           .then(function (response) {
               vm.dailyConfirmationPositionData = response;
               vm.showDailyConfirmationPositionStackedColumnChart();
           }, function (err) {
               vm.errorMessage = commonService.showError(err);
           })
        }

        //Load unbatched order data
        function refresh(response) {
            vm.data = response;
            vm.filteredData = vm.data;
            
            vm.sortData('orderReference');
            vm.sortOrder = true;

            //Paging data
            vm.paging.rowTotal = vm.filteredData.length;
            vm.paging.totalPage = Math.floor(vm.filteredData.length / 10) + 1;
            vm.gotoPage(0); // Activate first page
        };

        //Calculate Total for footer
        function calculateTotals(response) {
            //get total
            vm.total = 0;
            vm.totalBuy = 0;
            vm.totalSell = 0;
            for (var prop in response) {
                if (response.hasOwnProperty(prop)) {
                    vm.total = vm.total + response[prop].buyCount + response[prop].sellCount;
                    vm.totalBuy = vm.totalBuy + response[prop].buyCount;
                    vm.totalSell = vm.totalSell + response[prop].sellCount;
                }
            }
        };

        vm.loadUnbatchedOrderData = function () {
            vm.title = 'Unbatched Orders';
            /* Old
            //Get data
            buysellsService.getUnbatchedOrderData()
            .then(function (response) {
                refresh(response)
            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            });
            */
            buysellsService.getUnbatchedOverviewData()
            .then(function (response) {
                calculateTotals(response);
                refresh(response);
            }, function (err) {
                vm.errorMessage = commonService.showError(err);
            });
        }

        vm.getDetailsByCategory = function (graph, buysells, category) {
            document.location.href = "index.html#/servicePerformance/buysells/detail/" + graph + "/" + buysells + "/" + category;
        }

        activate();

        ////////////////

        function activate() {

            //if (vm.authentication.adiCode != '')
            //    vm.clientCode = vm.authentication.adiCode;
            //else if (vm.authentication.tdOrgCode != '')
            //    vm.clientCode = vm.authentication.tdOrgCode;

            //Tam:OrderRef
            vm.detailOrderRef = '';
            //TN:
            vm.loadOverViewPieChart();

            //vm.loadOverdueAreaChart();
            vm.loadConfirmationForecastColumnChart();
            vm.loadDailyConfirmationPositionStackedColumnChart();
            vm.loadUnbatchedOrderData();
            
        }

        vm.viewDetailOrderRef = function () {
            console.log(vm.detailOrderRef);

            if (vm.detailOrderRef == '')
                return;
            
            $location.path("/servicePerformance/buysells/OrderRef/" +  vm.detailOrderRef);
        }
    }
})();