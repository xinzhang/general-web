﻿(function () {
    'use strict';

    angular.module('app.buysells').controller('BuysellsDetailCtrl', BuysellsDetailCtrl);

    BuysellsDetailCtrl.$inject = ['$location', '$scope', '$stateParams', 'commonService', 'authService', 'buysellsService', 'noteService', 'notify', 'ngSettings', '$filter'];

    function BuysellsDetailCtrl($location, $scope, $stateParams, commonService, authService, buysellsService, noteService, notify, ngSettings, $filter) {

        var vm = this;
        vm.clientCode = '';
        vm.title = '';

        // Unbatched Orders
        //Raw data
        vm.data = [];
        //Initialize fitered data
        vm.filteredData = vm.data;
        //Initialize page list 
        vm.pageList = [];
        //Initialize the search criteria
        vm.freeQuery = '';

        //Tam:OrderRef
        vm.hasOrderRef = false;

        vm.buysellsList = ["Application", "Redemption"];
        vm.overdueList = ["T+5", "T+6", "T+7", "T>7"];
        vm.forecastList = ["T+1", "T+2", "T+3", "T+4"];

        vm.investorList = ["P1","P2","P3","P4","P5","P6"];

        //Setup sorting using $filter
        var orderBy = $filter('orderBy');

        //Setup the paging
        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }

        //filtered: use by ng-change on the view (HTML page)
        //vm.filterData(vm.freeQuery)
        vm.filterData = function (searchCriteria) {
            //Filtered
            vm.filteredData = $filter('filter')(vm.data, searchCriteria);
            //Paging filtered data
            vm.paging.rowTotal = vm.filteredData.length;
            vm.paging.totalPage = Math.floor(vm.filteredData.length / 10) + 1;
            vm.gotoPage(0); // Activated first page
        }

        //Function paging
        vm.gotoPage = function (pageno) {
            if (pageno < 0 || pageno >= vm.paging.totalPage)
                return;
            vm.paging.isPrev = vm.paging.isNext = true;
            if (pageno === 0)
                vm.paging.isPrev = false;
            if (pageno === (vm.paging.totalPage - 1))
                vm.paging.isNext = false;
            vm.paging.currentPage = pageno;

            //Load vm.pageList to the grid
            vm.pageList = vm.filteredData.slice(pageno * 10, (pageno + 1) * 10);

            //for current each page item, check if there is notes, if there is then show it as icon
            for (var i = 0; i < vm.pageList.length; i++) {
                var id = vm.pageList[i].orderNo;
                vm.checkNote(id, vm.pageList[i]);
            }
        }

        //Function Sort
        vm.sortData = function (columnName) {
            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.filteredData = orderBy(vm.filteredData, vm.sortColumn, vm.sortOrder);
            vm.gotoPage(0); //Activate first page
        }
        // End Unbatched Orders

        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }

        if ($stateParams.title) {
            vm.graph = $stateParams.title;

            console.log("vm.graph: " + vm.graph);
        }

        if ($stateParams.buysells) {
            vm.buysells = $stateParams.buysells;

            console.log("vm.buysells: " + vm.buysells);
        }

        if ($stateParams.category) {
            vm.category = $stateParams.category;

            console.log("vm.category: " + vm.category) ;
        }

        //Tam:OrderRef
        if ($stateParams.orderRef) {
            vm.orderRef = $stateParams.orderRef;
            vm.hasOrderRef = true;
        }

        vm.authentication = authService.authentication;
        if (vm.authentication.adiCode != '')
            vm.clientCode = vm.authentication.adiCode;
        else if (vm.authentication.tdOrgCode != '')
            vm.clientCode = vm.authentication.tdOrgCode;

        //Load unbatched order data
        function refresh(response) {
            vm.data = response;
            vm.filteredData = vm.data;

            vm.sortData('orderReference');
            vm.sortOrder = true;

            //Paging data
            vm.paging.rowTotal = vm.filteredData.length;
            vm.paging.totalPage = Math.floor(vm.filteredData.length / 10) + 1;
            vm.gotoPage(0); // Activate first page
        };
       
        //TN: To be replaced by getCategoryDetail()
        vm.getOverdueDetail = function () {
            
            if (vm.graph != "overdue")
                return;

            vm.title = "Overdue";

            //Get data
            buysellsService.getOverdueDetail(vm.buysells, vm.category)
                .then(function (response) {
                    refresh(response)
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        }
        //TN: Relaced above vm.getOverdueDetail
        vm.getCategoryDetail = function () {

            if (vm.graph != "buy & sell overview")
                return;

            vm.title = vm.category;



            //Get data
            buysellsService.getDetailByCategory(vm.category)
                .then(function (response) {
                    refresh(response)
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        }

        //TN: Add new
        vm.getUnbatchedDetailByCategory = function () {
            
            if (!(vm.buysells == 'S' || vm.buysells == 'B' || vm.buysells == 'BS'))
                return;

            vm.title = $stateParams.title; //vm.graph
            //Get data
            
            //Get data 
            buysellsService.getUnbatchedDetailByCategory(vm.buysells, vm.category)
                .then(function (response) {
                    refresh(response)
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        }

        vm.getConfirmationforecastDetail = function () {

            if (vm.graph != "confirmationforecast")
                return;

            vm.title = "Confirmation Forecast";

            var age = vm.category.substr(2, 1);

            //Get data
            buysellsService.getConfirmationForecastDetail(vm.buysells, age)
                .then(function (response) {
                    refresh(response)
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        }

        vm.getDailyConfirmationDetail = function () {

            if (vm.graph != "dailyConfirmation")
                return;

            vm.title = "Daily Confirmation Position";

            //Get data
            // for daily confirmation,vm.category is the investor name, just pass this one to controller
            buysellsService.getDailyConfirmationPositionDetail(vm.buysells, vm.category)
                .then(function (response) {
                    refresh(response)
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        }

        //
        vm.checkNote = function (id, item) {
            noteService.checkNote('Order', id)
                .then(function (response) {
                    item.hasnote = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
        };

        //
        vm.showNote = function (id, orderRef) {
            noteService.getNote('Order',id)
                .then(function (response) {
                    vm.notes = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });
            vm.modalTitle = 'Order: ' + orderRef + " - Notes";
            $('#modalViewNote').modal('show');
        };

        activate();

        ////////////////

        function activate() {

            if (vm.orderRef != undefined) {
                vm.title = "Search by Order Reference";
                buysellsService.getOrderByRef(vm.orderRef)
                    .then(function (response) {
                        refresh(response)
                    }, function (err) {
                        vm.errorMessage = commonService.showError(err);
                    });
            }
            else{ //Get date
                //vm.getOverdueDetail();
                //TN
                vm.getCategoryDetail();
                vm.getUnbatchedDetailByCategory();


                vm.getConfirmationforecastDetail();
                vm.getDailyConfirmationDetail();
            }

            
        }

        vm.datarefresh = function () {
            activate();
        }

        vm.searchByOrderRef = function () {
            if (vm.orderRef != undefined) {
                //$location.path("/servicePerformance/distribution/APIR/" + vm.apir)
                $location.path("/servicePerformance/buysells/OrderRef/" + vm.orderRef);
            }
        }
    }
})();