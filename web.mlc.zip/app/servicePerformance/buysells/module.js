﻿'use strict';

angular.module('app.buysells', [
    'ui.router',
    'ngResource',
    'app.settings'
])

.config(function ($stateProvider) {
    
    $stateProvider
        .state('app.buysells', {
            url: '/buysells/summary',
            views: {
                "content@app": {
                    controller: 'BuysellsSummaryCtrl',
                    templateUrl: 'app/servicePerformance/buysells/summary.html',
                    controllerAs: 'vm'
                }
            },
            data: {
                title: 'Buys & Sells'
            }
        })

   $stateProvider
            .state('app.buysellsDetail', {                
                url: '/servicePerformance/buysells/detail/:title/:buysells/:category',
                views: {
                    "content@app": {
                        controller: 'BuysellsDetailCtrl',
                        templateUrl: 'app/servicePerformance/buysells/buysellsDetails.panel.html',
                        controllerAs: 'vm'
                    }
                },
                data: {
                    title: 'Buys & Sells',
                    category: '',

                }
            })

    //Tam:OrderRef
    .state('app.buysellsOrderRef', {
        url: '/servicePerformance/buysells/OrderRef/:orderRef',
        views: {
            "content@app": {
                controller: 'BuysellsDetailCtrl',
                templateUrl: 'app/servicePerformance/buysells/buysellsDetails.panel.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: ''
        }
    })
});