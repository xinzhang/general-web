﻿(function () {
    'use strict';

    angular.module('app.layout').controller('NavigationCtrl', NavigationCtrl);

    NavigationCtrl.$inject = ['$scope', '$stateParams', 'authService'];
    
    function NavigationCtrl($scope, $stateParams, authService) {

        var vm = this;
        // Get authDate using authService
        var authData = authService.authentication;

        console.log('NavigationCtrl loaded.' + authData);
        console.log(authData);

        //Used by latest rates
        vm.authentication = authService.authentication; 

        vm.menuAuthenticate = {
            isMLC: false,
            isTdClient: false,
            isADI: false,
            isAdmin: false
        }

        activate();

        ////////////////

        function activate() {
            console.log('NavigationCtrl-> roleName: ' + authData.roleName);
            console.log(authData);

            //For MLC
            //Tam:Removed
            //vm.menuAuthenticate.isMLC = (authData.tdOrgCode == 'MLC');
            //Tam:Added
            vm.menuAuthenticate.isMLC = (authData.tdOrgCode == 'MLC' && !authData.isAdmin);
            //For TdClient
            //Tam:Removed
            //vm.menuAuthenticate.isTdClient = (authData.isClient && authData.isTermDeposit);
            //Tam:Added
            vm.menuAuthenticate.isTdClient = (authData.isClient && authData.isTermDeposit && !authData.isAdmin);
            //For ADI
            vm.menuAuthenticate.isADI = (authData.isProductManagement && authData.isTermDeposit);
            //For Admin. Need to refine for each organisation
            vm.menuAuthenticate.isAdmin = (authData.tdOrgCode == 'AMQ');
        }
    }

})();