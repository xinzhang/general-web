﻿(function () {
    'use strict';

    angular.module('app.layout').controller('HeaderCtrl', HeaderCtrl);

    HeaderCtrl.$inject = ['$window', '$scope', '$stateParams', 'authService', 'ngSettings'];

    function HeaderCtrl($window,$scope, $stateParams, authService) {

        var vm = this;

        // Get authDate using authService
        vm.authData = authService.authentication;
        vm.searchArea = 'Please Select';
        
        activate();

        ////////////////

        function activate() {
        };

        vm.logout = function () {
            authService.logout();
            $window.location.href = 'home.html#/account/login';
        };

        vm.selectSearchArea = function (a) {
            vm.searchArea = a;
        };

        $scope.status = {
            isopen: false
        };

        $scope.toggled = function (open) {
            $log.log('Dropdown is now: ', open);
        };

        $scope.toggleDropdown = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.status.isopen = !$scope.status.isopen;
        };
    }
})();

