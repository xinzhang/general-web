﻿(function () {
    'use strict';
    angular.module('app').directive('showErrors', ['$timeout', function ($timeout) {
        return {
            restrict: 'A',
            require: '^form',
            link: function (scope, el, attrs, formCtrl) {

                // Find the text box element, which has the 'name' attribute
                var inputEl = el[0].querySelector("[name]");
                // Convert the native text box element to an angular element
                var inputNgEl = angular.element(inputEl);
                // Get the name on the text box so we know the property to check on the form controller
                var inputName = inputNgEl.attr('name');
                // Only apply the has-error class after the user leaves the text box
                inputNgEl.bind('blur', function () {
                    el.toggleClass('has-error', formCtrl[inputName].$invalid);
                    //el.toggleClass('has-error', formCtrl[inputName].$error.unique);
                });

                // Intercept event from parent for validation check
                scope.$on('show-errors-check-validity', function () {
                    el.toggleClass('has-error', formCtrl[inputName].$invalid);
                    //el.toggleClass('has-error', formCtrl[inputName].$error.unique);
                });
                // Intercept event from parent for removing error message
                scope.$on('show-errors-reset', function () {
                    // $timeout waits until the current digest cycle has finished before removing the class
                    $timeout(function () {
                        el.removeClass('has-error');
                    }, 0, false);
                });
            }

        }
    }])
})();