﻿(function () {
    'use strict';

    angular.module('app').directive("dropdown", function ($rootScope) {
        return {
            restrict: "E",
            templateUrl: "app/directives/dropdown.html",
            scope: {
                placeholder: "@",
                list: "=",
                selected: "=",
                property: "@"
            },
            link: function (scope) {
                scope.listVisible = false;
                scope.isPlaceholder = true;

                scope.select = function (item) {
                    scope.isPlaceholder = false;
                    scope.selected = item;
                    //scope.listVisible = false;
                };

                scope.isSelected = function (item) {
                    return item[scope.property] === scope.selected[scope.property];
                };

                scope.show = function () {
                    console.log('show clicked');
                    scope.listVisible = true;
                };

                $rootScope.$on("documentClicked", function (inner, target) {
                    console.log($(target[0]).is(".dropdown-display.clicked") || $(target[0]).parents(".dropdown-display.clicked").length > 0);
                    if (!$(target[0]).is(".dropdown-display.clicked") && !$(target[0]).parents(".dropdown-display.clicked").length > 0)
                        scope.$apply(function () {
                            //scope.listVisible = false;
                        });
                });

                //scope.$watch("selected", function (value) {
                //    scope.isPlaceholder = scope.selected[scope.property] === undefined;
                //    scope.display = scope.selected[scope.property];
                //    //scope.listVisible = false;
                //});
            }
        }
    });

})();