﻿(function () {
    'use strict';
    angular.module('app').directive('checkClientCode', ['userClientAdminService', function (userClientAdminService) {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, ele, attrs, ngModel) {
                ngModel.$validators.unique = function (modelValue) { 
                    if (!ngModel || !modelValue) return;
                    // Return true if exists, otherwise returns false
                    userClientAdminService.checkClientCode(modelValue)                    
                        .then(function (unique) {
                            if (modelValue === ele.val()) {
                                ngModel.$setValidity('unique', unique);
                            }
                        }, function () {
                            ngModel.$setValidity('unique', false);
                        });
                    

                    };
            }
        }
    }])
})();