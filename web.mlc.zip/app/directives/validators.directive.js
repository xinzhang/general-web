﻿(function () {
    'use strict';

    angular.module('app').directive("compareTo", function () {
        return {
            restrict: "A",

            require: "ngModel",

            scope: {
                otherModelValue: "=compareTo"
            },

            link: function (scope, element, attributes, ngModel) {
                ngModel.$validators.compareTo = function (modelValue) {
                    return modelValue == scope.otherModelValue;
                }
            }
        };
    });

    angular.module('app').directive("rangeFrom", function () {
        return {
            restrict: "A",
            require: 'ngModel',
            scope: {
                compareBaseValue: "=rangeFrom"
            },
            link: function (scope, element, attr, ngModel) {
                ngModel.$validators.rangeFrom = function (modelValue) {
                    return Math.abs(modelValue - scope.compareBaseValue) <= 10;
                }
            }
        }
    });

    angular.module('app').directive("dateMin", function () {
        return {
            restrict: "A",
            require: 'ngModel',
            link: function (scope, element, attr, ngModel) {
                ngModel.$validators.dateMin = function (modelValue) {
                    var today = new Date();
                    var fromEffectiveDate = today.setDate(today.getDate() + 1);
                    //make sure the date is the same or after the effective date
                    var ret = (
                            moment(modelValue, "YYYY-MM-DD").isAfter(moment(fromEffectiveDate), 'day') ||
                            moment(modelValue, "YYYY-MM-DD").isSame(moment(fromEffectiveDate), 'day')
                        );
                    return ret;
                }
            }
        }
    });

})();

