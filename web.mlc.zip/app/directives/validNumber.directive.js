﻿(function () {
    'use strict';
    //validNumber uses regular expression to check a number
    angular.module('app').directive('validNumber', function () {
        return {
            require: "ngModel",
            link: function (scope, elm, attrs, ctrl) {
                var regex = /\d/;
                ctrl.$parsers.unshift(function (viewValue) {
                    
                    if (regex.test(viewValue)) {
                        ctrl.$setValidity('validNumber', true);
                    }
                    else {
                        ctrl.$setValidity('validNumber', false);
                    }
                    return viewValue;
                });
            }
        };
    });
})();