﻿(function () {
    'use strict';

    angular.module('app').directive('toggleClass', function () {

    var directiveDefinitionObject = {
        restrict: 'A',
        template: '<span ng-click="localFunction()" ng-class="selected"  ng-transclude></span>',
        replace: true,
        scope: {
            model: '=',
            sortName: '@'
        },
        transclude: true,
        link: function (scope, element, attrs) {
            scope.localFunction = function () {
                scope.model.id = scope.$id;
                if (scope.sortName != undefined) {
                    scope.model.value = scope.sortName;
                }
            };
            scope.$watch('model.id', function () {
                if (scope.model.id === scope.$id) {
                    scope.selected = "toggled";
                } else {
                    scope.selected = '';
                }
            });
        }
    };
    return directiveDefinitionObject;
});
})();