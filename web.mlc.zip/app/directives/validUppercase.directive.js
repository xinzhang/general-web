﻿(function () {
    'use strict';
    //validUppercase uses regular expression to check an uppercase char
    angular.module('app').directive('validUppercase', function () {
        return {
            require: "ngModel",
            link: function (scope, elm, attrs, ctrl) {
                var regex = /[A-Z]/;
                ctrl.$parsers.unshift(function (viewValue) {
                    if (regex.test(viewValue)) {
                        ctrl.$setValidity('validUppercase', true);
                    }
                    else {
                        ctrl.$setValidity('validUppercase', false);
                    }
                    return viewValue;
                });
            }
        };
    });
})();