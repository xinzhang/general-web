﻿(function () {
    'use strict';
    angular.module('app').directive('checkUserName', ['userClientAdminService', function (userClientAdminService) {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, ele, attrs, ngModel) {
                ngModel.$validators.unique = function (modelValue) {
                    if (!ngModel || !modelValue) return;
                    // Return true if unique, otherwise returns false
                    userClientAdminService.checkUserName(modelValue)                    
                        .then(function (unique) {
                            if (modelValue === ele.val()) {
                                ngModel.$setValidity('unique', unique);
                            }
                        }, function () {
                            ngModel.$setValidity('unique', false);
                        });
                    

                    };
            }
        }
    }])
})();