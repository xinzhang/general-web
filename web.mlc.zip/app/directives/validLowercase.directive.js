﻿(function () {
    'use strict';
    //validLowercase uses regular expression to check an lowercase char
    angular.module('app').directive('validLowercase', function () {
        return {
            require: "ngModel",
            link: function (scope, elm, attrs, ctrl) {
                var regex = /[a-z]/;
                ctrl.$parsers.unshift(function (viewValue) {
                    if (regex.test(viewValue)) {
                        ctrl.$setValidity('validLowercase', true);
                    }
                    else {
                        ctrl.$setValidity('validLowercase', false);
                    }
                    return viewValue;
                });
            }
        };
    });
})();