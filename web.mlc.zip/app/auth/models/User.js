

'use strict';

angular.module('app.auth').factory('User', function ($http, $q, APP_CONFIG, authService) {
    
    var UserModel = {
        username: authService.authentication.userName,
        picture: 'styles/img/avatars/male.png'
    };
    
    /*
    $http.get(APP_CONFIG.apiRootUrl + '/user.json').then(function(response){
         UserModel.username = response.data.username;
         UserModel.picture= response.data.picture;
         dfd.resolve(UserModel)
     });
     */


    return UserModel;
});
