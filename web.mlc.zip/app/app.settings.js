angular.module('app.settings', [])
.constant('ngSettings', {"authServiceBaseUri":"http://localhost:48726/","appServiceBaseUri":"http://localhost:27969/","proxyAddress":"api/Relay/","proxyEnabled":"1","baseAddress":"http://localhost:44912/index.html#","clientId":"AusmaqClientPortal","disableSubmitHour":"21"});
