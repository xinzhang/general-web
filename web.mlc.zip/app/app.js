'use strict';

/**
 * @ngdoc overview
 * @name app [smartadminApp]
 * @description
 * # app [smartadminApp]
 *
 * Main module of the application.
 */

angular.module('app', [
    'ngSanitize',
    'ngAnimate',
    'LocalStorageModule',

    'ngResource',
    'restangular',
    'ui.router',
    'ui.bootstrap',

    // Smartadmin Angular Common Module
    'SmartAdmin',

    'angular.filter',
    'AxelSoft',
    'ngTagEditor',
    // use for angular-input-masks-standalone.min.js
    'ui.utils.masks',
    'angularFileUpload',
    'angular-loading-bar',

    // App
    'app.auth',
    'app.layout',
    'app.dashboard',
    'app.corporate',
    'app.request',
    'app.calendar',
    'app.distribution',
    'app.buysells',
    'app.transfer',
    'app.secrec',
    'app.rebate',
    'app.termdeposit',
    'app.tdRequest',
    'app.admin',
    'app.settings',
    'app.reports'

])

.config(function ($provide, $httpProvider, RestangularProvider) {

    $httpProvider.interceptors.push('authInterceptorService');

    // Add the interceptor to the $httpProvider.
    $httpProvider.interceptors.push('errorInterceptorService');

    RestangularProvider.setBaseUrl(location.pathname.replace(/[^\/]+?$/, ''));

})
.constant('APP_CONFIG', window.appConfig)
.constant('serviceNames', {
    Distribution: 'Distribution',
    Rebate: 'Rebate',
    Transfer: 'Transfer',
    SecurityRecs: 'SecurityRecs'
})

.run(function ($rootScope
    , $state, $stateParams
    ) {
    $rootScope.$state = $state;
    $rootScope.$stateParams = $stateParams;
    // editableOptions.theme = 'bs3';

});



