﻿'use strict';

//angular.module('app.home', [
//    'ui.router',
//    'ngAnimate',
//    'ui.bootstrap',
//    'ngResource',
//    'app.settings'
//])

angular.module('app')
.config(function ($stateProvider) {
    

    $stateProvider.state('apphome', {
        url: '/home/home',
        templateUrl: 'app/home/home.html',
        controller: 'HomeCtrl',
        controllerAs: 'vm'
    });
});