﻿(function () {
    'use strict';
    angular.module('app').controller('HomeCtrl', HomeCtrl);
    HomeCtrl.$inject = ['$scope']

    function HomeCtrl($scope) {
        var vm = this;
        vm.title = "Portal Home";
        
        $scope.noWrapSlides = false;
        $scope.active = 0;
        var currIndex = 0;
        $scope.myInterval = 3000;

        $scope.slides = [
          {
              image: 'styles/img/slider/slider1.png',
              id: 1
          },
          {
              image: 'styles/img/slider/slider2.png',
              id: 2
          },
          {
              image: 'styles/img/slider/slider4.jpg',
              id: 3
          },
          {
              image: 'styles/img/slider/slider5.jpg',
              id: 0
          }
        ]

        activate();

        ////////////////

        function activate() {
        }

    }


})();

