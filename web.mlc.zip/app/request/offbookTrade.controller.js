﻿(function () {
    'use strict';

    angular.module('app').controller('OffbookTradeCtrl', OffbookTradeCtrl);

    OffbookTradeCtrl.$inject = ['$location', '$scope', '$stateParams', 'authService', 'commonService', 'notify', '$filter', 'buysellsService', 'mlcRequestService'];

    function OffbookTradeCtrl($location, $scope, $stateParams, authService, commonService, notify, $filter, buysellsService, mlcRequestService) {
        var vm = this;
        vm.clientCode = '';
        vm.title = "Off Book Trade";
        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }
        
        vm.authentication = authService.authentication;

        vm.hasAuthorised = false;
        vm.hasSubmitted = false;
        //Uses value of type int so fix select with ngOption from the view
        vm.transactionType = [
           { "value": 1, "text": "Buy $$" },
           { "value": 2, "text": "Sell $$" },
           { "value": 3, "text": "Sell Unit"}
        ]

        vm.portfolioValidation = "[0-9]{3}";
        vm.apirValidation = "[a-z|A-Z]{3}[0-9]{4}[a-z|A-Z]{2}|[a-z|A-Z]{4}[0-9]{4}[a-z|A-Z]"

        vm.investors = [];

        vm.offBookTrades = {
            clientCode: '',
            investorNo: '',     //accountNo: ''
            apirCode: '',       //aPIRCode
            portfolioType: '',
            orderRef: '',
            transactionType: '',
            orderAmount: '',
            unitAmount: '',
            notes: '',
            isAuth: false
        }
        
        vm.authoriseMode = false;
        vm.editMode = false;

        activate();

        ////////////////

        function activate() {
            if (vm.authentication.adiCode != '')
                vm.offBookTrades.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.offBookTrades.clientCode = vm.authentication.tdOrgCode

            // Get Status the latest submit virtual request that will return MLCRequestViewModel
            mlcRequestService.getLatestRequestStatus(vm.authentication.tdOrgCode, "Off Book Trades")
            .then(function (response) {
                vm.editMode = false;
                console.log(response);
                if (response != undefined) { 
                    if (response.status == 'AwaitingAuthorisation') {
                        vm.editMode = false;
                        vm.authoriseMode = true;

                    } else {
                        vm.editMode = true;
                        vm.authoriseMode = false;
                    }

                }else{ //Fix bug when no off book trades request in DB
                    vm.editMode = true;
                    vm.authoriseMode = false;
                }
            }, function (err) {
                vm.message = commonService.showError(err);
                notify.showError(vm.message);
            });

            
            //Load investor from Chicago DB
            buysellsService.getInvestorList()
                        .then(function (response) {
                            var i = 0;
                            if (response != null) {
                                for (var i = 0; i < response.length; i++) {
                                    var investor = {};
                                    investor.value = response[i].investor;
                                    investor.text = response[i].investorName;
                                    vm.investors.push(investor);
                                }
                            }
                        }, function (err) {
                            vm.message = commonService.showError(err);
                            notify.showError(vm.message);
                        });

            mlcRequestService.getLatestOffbookTrades(vm.offBookTrades.clientCode)
                .then(function (response) {

                    if (response != null) {
                        if(response.isAuth) //record has already authorised
                        {
                            //Do nothing: Load the blank form
                        }
                        else //record has been submitted
                        {
                            //Bind to the view
                            vm.offBookTrades = response;
                        }
                    }
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(err);
                });
        }       

        vm.submitOffBookTrades = function () {
            //Tam: Fix the bug
            if (vm.offBookTrades.transactionType > 2) {
                vm.offBookTrades.orderAmount = null;
            } else {
                vm.offBookTrades.unitAmount = null;
            }

            console.log("vm.offBookTrades");
            console.log(vm.offBookTrades);
            mlcRequestService.submitMlcOffBookTradesRequest(vm.offBookTrades)
                    .then(function (response) {
                        var reference = response;
                        //Create an event to hide the pop up confimation dialog #myModal
                        //that fix the handling page when it finished the process.
                        $('#myModalSubmit').on('hidden.bs.modal', function () {
                            // Redirect to request reference page
                            $location.path('/request/requestReference/' + reference);
                        });
                        notify.showSuccess("Off Book Trades Request is submitted successfully.");
                        
                        //Call hide event
                        $('#myModalSubmit').modal('hide');

                        // Redirect to request reference page
                        //$location.path('/request/requestReference/' + reference);
                    }, function (err) {
                        vm.message = commonService.showError(err);
                        notify.showError(err);
                    });
        }

        vm.authorise = function () {
            mlcRequestService.authoriseMlcOffBookTradesRequest(vm.offBookTrades)
                    .then(function (response) {
                        var reference = response;
                        //Create an event to hide the pop up confimation dialog #myModal
                        //that fix the handling page when it finished the process.
                        $('#myModalAuthorise').on('hidden.bs.modal', function () {
                            // Redirect to request reference page
                            $location.path('/request/requestReference/' + reference);
                        });
                        
                        notify.showSuccess("Off Book Trades Request is authorised successfully.");
                        // Set auhtorise message
                        reference = reference + " has been authorised.";

                        console.log("mlcRequestService reference: " + reference);
                        //Call hide event
                        $('#myModalAuthorise').modal('hide');
                    }, function (err) {
                        vm.message = commonService.showError(err);
                        notify.showError(err);
                    });
        }

        //Reject MLC Off Book Trades
        vm.reject = function () {

            console.log("vm.reject");
            //vm.virtualCash.submitDate = new Date();
            //vm.virtualCash.userName = vm.authentication.userName;
            //vm.virtualCash.clientCode = vm.authentication.tdOrgCode;
            vm.offBookTrades.isAuth = false;

            mlcRequestService.rejectMlcOffBookTradesRequest(vm.offBookTrades)
            .then(function (response) {

                notify.showSuccess("Off Book Trades Request is rejected successfully.");

                var reference = response;

                //Create an event to hide the pop up confimation dialog #myModal
                //that fix the handling page when it finished the process.
                $('#myModalReject').on('hidden.bs.modal', function () {
                    // Redirect to request reference page
                    $location.path('/request/requestReference/' + reference);
                });

                // Set auhtorise message
                reference = reference + " has been rejected.";

                //Call hide event
                $('#myModalReject').modal('hide');

            }, function (err) {
                vm.message = commonService.showError(err);
                notify.showError(vm.message);
            });
        };
    }
})();