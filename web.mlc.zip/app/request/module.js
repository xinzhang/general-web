﻿'use strict';

angular.module('app.request', [
    'ui.router',
    'ngResource'
])

.config(function ($stateProvider) {
    $stateProvider
        
       .state('app.requestAssetManagement', {
           url: '/request/assetManagement',
           views: {
               "content@app": {
                   controller: 'AssetManagementCtrl',
                   templateUrl: 'app/request/assetManagement.html',
                   controllerAs: 'vm'
               }
           },
           data: {
               title: 'Asset Management'
           }
       })

     .state('app.requestOffbooktrade', {
         url: '/request/offbooktrade',
         views: {
             "content@app": {
                 controller: 'OffbookTradeCtrl',
                 templateUrl: 'app/request/offbookTrade.html',
                 controllerAs: 'vm'
             }
         },
         data: {
             title: 'Offbook Trade'
         }
     })

    .state('app.requestHardshipWithdrawal', {
        url: '/request/hardshipWithdrawal',
        views: {
            "content@app": {
                controller: 'HardshipWithdrawalCtrl',
                templateUrl: 'app/request/hardshipWithdrawal.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: 'Hardship Withdrawal'
        }
    })

    .state('app.requestVirtualCash', {
        url: '/request/virtualCash',
        views: {
            "content@app": {
                controller: 'VirtualCashCtrl',
                templateUrl: 'app/request/virtualCash.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: 'Virtual Cash'
        }
    })

    .state('app.requestReference', {
        url: '/request/requestReference/:reference',
        views: {
            "content@app": {
                controller: 'RequestReferenceCtrl',
                templateUrl: 'app/request/requestReference.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: 'Request Reference'
        }
    })

    .state('app.mlcRequest', {
        url: '/request/mlcRequest',
        views: {
            "content@app": {
                controller: 'MlcRequestCtrl',
                templateUrl: 'app/request/mlcRequest.html',
                controllerAs: 'vm'
            }
        },
        data: {
            title: 'Requests'
        }
    })
});
