﻿(function () {
    'use strict';

    angular.module('app').controller('VirtualCashCtrl', VirtualCashCtrl);

    VirtualCashCtrl.$inject = ['$window', '$location', '$scope', '$stateParams', '$filter', 'ngSettings', 'authService', 'commonService', 'buysellsService', 'mlcRequestService', 'notify'];
    function VirtualCashCtrl($window, $location, $scope, $stateParams, $filter, ngSettings, authService, commonService, buysellsService, mlcRequestService, notify) {
       
        var vm = this;     
        vm.allAuthChecked = false;
        vm.hasChanged = false;
        vm.title = 'Virtual Cash - Enter Details';
        vm.authentication = authService.authentication;
        
        var virtualCashClientPortal = {};
        vm.authoriseMode = false;
        vm.virtualCash = {
        requestReference: '',
        submitDate: new Date,
        userName: '',
        clientCode: '',
        isAuth: false,
        items:[]
        };

        vm.editMode = false;

        vm.selectedRows = [];
        //role Standard
        vm.selected = function (idx) {
            //if (!vm.editMode && vm.authentication.isStandard)
            //    return;
            vm.hasChanged = true;
            var r = vm.virtualCash.items[idx];
            r.isSelected = !r.isSelected;
            if (r.isSelected) {
                vm.selectedRows.push(idx);
            } else {
                vm.virtualCash.items[idx]['amount'] = 0;
                console.log("vm.selected");
                console.log(vm.virtualCash.items[idx]['amount']);
                var pos = vm.selectedRows.indexOf(idx);
                console.log("pos");
                console.log(pos);
                if (pos > -1) 
                    vm.selectedRows.splice(pos, 1);
            }
            //Toogle Save button
            if (vm.selectedRows.length > 0)
                vm.hasChanged = true;
            else
                vm.hasChanged = false;

        }

        //role Authorise
        vm.authorisedItem = function (idx) {
            var r = vm.virtualCash.items[idx];
            r.isSelected = !r.isSelected;
            if (r.isSelected) {
                vm.selectedRows.push(idx);
            } else {
                var pos = vm.selectedRows.indexOf(idx);
                if (pos > -1) 
                    vm.selectedRows.splice(pos, 1);
            }
            vm.allAuthChecked = getAllAuthChecked();
        }

        //This function returns true if all isSelected = true 
        //otherwise returns false
        var getAllAuthChecked = function () {
            if (vm.virtualCash == undefined)
                return false;
            if (vm.virtualCash.items.length != vm.selectedRows.length)
                return false;
            return true;
        }
        //This function merges the existing investor's amount from ClientPotalDB
        //to vm.virtualCash that load from ChicagoDB
        var mergeInvestorAmount = function () {
            for (var key in vm.virtualCash.items) {
                for (var key1 in virtualCashClientPortal.items) {
                    if (vm.virtualCash.items[key]['investor'] == virtualCashClientPortal.items[key1]['investor']) {

                        vm.virtualCash.items[key]['amount'] = virtualCashClientPortal.items[key1]['amount'];
                        //vm.selected(key); 
                        vm.virtualCash.items[key]['isSelected'] = true;
                        vm.selectedRows.push(key);
                        break;
                    } else {
                        //Tam:0
                        vm.virtualCash.items[key]['amount'] = 0;
                        vm.virtualCash.items[key]['isSelected'] = false;
                    }
                }
            }
        }
        
       
        activate();

        ////////////////

        function activate() {
           
            // Get Status the latest submit virtual request that will return MLCRequestViewModel
            mlcRequestService.getLatestRequestStatus(vm.authentication.tdOrgCode, "Virtual Cash")
            .then(function (response) {
                vm.editMode = false;
                
                console.log(response);
                if (response != null) { //if (response != undefined) {
                    if (response.status == 'AwaitingAuthorisation') {
                        vm.editMode = false;
                        vm.authoriseMode = true; //Tam
                    } else {

                        vm.editMode = true;
                        vm.authoriseMode = false;
                    }
                }
                else //TN: Fixed bug when empty database
                {
                    vm.editMode = true;
                    vm.authoriseMode = false;
                }
            }, function (err) {
                vm.message = commonService.showError(err);
                notify.showError(vm.message);
            });

            //Try get existing investors in SQL db
            mlcRequestService.getExistingMlcVirtualCashRequest()
            .then(function (response) {
                vm.hasChanged = false;
                if (response === null) { //Case: no investor awaits to authorise

                    //Standard role
                    if (vm.authentication.isStandard) {
                        //Load investors from chicago db
                        buysellsService.getInvestorList()
                        .then(function (response) {

                            if (response != null) {

                                if (vm.authentication.isStandard) {
                                    vm.virtualCash.items = response;
                                    vm.virtualCash.isAuth = false;
                                } else {
                                    //No data from Chicago db.
                                }
                            }

                        }, function (err) {
                            vm.message = commonService.showError(err);
                            notify.showError(vm.message);
                        });
                    } else { //Authorise role
                        //Nothing to authorise
                        vm.title = 'Virtual Cash - Authorisation';
                        vm.authoriseMode = false;//Hide form and display message no records to authorise
                    }

                } else { //Case: investor awaits to authorise

                    virtualCashClientPortal = response;

                    //Satandard role
                    if (vm.authentication.isStandard) {

                        //Load investors from chicago db
                        buysellsService.getInvestorList()
                        .then(function (response) {

                            if (response != null) {

                                if (vm.authentication.isStandard) {

                                    vm.virtualCash.items = response;
                                    vm.virtualCash.isAuth = false;
                                    //Merge existing investors from SQL to vm.virtualCash
                                    mergeInvestorAmount();
                                } else {
                                    //No data from Chicago db.
                                }
                            }

                        }, function (err) {
                            vm.message = commonService.showError(err);
                            notify.showError(vm.message);
                        });

                    } else { // Authorise role
                        vm.title = 'Virtual Cash - Authorisation';
                        vm.allAuthChecked = false;
                        vm.virtualCash = virtualCashClientPortal;
                        console.log(vm.virtualCash);
                        // Authorise mode
                        //vm.authoriseMode = true; //Tam removed
                    }
                }
            }, function (err) {
                vm.message = commonService.showError(err);
                notify.showError(vm.message);
            });

            console.log("end activate-> vm.authoriseMode: " + vm.authoriseMode);
            console.log("end activate-> vm.editMode: " + vm.authoriseMode);
        };

       vm.reset = function () {
            for (var key in vm.virtualCash.items) {
                //Tam:0
                vm.virtualCash.items[key]['amount'] = 0; // fixed issue:ng-show="virtualCashForm.amount{{$index}}.$error.required
                vm.virtualCash.items[key]['isSelected'] = false;
                vm.selectedRows.length = 0;
                vm.hasChanged = false;
            }
            //Call hide event
            $('#myModalReset').modal('hide');
        }

        //Save MLC Virtual Cash
        vm.submit = function () {

            $scope.$broadcast('show-errors-check-validity');
            if ($scope.virtualCashForm.$invalid ||
                $scope.virtualCashForm.$invalid == undefined
                ) { return }

            vm.virtualCash.requestReference = '';
            vm.virtualCash.submitDate = new Date();
            vm.virtualCash.userName = vm.authentication.userName;
            vm.virtualCash.clientCode = vm.authentication.tdOrgCode;
            vm.virtualCash.isAuth = false;

            mlcRequestService.submitMlcVirtualCashRequest(vm.virtualCash)
            .then(function (response) {
                
                notify.showSuccess("Virtual Cash Request is submitted successfully.");
                var reference = response;

                //Create an event to hide the pop up confimation dialog #myModalSubmit
                //that fix the handling page when it finished the process.
                $('#myModalSubmit').on('hidden.bs.modal', function () {
                    // Redirect to request reference page
                    $location.path('/request/requestReference/' + reference);
                });
                
                //Call hide event
                $('#myModalSubmit').modal('hide');
               
            }, function (err) {
                vm.message = commonService.showError(err);
                notify.showError(vm.message);
            });
        };

        //Authorise MLC Virtual cash
        vm.authorise = function () {

            //vm.virtualCash.requestReference = '';
            vm.virtualCash.submitDate = new Date();
            vm.virtualCash.userName = vm.authentication.userName;
            vm.virtualCash.clientCode = vm.authentication.tdOrgCode;
            vm.virtualCash.isAuth = true;
            
            mlcRequestService.authoriseMlcVirtualCashRequest(vm.virtualCash)
            .then(function (response) {

                notify.showSuccess("Virtual Cash Request is authorised successfully.");

                var reference = response;

                //Create an event to hide the pop up confimation dialog #myModalAuthorise
                //that fix the handling page when it finished the process.
                $('#myModalAuthorise').on('hidden.bs.modal', function () {
                    // Redirect to request reference page
                    $location.path('/request/requestReference/' + reference);
                });

                // Set auhtorise message
                reference = reference + " has been authorised.";

                //Call hide event
                $('#myModalAuthorise').modal('hide');

            }, function (err) {
                vm.message = commonService.showError(err);
                notify.showError(vm.message);
            });
        };

        //Reject MLC Virtual cash
        vm.reject = function () {

            console.log("vm.reject");
            vm.virtualCash.submitDate = new Date();
            vm.virtualCash.userName = vm.authentication.userName;
            vm.virtualCash.clientCode = vm.authentication.tdOrgCode;
            vm.virtualCash.isAuth = false;

            mlcRequestService.rejectMlcVirtualCashRequest(vm.virtualCash)
            .then(function (response) {

                notify.showSuccess("Virtual Cash Request is rejected successfully.");

                var reference = response;

                //Create an event to hide the pop up confimation dialog #myModalAuthorise
                //that fix the handling page when it finished the process.
                $('#myModalReject').on('hidden.bs.modal', function () {
                    // Redirect to request reference page
                    $location.path('/request/requestReference/' + reference);
                });

                // Set auhtorise message
                reference = reference + " has been rejected.";

                //Call hide event
                $('#myModalReject').modal('hide');

            }, function (err) {
                vm.message = commonService.showError(err);
                notify.showError(vm.message);
            });
        };
    }
})();