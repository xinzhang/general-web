﻿(function () {
    'use strict';

    angular.module('app').controller('RequestReferenceCtrl', RequestReferenceCtrl);

    RequestReferenceCtrl.$inject = ['$location', '$scope', '$stateParams'];

    function RequestReferenceCtrl($location, $scope, $stateParams) {

        var vm = this;

        vm.title = "Request Acknowledgement";

        if ($stateParams.reference) {
            vm.reference = $stateParams.reference;
            console.log("RequestReferenceCtrl $stateParams.reference: " + vm.reference);
        }

        activate();

        function activate() {
        }


    }

})();
