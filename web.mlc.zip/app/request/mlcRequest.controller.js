﻿(function () {
    'use strict';

    angular.module('app').controller('MlcRequestCtrl', MlcRequestCtrl);

    MlcRequestCtrl.$inject = ['$location', '$scope', '$stateParams', 'mlcRequestService', 'commonService', 'authService', '$q', 'notify', '$filter'];

    function MlcRequestCtrl($location, $scope, $stateParams, mlcRequestService, commonService, authService, $q, notify, $filter) {

        var vm = this;
        vm.title = "Requests";
        vm.clientCode = '';

        //Used by modalRequestDetailTDAusmaqRateTermStandard
        vm.asset = '';

        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }
        vm.histories = [];
        vm.pageRequestList = [];
        vm.filteredHistories = vm.histories;
        
        // Sort
        var orderBy = $filter('orderBy');
       

        vm.gotoPage = function (pageno) {
            if (pageno < 0 || pageno >= vm.paging.totalPage)
                return;

            vm.paging.isPrev = vm.paging.isNext = true;

            if (pageno == 0)
                vm.paging.isPrev = false;

            if (pageno == (vm.paging.totalPage - 1))
                vm.paging.isNext = false;

            vm.paging.currentPage = pageno;

            vm.pageRequestList = vm.filteredHistories.slice(pageno * 10, (pageno + 1) * 10);

        }

        activate();

        ////////////////

        function activate() {
            vm.authentication = authService.authentication;

            $("#modalRequestDetailAssetManagement").draggable({
                handle: ".modal-header"
            });

            $("#modalRequestDetailOffBookTrades").draggable({
                handle: ".modal-header"
            });

            $("#modalRequestDetailHardshipWithdrawal").draggable({
                handle: ".modal-header"
            });
            
            $("#modalRequestDetailVirtualCash").draggable({
                handle: ".modal-header"
            });
            
            vm.selectionRequestTypes = ['Asset Management', 'Off Book Trades', 'Hardship Withdrawal', 'Virtual Cash'];
            vm.clientCode = vm.authentication.tdOrgCode;
            mlcRequestService.getRequestList(vm.clientCode)
                .then(function (response) {
                    vm.histories = response;
                    vm.filteredHistories = vm.histories;
                    vm.paging.rowTotal = vm.filteredHistories.length;
                    vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
                    vm.gotoPage(0);
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });
        };

        vm.refresh = function () {
            activate();
        }

        vm.filterObject = {
            'requestType': '',
            'addedBy': '',
            'requestStatus': ''
        }

        vm.selectionRequestStatuses = ['Pending', 'Received', 'Accepted', 'Review', 'Error', 'Success', 'AwaitingAuthorisation'];

        vm.setFilterObject = function (purpose) {

            console.log('purpose: ' + purpose);

            switch (purpose) {
                case "AllRequests":
                    vm.filterObject.requestType = '';
                    vm.filterObject.addedBy = '';
                    vm.filterObject.requestStatus = '';
                    break;

                case "MyRequests":
                    vm.filterObject.addedBy = vm.authentication.userName;
                    break;

                case "PendingRequests":
                    vm.filterObject.requestStatus = 'Pending';
                    break;
            }
        };

        vm.filterRequestList = function (row) {
            var blRequestType = false;

            blRequestType = (
                    (vm.isObjEmpty(vm.filterObject.requestType) || vm.filterObject.requestType === row.requestType)
                    &&
                    (vm.isObjEmpty(vm.filterObject.addedBy) || vm.filterObject.addedBy === row.addedBy)
                    &&
                    (vm.isObjEmpty(vm.filterObject.requestStatus) || vm.filterObject.requestStatus === row.status)
                );

            if (!vm.isObjEmpty(vm.freeQuery)) {
                blRequestType = blRequestType
                    &&
                    (
                         angular.lowercase(row.requestReference.toString()).indexOf(angular.lowercase(vm.freeQuery) || '') !== -1
                    );
            }
            return blRequestType;
        };

        vm.isObjEmpty = function (obj) {
            if (obj === undefined || obj === null || obj === '') {
                return true;
            }
            else {
                return false;
            }
        };

        
        vm.showRequestDetail = function (clientCode, reference, requestType) {

            mlcRequestService.getRequestDetailByReference(clientCode, reference)
                .then(function (response) {

                    console.log("requestType: " + requestType);

                    switch (angular.lowercase(requestType)) {

                        case "asset management":
                            vm.modalTitle = "Asset Management";
                            vm.requestDetail = response;
                            vm.ref = vm.requestDetail.requestReference;
                            vm.apirCode = vm.requestDetail.apirCode;
                            vm.securityName = vm.requestDetail.securityName;
                            vm.assetType = vm.requestDetail.assetType;
                            vm.assetStatus = vm.requestDetail.assetStatus;
                            vm.notes = vm.requestDetail.notes;
                            $('#modalRequestDetailAssetManagement').modal('show');
                            break;

                        case "off book trades":
                            vm.modalTitle = "Off Book Trades";
                            vm.requestDetail = response;
                            vm.ref = vm.requestDetail.requestReference;
                            vm.investorNo = vm.requestDetail.investorNo;
                            vm.apirCode = vm.requestDetail.apirCode;
                            vm.portfolioType = vm.requestDetail.portfolioType;
                            vm.orderRef = vm.requestDetail.orderRef;
                            vm.transactionType = vm.requestDetail.transactionType;
                            vm.unitAmount = vm.requestDetail.unitAmount;
                            vm.orderAmount = vm.requestDetail.orderAmount;
                            vm.submitDate = vm.requestDetail.submitDate;
                            vm.user = vm.requestDetail.userName;
                            vm.notes = vm.requestDetail.notes;
                            $('#modalRequestDetailOffBookTrades').modal('show');
                            break;

                        case "hardship withdrawal":
                            vm.modalTitle = "Hardship Withdrawal";
                            vm.requestDetail = response;
                            vm.ref = vm.requestDetail.requestReference;
                            vm.investorNo = vm.requestDetail.investorNo;
                            vm.apirCode = vm.requestDetail.apirCode;
                            vm.orderRef = vm.requestDetail.orderRef;
                            vm.transactionType = vm.requestDetail.transactionType;
                            vm.unitAmount = vm.requestDetail.unitAmount;
                            vm.orderAmount = vm.requestDetail.orderAmount;
                            vm.submitDate = vm.requestDetail.submitDate;
                            vm.user = vm.requestDetail.userName;
                            vm.notes = vm.requestDetail.notes;
                            $('#modalRequestDetailHardshipWithdrawal').modal('show');
                            break;

                        case "virtual cash":
                            vm.modalTitle = "Virtual Cash";
                            vm.requestDetail = response;
                            console.log(vm.requestDetail);
                            vm.ref = vm.requestDetail.requestReference;
                            vm.status = vm.requestDetail.isAuth;
                            vm.submitDate = vm.requestDetail.submitDate;
                            vm.user = vm.requestDetail.userName;
                            vm.investors = vm.requestDetail.items;
                            $('#modalRequestDetailVirtualCash').modal('show');
                            break;
                        default:
                            break;
                    }

                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });
        };

        // Sort by column in the grid
        vm.sortColumn = 'dateTimeAdded';
        vm.sortOrder = true;
        vm.sortData = function (columnName) {
            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.filteredHistories = orderBy(vm.filteredHistories, vm.sortColumn, vm.sortOrder);
            vm.gotoPage(0);
        }

        vm.filterHistory = function (searchCriteria) {
            vm.filteredHistories = $filter('filter')(vm.histories, searchCriteria);
            vm.paging.rowTotal = vm.filteredHistories.length;
            vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
            vm.gotoPage(0);
        }
        
    }

})();
