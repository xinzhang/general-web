﻿(function () {
    'use strict';

    angular.module('app').controller('AssetManagementCtrl', AssetManagementCtrl);

    AssetManagementCtrl.$inject = ['$location', '$scope', '$stateParams', 'localStorageService', 'authService', 'commonService', 'mlcRequestService', 'notify', '$filter', 'FileUploader'];//'assetManagementService' to be removed from project

    function AssetManagementCtrl($location, $scope, $stateParams, localStorageService, authService, commonService, mlcRequestService, notify, $filter, FileUploader) { //assetManagementService
        var vm = this;
        vm.clientCode = '';
        vm.title = "Asset Management";

        vm.assetManagement = {
            clientCode: '',
            aPIRCode: '',
            securityName: '',
            assetType: '',
            assetStatus: '',
            notes: [], // initialise array
        }

        vm.authentication = authService.authentication;

        vm.assetType = [
           { "value": 1, "text": "Asset Onboard" },
           { "value": 2, "text": "Asset Offboard" }
        ]

        vm.requestStatus = [
           { "value": 1, "text": "Standard" },
           { "value": 2, "text": "Urgent" }
        ]
        
        vm.submitted = false;

        //Tam: Upload
        //Call direct api Relay controller to access ressourceServer without using $hhtp.post

        var authData = 'Bearer ' + localStorageService.get('authorisationData').token;
        vm.uploader = new FileUploader({            
            url: "api/relay",
            headers: {
                Authorization : authData,
                uploadCategory: "mlc_asset",
            }
        });

        vm.uploader.filters.push({
            name: 'documentFilter',
            fn: function (item /*{File|FileLikeObject}*/, options) {
                var type = '|' + item.name.slice(item.name.lastIndexOf('.') + 1).toLowerCase() + '|';
                return '|xml|csv|txt|doc|docx|pdf|xls|xlsx|jpg|png|jpeg|bmp|zip|rar|'.indexOf(type) !== -1;
            }
        });

        vm.fileUploaded = false;

        vm.link = "";
        vm.attachment = false;
        vm.localFileName = "";
        
        //Tam: Regex validation
        vm.apirValidation = "[a-z|A-Z]{3}[0-9]{4}[a-z|A-Z]{2}|[a-z|A-Z]{4}[0-9]{4}[a-z|A-Z]";

        activate();

        ////////////////

        function activate() {
            vm.authentication = authService.authentication;
            if (vm.authentication.adiCode != '')
                vm.assetManagement.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.assetManagement.clientCode = vm.authentication.tdOrgCode;
        }

        //modalAssetManagementViewAddComment
        vm.showCommentDetail = function (commentId) {
            console.log("commentId: " + commentId);
            var dateNow = moment(new Date());
            vm.isViewMode = false;
            //New comment
            if (commentId == 0)
            {
                vm.uploader.clearQueue();
                vm.modalTitle = "Add New Comment";
                vm.datetimeAdded = moment(dateNow).format("YYYY-MM-DD HH:mm:ss");
                vm.comment = "";
                vm.link = "";
                vm.user = vm.authentication.userName;
            }
            else //Existing comment
            {
                vm.modalTitle = "View Comment";
                vm.isViewMode = true;
               
                var elementPos = vm.assetManagement.notes.map(function (x) { return x.id; }).indexOf(commentId);
                var selectedObj = vm.assetManagement.notes[elementPos];
                
                //Assign value
                vm.datetimeAdded = moment(selectedObj.datetimeAdded).format("YYYY-MM-DD HH:mm:ss");
                vm.comment = selectedObj.comment;
                vm.link = selectedObj.link;
                vm.user = selectedObj.user;
                vm.localFileName = selectedObj.localFileName;
            }
            $('#modalAssetManagementViewAddComment').modal('show');
        };
        
        vm.addComment = function () {

            var objComment = {}; //Initialise object
            objComment.datetimeAdded = vm.datetimeAdded;
            objComment.user = vm.user;
            objComment.comment = vm.comment;
            objComment.attachment = vm.attachment;
            objComment.link = vm.link;
            objComment.localFileName = vm.localFileName;
            
            var lastIndex = 0;
            if (vm.assetManagement.notes.length > 0)
                lastIndex = vm.assetManagement.notes.length;
            lastIndex++;
            objComment.id = lastIndex;
            
            //Add Note
            vm.assetManagement.notes.push(objComment);

        };

        vm.submit = function () {

            vm.submitted = true;

            //Validate required data
            $scope.$broadcast('show-errors-check-validity');
            if ($scope.mlcRequestAssetManagementForm.$invalid ||
                $scope.mlcRequestAssetManagementForm.$invalid == undefined
                ) { return }


            mlcRequestService.submitMlcAssetManagementRequest(vm.assetManagement)
                    .then(function (response) {
                        var reference = response;
                        notify.showSuccess("Asset Management Request is submitted successfully.");
                        // Redirect to request
                        var reference = response;
                        $location.path('/request/requestReference/' + reference);

                    }, function (err) {
                        vm.message = commonService.showError(err);
                        notify.showError(err);
                    });
        };

        //File upload
        // CALLBACKS
        vm.uploader.onSuccessItem = function (fileItem, response, status, headers) {
            console.info('onSuccessItem', fileItem, response, status, headers);
        };
        vm.uploader.onErrorItem = function (fileItem, response, status, headers) {
            notify.showError("File upload errr." + status);
        };
        vm.uploader.onCancelItem = function (fileItem, response, status, headers) {
            console.info('onCancelItem', fileItem, response, status, headers);
        };
        vm.uploader.onCompleteItem = function (fileItem, response, status, headers) {
            
            notify.showSuccess("File upload success.");
            //Tam
            vm.link = response.fileNames[0];
            vm.attachment = true;
            vm.fileUploaded = true;
            //Get the local filename without generated id.
            vm.localFileName = vm.uploader.queue[0].file.name;
        };

        vm.uploader.onCompleteAll = function () {
            vm.fileUploaded = true;
        };

        vm.uploader.onBeforeUploadItem = function (item) {
            console.log(item);
            if (vm.uploader.queue.length > 1)
            {
                notify.showWarning('You can only upload one document per comment');
                //Remove item from UI
                item.remove();
                //Remove item from the queue.
                vm.uploader.queue.cancelItem(item);
            }

         }; 
    }
})();