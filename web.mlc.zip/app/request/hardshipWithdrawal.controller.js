﻿(function () {
    'use strict';

    angular.module('app').controller('HardshipWithdrawalCtrl', HardshipWithdrawalCtrl);

    HardshipWithdrawalCtrl.$inject = ['$location', '$scope', '$stateParams', 'localStorageService', 'authService', 'commonService', 'notify', '$filter', 'buysellsService', 'mlcRequestService', 'FileUploader'];

    function HardshipWithdrawalCtrl($location, $scope, $stateParams, localStorageService, authService, commonService, notify, $filter, buysellsService, mlcRequestService, FileUploader) {
        var vm = this;
        vm.clientCode = '';
        vm.title = "Hardship Withdrawal";
        if ($stateParams.username) {
            vm.username = $stateParams.username;
        }
        
        vm.authentication = authService.authentication;

        vm.isViewMode = false;
        
        vm.investors = [];        

        vm.hardship = {
            clientCode: '',
            investorNo: '',
            aPIRCode: '',
            orderRef: '',
            notes: [], // initialise array,
            isAuth: false
        }

        vm.submitted = false;

        //Tam: Upload
        //Call direct api Relay controller to access ressourceServer without using $hhtp.post       
        var authData = 'Bearer ' + localStorageService.get('authorisationData').token;
        vm.uploader = new FileUploader({
            //url: "/api/uploadRelay"
            url: "api/relay",
            headers: {
                Authorization: authData,
                uploadCategory: "mlc_hardship",
            }
        });
        vm.uploader.filters.push({
            name: 'documentFilter',
            fn: function (item /*{File|FileLikeObject}*/, options) {
                var type = '|' + item.name.slice(item.name.lastIndexOf('.') + 1).toLowerCase() + '|';
                return '|xml|csv|txt|doc|docx|pdf|xls|xlsx|jpg|png|jpeg|bmp|zip|rar|'.indexOf(type) !== -1;
            }
        });
        vm.fileUploaded = false;

        vm.link = "";
        vm.attachment = false;
        vm.localFileName = "";
        
        //Tam: Regex validation
        vm.apirValidation = "[a-z|A-Z]{3}[0-9]{4}[a-z|A-Z]{2}|[a-z|A-Z]{4}[0-9]{4}[a-z|A-Z]";
        vm.portfolioValidation = "[0-9]{3}";

        activate();

        ////////////////

        function activate() {
            if (vm.authentication.adiCode != '')
                vm.hardship.clientCode = vm.authentication.adiCode;
            else if (vm.authentication.tdOrgCode != '')
                vm.hardship.clientCode = vm.authentication.tdOrgCode
             
            vm.isViewMode = false;

            //Tam:Here
            buysellsService.getInvestorList()
                .then(function (response) {
                    var i = 0;
                    if (response != null) {
                        for (var i = 0; i < response.length; i++) {
                            var investor = {};
                            investor.value = response[i].investor;
                            investor.text = response[i].investorName;
                            vm.investors.push(investor);
                        }
                    }
                }, function (err) {
                    vm.message = commonService.showError(err);
                    notify.showError(vm.message);
                });

        }       

        //modalAssetManagementViewAddComment
        vm.showCommentDetail = function (commentId) {
            var dateNow = moment(new Date());
            vm.isViewMode = false;
            //New comment
            if (commentId == 0) {

                vm.uploader.clearQueue();
                vm.modalTitle = "Add New Comment";
                vm.datetimeAdded = moment(dateNow).format("YYYY-MM-DD HH:mm:ss");
                vm.comment = "";
                vm.link = "";
                vm.user = vm.authentication.userName;
            }
            else //Existing comment
            {
                vm.modalTitle = "View Comment";
                vm.isViewMode = true;
                var elementPos = vm.hardship.notes.map(function (x) { return x.id; }).indexOf(commentId);
                var selectedObj = vm.hardship.notes[elementPos];

                //Assign value
                vm.datetimeAdded = moment(selectedObj.datetimeAdded).format("YYYY-MM-DD HH:mm:ss");
                vm.comment = selectedObj.comment;
                vm.link = selectedObj.link;
                vm.user = selectedObj.user;
                vm.localFileName = selectedObj.localFileName;
            }
            $('#modalHardshipWithdrawalViewAddComment').modal('show');
        };

        
        vm.submitHardshipWithdrawal = function () {
            vm.submitted = true;

            $scope.$broadcast('show-errors-check-validity');
            if ($scope.mlcRequestHardshipWithdrawalForm.$invalid ||
                $scope.mlcRequestHardshipWithdrawalForm.$invalid == undefined
                ) { return }

            mlcRequestService.submitMlcHardshipWithdrawalRequest(vm.hardship)
                    .then(function (response) {
                        var reference = response;
                        notify.showSuccess("Hardship Withdrawal Request is submitted successfully.");
                        // Redirect to request
                        var reference = response;
                        $location.path('/request/requestReference/' + reference);

                    }, function (err) {
                        vm.message = commonService.showError(err);
                        notify.showError(err);
                    });
        }

        vm.addComment = function () {

            var objComment = {}; //Initialise object
            objComment.datetimeAdded = vm.datetimeAdded;
            objComment.user = vm.user;
            objComment.comment = vm.comment;
            objComment.attachment = vm.attachment;
            objComment.link = vm.link;
            objComment.localFileName = vm.localFileName;

            var lastIndex = 0;
            if (vm.hardship.notes.length > 0)
                lastIndex = vm.hardship.notes.length;
            lastIndex++;
            objComment.id = lastIndex;

            //Add Note
            vm.hardship.notes.push(objComment);

        };

        //File upload
        // CALLBACKS
        vm.uploader.onSuccessItem = function (fileItem, response, status, headers) {
            console.info('onSuccessItem', fileItem, response, status, headers);
        };
        vm.uploader.onErrorItem = function (fileItem, response, status, headers) {
            notify.showError("File upload errr." + status);
        };
        vm.uploader.onCancelItem = function (fileItem, response, status, headers) {
            console.info('onCancelItem', fileItem, response, status, headers);
        };
        vm.uploader.onCompleteItem = function (fileItem, response, status, headers) {

            notify.showSuccess("File upload success.");
            //Tam
            vm.link = response.fileNames[0];
            vm.attachment = true;
            vm.fileUploaded = true;
            //Get the local filename without generated id.
            vm.localFileName = vm.uploader.queue[0].file.name;
        };

        vm.uploader.onCompleteAll = function () {
            vm.fileUploaded = true;
        };

        vm.uploader.onBeforeUploadItem = function (item) {
            console.log(item);
            if (vm.uploader.queue.length > 1) {
                notify.showWarning('You can only upload one document per comment');
                //Remove item from UI
                item.remove();
                //Remove item from the queue.
                vm.uploader.queue.cancelItem(item);
            }
        };
    }
})();