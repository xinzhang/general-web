﻿(function () {
    'use strict';

    angular.module('app').controller('ReportListCtrl', ReportListCtrl);

    ReportListCtrl.$inject = ['$location', '$scope', '$stateParams', '$filter','reportService','commonService', 'notify', '$q', '$window'];

    function ReportListCtrl($location, $scope, $stateParams, $filter, reportService, commonService, notify, $q, $window) {
        var vm = this;
        vm.clientCode = '';
        vm.title = "Reports";

        // Sort
        var orderBy = $filter('orderBy');

        vm.reports = [];
        
        activate();

        ////////////////

        function activate() {

            reportService.getReports()
               .then(function (response) {
                   vm.reports = response;
               }, function (err) {
                   vm.message = commonService.showError(err);
                   notify.showError(vm.message);
               });

        }

        // Sort by column in the grid
        vm.sortColumn = 'dateCreated';
        vm.sortOrder = true;
        vm.sortData = function (columnName) {
            vm.sortColumn = columnName;
            vm.sortOrder = !vm.sortOrder;
            vm.reports= orderBy(vm.reports, vm.sortColumn, vm.sortOrder);            
        }

        vm.download = function (fileName) {

            reportService.getReportByName(fileName)
                 .then(function (response) {
                     var data = new Blob([response]);
                     ($window).saveAs(data, fileName);

                 }, function (err) {
                     vm.message = commonService.showError(err);
                     notify.showError(vm.message);
                 });
        }

    }
})();