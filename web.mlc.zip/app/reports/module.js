﻿'use strict';

angular.module('app.reports', [
    'ui.router',
    'ngResource'
])

.config(function ($stateProvider) {
    $stateProvider
        
       .state('app.reportlist', {
           url: '/reports/reportlist',
           views: {
               "content@app": {
                   controller: 'ReportListCtrl',
                   templateUrl: 'app/reports/reportlist.panel.html',
                   controllerAs: 'vm'
               }
           },
           data: {
               title: 'Reports'
           }
       })
     
});
