﻿(function () {
    'use strict';

    angular.module('app').controller('AdiLatestRatesCtrl', AdiLatestRatesCtrl);

    AdiLatestRatesCtrl.$inject = ['$location', '$scope', '$stateParams', 'termdepositService', 'commonService', 'authService', 'notify', '$filter', 'chartUtility', 'ngSettings', 'businessDaysService'];

    function AdiLatestRatesCtrl($location, $scope, $stateParams, termdepositService, commonService, authService, notify, $filter, chartUtil, ngSettings, businessDaysService) {

        var vm = this;
        vm.title = "Edit Latest Rates";
        vm.toleranceBasis = 500;

        if ($stateParams.adiCode) {
            vm.adiCode = $stateParams.adiCode;
        }

        vm.paging = {
            rownumber: 10,
            currentPage: 0,
            totalPage: 0,
            isNext: true,
            isPrev: false,
            rowTotal: 0,
        }

        vm.histories = [];
        vm.pagedHistories = [];
        vm.filteredHistories = vm.histories;
        vm.diffrentAssetRates = [];

        vm.currentSort = {
            id: '',
            value:'dateTimeAdded'
        }

        var orderBy = $filter('orderBy');

        vm.gotoPage = function (pageno) {
            if (pageno < 0 || pageno >= vm.paging.totalPage)
                return;

            vm.paging.isPrev = vm.paging.isNext = true;

            if (pageno == 0)
                vm.paging.isPrev = false;

            if (pageno == (vm.paging.totalPage - 1))
                vm.paging.isNext = false;

            vm.paging.currentPage = pageno;

            vm.pagedHistories = vm.filteredHistories.slice(pageno * 10, (pageno + 1) * 10);
        }

        vm.disableInput = false;
        vm.submitted = false;
        vm.allAuthChecked = false;
        vm.todaysRateSaved = false;

        vm.today = new Date();
        
        vm.fromEffectiveDate = businessDaysService.businessAdd(moment(new Date()), 1)._d;

        activate();

        ////////////////

        function activate() {
            vm.authentication = authService.authentication;
            if (vm.authentication.isAuthorise)
                vm.title = "Authorise entered rates"
            
            $("#myModalHistoryList").draggable({
                handle: ".modal-header"
            });

            $("#myModalHistoryGraph").draggable({
                handle: ".modal-header"
            });

            $("#myModalSubmitConfirm").draggable({
                handle: ".modal-header"
            });

            var currentDate = new Date();
            vm.disableInput = (currentDate.getHours() >= ngSettings.disableSubmitHour);

            $scope.$on('LastRepeaterElement', function () {
                $('.popover-dismiss').popover({
                    trigger: 'focus',
                    html: 'true'
                });
            });            

            termdepositService.checkPreviousPendingRates(vm.adiCode)
                .then(function (response) {
                    //bool result returned.
                    vm.pendingRatesExist = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                });

            termdepositService.getPreviousAssetRates(vm.adiCode)
                .then(function (response) {
                    vm.assetRates = response;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                })
                .then(function () {
                    termdepositService.getTodaysAssetRates(vm.adiCode)
                    .then(function (response) {
                        vm.todaysAssetRates = response;
                        if (vm.todaysAssetRates != undefined)
                        {
                            if (vm.todaysAssetRates.length > 0 )
                            {
                                //to do
                                vm.submitted = true;                                
                            }
                                                
                            for (var i = 0; i < vm.todaysAssetRates.length; i++) {
                                if (vm.todaysAssetRates[i].fromEffectiveDate == undefined) {
                                    vm.todaysAssetRates[i].fromEffectiveDate = moment(vm.fromEffectiveDate).format('YYYY-MM-DD');
                                }
                                if (vm.todaysAssetRates[i].toEffectiveDate != undefined) {
                                    vm.todaysAssetRates[i].toEffectiveDate = moment(vm.todaysAssetRates[i].toEffectiveDate).format('YYYY-MM-DD');
                                }

                                if (vm.todaysAssetRates[i].submitted) {
                                    vm.todaysAssetRates[i].isAuthorised = true;
                                } else {
                                    vm.todaysAssetRates[i].isAuthorised = false;
                                    //any of submitted false causes the whole form submitted as false.
                                    vm.submitted = false;
                                }

                                if (vm.todaysAssetRates[i].intRate != null) {
                                    vm.todaysRateSaved = true;

                                    //check tolerance check
                                    // ui flag only
                                    vm.todaysAssetRates[i].tolerance = true;
                                    var previousValue = vm.assetRates[i].intRate;
                                    if (previousValue != null) {
                                        var currentValue = vm.todaysAssetRates[i].intRate;
                                        vm.todaysAssetRates[i].tolerance = (Math.abs(currentValue - previousValue) <= (vm.toleranceBasis / 1000));
                                    }
                                }

                                $('#popoverData'+i).popover();
                            }
                        }
                    }, function (err) {
                        vm.errorMessage = commonService.showError(err);
                        notify.showError(vm.errorMessage);
                    })
                })                

        };

        vm.authoriseTolerance = function (idx) {
            vm.todaysAssetRates[idx].tolerance = true;
        }

        vm.refresh = function () {
            activate();
        }

        vm.saveRates = function (isValid) {
            if (!isValid)
                return;

            termdepositService
                .saveAssetRates(vm.todaysAssetRates)
                .then(function (response) {
                    notify.showSuccess("Rates are saved successfully.");
                }, function (err) {
                    vm.erorMessage = commonService.showError(err);
                    notify.showError(vm.errorMessage);
                });
        };

        vm.deleteAssetRatesForToday = function () {
            termdepositService
                .deleteAssetRatesForToday(vm.adiCode)
                .then(function (response) {
                    notify.showSuccess("Rates are deleted successfully.");
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                    notify.showError(vm.errorMessage);
                })
                .then(function () {
                    termdepositService.getTodaysAssetRates(vm.adiCode)
                    .then(function (response) {
                        vm.todaysAssetRates = response;
                    }, function (err) {
                        vm.errorMessage = commonService.showError(err);
                    })
                });
        };

        vm.clearPendingRates = function () {
            termdepositService
                .deletePreviousPendingAssetRates(vm.adiCode)
                .then(function (response) {
                    notify.showSuccess("Pending rates are cleared successfully.");
                    vm.pendingRatesExist = false;
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                    notify.showError(vm.errorMessage);
                })
        }
        
        vm.copyRateRightToLeft = function (assetRate, todaysAssetRate) {
            if (todaysAssetRate.submitted)
                return;

            todaysAssetRate.intRate = angular.copy(assetRate.intRate);
        };

        vm.copyAllRatesRightToLeft = function (assetRates, todaysAssetRates) {
            for (var i = 0; i < assetRates.length; i++) {
                if (i < todaysAssetRates.length) {
                    if (!vm.todaysAssetRates[i].submitted)                        
                        todaysAssetRates[i].intRate = angular.copy(assetRates[i].intRate);
                }
            }
        };

        vm.copyAllEffectiveDatesFromTopToDown = function () {            
            for (var i = 0; i < vm.todaysAssetRates.length; i++) {
                if (!vm.todaysAssetRates[i].submitted)
                    vm.todaysAssetRates[i].toEffectiveDate = angular.copy(vm.toEffectiveDate);                
            }
            
        }

        vm.showHistory = function (assetNo) {
            vm.modalTitle = "Show History";
            vm.currentAssetNo = assetNo;
            termdepositService.getAssetRateHistory(assetNo)
                .then(function (response) {
                    vm.histories = response;
                    vm.filteredHistories = vm.histories;
                    vm.paging.rowTotal = vm.filteredHistories.length;
                    vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
                    vm.gotoPage(0);

                    $('#myModalHistoryList').modal('show');
                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                    notify.showError(vm.message);
                });
            
        }

        vm.filterHistory = function () {
            vm.filteredHistories = $filter('filter')(vm.histories, vm.search);;
            vm.paging.rowTotal = vm.filteredHistories.length;
            vm.paging.totalPage = Math.floor(vm.filteredHistories.length / 10) + 1;
            vm.gotoPage(0);
        }

        vm.showHistoryGraph = function (assetNo) {
            vm.modalTitle = "Show History Graph";
            vm.currentAssetNo = assetNo;
            termdepositService.getAssetRateHistory(assetNo)
                .then(function (response) {
                    vm.histories = response;

                    $('#myModalHistoryGraph').modal('show');
                    chartUtil.drawRateCharts( orderBy(vm.histories, 'dateTimeAdded', false) );

                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                    notify.showError(message);
                });

        }

        vm.showSubmitConfirm = function () {

            for (var i = 0; i < vm.todaysAssetRates.length - 1; i++)
            {
                vm.todaysAssetRates[i].isDifferentRate = (vm.todaysAssetRates[i].intRate != vm.assetRates[i].intRate)
                if (vm.todaysAssetRates[i].isDifferentRate) {
                    vm.diffrentAssetRates.push(vm.todaysAssetRates[i]);
                }
            }

            vm.showDifference(false);
            $('#myModalSubmitConfirm').modal('show');
        }

        vm.showDifference = function(isDiff)
        {
            if (isDiff) {
                vm.filteredTodaysAssetRates = vm.diffrentAssetRates;
            }
            else {
                vm.filteredTodaysAssetRates = vm.todaysAssetRates;
            }
        }

        vm.sort = function (reverse) {
            vm.filteredHistories = orderBy(vm.filteredHistories, vm.currentSort.value, reverse);
            vm.gotoPage(0);
        }

        vm.getAllAuthChecked = function () {
            
            if (vm.todaysAssetRates == undefined)
                return false;

            for (var i = 0; i < vm.todaysAssetRates.length; i++) {
                if (!vm.todaysAssetRates[i].isAuthorised)
                    return false;
            }

            return true;
        }

        vm.selectedRows = [];

        vm.authorise = function (idx) {
            var r = vm.todaysAssetRates[idx];
            r.isAuthorised = !r.isAuthorised;
            vm.allAuthChecked = vm.getAllAuthChecked();

            if (r.isAuthorised){
                vm.selectedRows.push(idx);
            } else {
                var pos = vm.selectedRows.indexOf(idx);
                if (pos > -1)
                    vm.selectedRows.splice(pos, 1);
            }
        }
       
        vm.submitRates = function (isValid) {
            if (!isValid)
                return;

            termdepositService
                .submitAssetRates(vm.todaysAssetRates)
                .then(function (response) {
                    vm.submitted = true;
                    $('#myModalSubmitConfirm').modal('hide');
                    notify.showSuccess("Rates are saved successfully.");

                    var reference = response;
                    $('#myModalSubmitConfirm').on('hidden.bs.modal', function () {
                        $location.path('/request/requestReference/' + reference);
                    });

                }, function (err) {
                    vm.errorMessage = commonService.showError(err);
                    notify.showError(vm.errorMessage);
                });
        };
    }

})();
