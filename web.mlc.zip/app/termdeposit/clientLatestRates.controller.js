﻿(function () {
    'use strict';

    angular.module('app').controller('ClientLatestRatesCtrl', ClientLatestRatesCtrl);

    ClientLatestRatesCtrl.$inject = ['$location', '$scope', '$stateParams', 'termdepositService', 'commonService', 'authService', '$q', 'notify'];

    function ClientLatestRatesCtrl($location, $scope, $stateParams, termdepositService, commonService, authService, $q, notify) {

        console.log('ClientLatestRatesCtrl loaded');

        var vm = this;
        vm.title = "Latest Rates";

        if ($stateParams.clientCode) {
            vm.clientCode = $stateParams.clientCode;
        }

        activate();

        ////////////////

        function activate() {
            vm.authentication = authService.authentication;
            console.log('Client Code: ' + vm.clientCode);
            console.log(vm.clientCode);
            termdepositService.getClientLatestAssetRates(vm.clientCode)
                .then(function (response) {
                    vm.adiList = response.adiList;
                    vm.assetRatesList = response.assetRatesList;
                    console.log('returned vm.assetRatesList');
                    console.log(vm.assetRatesList);

                }, function (err) {
                    vm.message = commonService.showError(err);

                    console.log('err message: '+ vm.message)

                    notify.showError(vm.message);
                })
        };

        vm.showHistoryGraph = function (assetNo) {
            vm.modalTitle = "Show History Graph";
            vm.currentAssetNo = assetNo;
            $('#myModal').modal('show');
        }

    }

})();
