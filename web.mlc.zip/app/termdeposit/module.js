﻿'use strict';

angular.module('app.termdeposit', [
    'ui.router',
    'ngResource'
])

.config(function ($stateProvider) {
    $stateProvider
       .state('app.clientLatestRates', {
           url: '/termdeposit/clientLatestRates/:clientCode',
           views: {
               "content@app": { 
                   controller: 'ClientLatestRatesCtrl',
                   templateUrl: 'app/termdeposit/clientLatestRates.html',
                   controllerAs: 'vm'
               }
           },
           data: {
               title: 'Client Latest Rates'
           }
       })
       
       .state('app.adiLatestRates', {
           url: '/termdeposit/adiLatestRates/:adiCode',
           views: {
               "content@app": { 
                   controller: 'AdiLatestRatesCtrl',
                       templateUrl: 'app/termdeposit/adiLatestRates.html',
                   controllerAs: 'vm'
               }
           },
           data: {
               title: 'Adi Latest Rates'
           }
       })
    // .state('app.requestOffbooktrade', {
    //     url: '/request/offbooktrade',
    //     views: {
    //         "content@app": {
    //             controller: 'OffbookTradeCtrl',
    //             templateUrl: 'app/request/offbookTrade.html',
    //             controllerAs: 'vm'
    //         }
    //     },
    //     data: {
    //         title: 'Offbook Trade'
    //     }
    // })

    //.state('app.requestReference', {
    //    url: '/request/requestReference/:reference',
    //    views: {
    //        "content@app": {
    //            controller: 'RequestReferenceCtrl',
    //            templateUrl: 'app/request/requestReference.html',
    //            controllerAs: 'vm'
    //        }
    //    },
    //    data: {
    //        title: 'Request Reference'
    //    }
    //})
});
